﻿/**
 * @file 004-output.cpp
 * @author Thomas Kim (ThomasKim@TalkPlayFun.com)
 * @brief Examples for stream output operators
 * @version 0.1
 * @date 2019-04-13
 * 
 * @copyright Copyright (c) 2019
 * 
 */

#include <vector>
#include <tpf_output.hpp>

void test_output()
{
    using namespace tpf::output;

    

}

int main()
{
    // tpf::conversion::load_default_locale(true);

    
    test_output();
}