﻿/**
 * @file tpf_types.hpp
 * @author Thomas Kim (ThomasKim@TalkPlayFun.com)
 * @brief Type functions are implemented
 * @version 0.1
 * @date 2019-04-13
 * 
 * @copyright Copyright (c) 2019
 * 
 */

#ifndef _TPF_TYPES_HPP
#define _TPF_TYPES_HPP

#ifdef _MSVC_LANG 

	#if _MSVC_LANG < 201703L
		#error This libary requires C++17 Standard (Visual Studio 2017).
	#endif

#else

	#if __cplusplus < 201703
		#error This library requires C++17 Standard (GNU g++ version 8.0 or clang++ version 8.0 above)
	#endif // end of __cplusplus 

#endif // end of _MSVC_LANG

#include <numeric>
#include <type_traits>
#include <string>
#include <cstring>
#include <vector>
#include <deque>
#include <exception>
#include <sstream>
#include <variant>
#include <tuple>
#include <set>
#include <unordered_set>
#include <map>
#include <unordered_map>
#include <list>
#include <any>
#include <functional>
#include <iostream>
#include <future>
#include <thread>
#include <atomic>
#include <mutex>
#include <memory>
#include <iterator>
#include <execution>

#ifdef max
#define _TPF_TYPES_MAX_DEFINED
#pragma push_macro("max")
#undef max
#endif 

#ifdef min
#define _TPF_TYPES_MIN_DEFINED
#pragma push_macro("min")
#undef min
#endif 

#ifdef _MSC_VER
    #define __FUNCTION_NAME__ __FUNCSIG__
#else
    #define __FUNCTION_NAME__ __PRETTY_FUNCTION__
#endif

/**
 * @brief Root namespace for C++ Extension Library
 * 
 */
namespace tpf
{
    enum class direction_t{ left, right };

     /**
     * @brief Remove const volatile reference from Type.
     * 
     * @tparam Type for remove const volatile and reference.
     */
    template<typename Type>
    using remove_cv_ref_t = std::remove_cv_t<std::remove_reference_t<Type>>;

    template<typename Type>
    constexpr bool is_const_v = std::is_const_v<std::remove_reference_t<Type>>;

    /**
     * @brief Decay, remove const, volatile, reference
     * 
     * @tparam Type 
     */
    template<typename Type>
    using decay_remove_cv_ref_t = std::remove_cv_t<std::remove_reference_t<std::decay_t<Type>>>;

    /**
     * @brief Decay, remove reference
     * 
     * @tparam Type 
     */
    template<typename Type>
    using decay_remove_ref_t = std::remove_reference_t<std::decay_t<Type>>;

    /**
     * @brief Decay, remove const, volatile, reference, then remove pointer and remove const and volatile
     * 
     * @tparam Type 
     */
    template<typename Type>
    using primitive_type_t = remove_cv_ref_t<std::remove_pointer_t<decay_remove_cv_ref_t<Type>>>;

    

    template<typename Type_1, typename Type_2>
    auto maximum(Type_1 a, Type_2 b)
    {
        return a >= b ? a : b;
    }

    template<typename Type_1, typename Type_2, typename... Types>
    auto maximum(Type_1 a, Type_2 b, Types... args)
    {
        if constexpr(sizeof...(args)==0)
            return maximum(a, b);
        else
            return maximum(maximum(a, b), maximum(b, args...));
    }

    template<typename Type_1, typename Type_2>
    auto minimum(Type_1 a, Type_2 b)
    {
        return b < a ? b : a;
    }

    template<typename Type_1, typename Type_2, typename... Types>
    auto minimum(Type_1 a, Type_2 b, Types... args)
    {
        if constexpr(sizeof...(args)==0)
            return minimum(a, b);
        else
            return minimum(minimum(a, b), minimum(b, args...));
    }

    /**
     * @brief Test if Type is reference to const object
     * 
     * @tparam Type 
     */
    template<typename Type>
    constexpr bool is_const_reference_v =
        std::is_reference_v<Type> && std::is_const_v<std::remove_reference_t<Type>>;
             
   /**
    * @brief This class implements all debugging requirements for C++ Library Extension
    * 
    */
    class debug_exception: public std::exception
    {
        private:
            std::string m_message;
            int m_lineno;
            std::string m_function_name;
            std::string m_file_name;
            std::string m_what_msg;

        public:
            debug_exception(std::string message,
                int lineno, std::string function_name,
                std::string file_name):
                m_lineno(lineno), m_message(message),
                m_function_name(function_name), m_file_name(file_name)
            { 
                std::ostringstream os;

                os << "debug_exception - file [" << this->m_file_name << "]\n";
                os << "thread id [" << std::this_thread::get_id() << "] - ";
                os << "line [" << this->m_lineno<<"] - ";
                os << "function [" << this->m_function_name<<"]\n\n";
                os << "message: " << this->m_message;
                
                this->m_what_msg = os.str();
            }

            virtual const char* what() const noexcept override
            {
                return this->m_what_msg.c_str();
            }

    }; // end of class debug_exception

    template<typename Type>
    constexpr unsigned long long two_power_n(Type n)
    {
        unsigned long long two_power = 1;
        return (two_power << (unsigned long long)n);
    }

    /**
     * @brief Type to string name conversions are defined.
     * 
     */
    namespace types
    {
        /**
         * @brief This type is used to manipulate type list.
         * 
         * @tparam Types for ZERO or more variadic template parameters.
         */
        template<typename... Types> struct type_list_t{};

        namespace hidden
        {
            template<typename T>
            struct st_is_type_list
            {
                static constexpr bool value = false;
            };

            template<typename... Ts>
            struct st_is_type_list<type_list_t<Ts...>>
            {
                static constexpr bool value = true;
            };

        } // end of namespace hidden

        template<typename T>
        constexpr bool is_type_list_v = hidden::st_is_type_list<remove_cv_ref_t<T>>::value;

        /**
         * @brief Create type_list_t by removing const, volatile, reference
         * 
         * @tparam Types 
         */
        template<typename... Types>
        using remove_cv_ref_type_list_t =  type_list_t<tpf::remove_cv_ref_t<Types>...>;

        /**
         * @brief Create type_list_t by decaying and removing const, volatile, reference
         * 
         * @tparam Types 
         */
        template<typename... Types>
        using decay_remove_cv_ref_type_list_t =  type_list_t<tpf::decay_remove_cv_ref_t<Types>...>;

        /**
         * @brief Create type_list_t by decaying and removing reference
         * 
         * @tparam Types 
         */
        template<typename... Types>
        using decay_remove_ref_type_list_t =  type_list_t<tpf::decay_remove_ref_t<Types>...>;

        namespace hidden
        {
            template<typename... Types>
            struct st_type_list_to_tuple_of_vectors
            {
                using type = std::tuple< std::vector<Types>... >;
            };

            template<typename... Types>
            struct st_type_list_to_tuple_of_vectors<type_list_t<Types...>>
            {
                using type = std::tuple<std::vector<Types>... >;
            };

            template<template<typename...> class CntrType, typename... Types>
            struct st_type_list_to_tuple_of_vectors<CntrType<Types...>>
            {
                using type = std::tuple< std::vector<Types>... >;
            };

        } // end of namespace hidden

        template<typename... Types>
        using tuple_of_vectors_t = typename hidden::st_type_list_to_tuple_of_vectors<Types...>::type;

        namespace hidden
        {
            template<std::size_t ...I>
            struct st_vector
            {
                using type = std::vector<std::size_t>;
            };

            template<typename Type> struct st_index_tuple_vector;
            
            template<std::size_t ...Is>
            struct st_index_tuple_vector<std::index_sequence<Is...>>
            {
                using type = std::tuple<typename st_vector<Is>::type...>;
            };
        
        } // end of namespace hidden
        
        template<std::size_t N>
        using index_tuple_vector_t = typename hidden::st_index_tuple_vector<std::make_index_sequence<N>>::type;

        template<typename PointerType, typename SizeType>
        struct array_wrapper_t: public std::pair<PointerType, SizeType>
        {
            public:
                using base_type = std::pair<PointerType, SizeType>;
               
                template<typename ElementType, size_t ElementCount>
                array_wrapper_t(ElementType(&array)[ElementCount]) noexcept:
                    std::pair<ElementType*, size_t>{array, ElementCount} { }
        };

        template<typename ElementType, size_t ElementCount>
        array_wrapper_t(ElementType(&)[ElementCount]) -> array_wrapper_t<ElementType*, size_t>;

        template<typename ElementType, size_t ElementSize>
        auto array_wrapper(ElementType(&array)[ElementSize]) noexcept
        {
            return array_wrapper_t<ElementType*, size_t>{array};
        }

        template<typename Type>
        auto to_ref(const Type& value) { return std::ref(const_cast<Type&>(value)); }
        
        template<typename Type>
        constexpr bool is_array_v = std::is_array_v<remove_cv_ref_t<Type>>;      

        template<typename ElementType, size_t ElementSize>
        constexpr size_t array_size(ElementType(&array)[ElementSize]) noexcept { return (size_t) ElementSize; }
              
        // forward declaration
        template<typename ContainerType> class reverse_st;
        template<typename ContainerType> auto reverse(ContainerType&& container);
        template<typename ElementType, size_t ElementCount> auto reverse(ElementType(&array)[ElementCount]);

        template<typename Type, typename... Types> auto reverse(Type&& arg, Types&&... args);
        template<typename Type, typename... Types> auto make_vector(Type&& arg, Types&&... args);
        template<typename Type, typename... Types> auto make_container(Type&& arg, Types&&... args);

        template<typename ContainerType, typename IndexType>
        decltype(auto) get_element(ContainerType container, IndexType index);

        #if !defined(__clang_major__)
            template<typename Type, typename... Types> auto make_variants(Type&& arg, Types&&... args);
        #endif

        template<typename Type>
        decltype(auto) decay(Type&& arg) 
        { 
            using type = std::remove_reference_t<Type>;

            if constexpr(std::is_array_v<type> || std::is_function_v<type>)
                return decay_remove_cv_ref_t<type>(arg);
            else
                return std::forward<Type>(arg);
        }

        /**
         * @brief Returns Type's string name.
         * 
         * @tparam Type &mdash; Constraints: NONE
         * @return std::string &mdash; if fails, DOES NOT FAIL
         * @sa <a target ="_blank" href="001-type__to__string_8cpp_source.html">001-type_to_string.cpp</a>
         */
        template<typename Type>
        std::string type_to_string()
        {
            #ifdef __FUNCSIG__
                std::string fname(__FUNCSIG__);
                const char* to_str = "to_string<";
                size_t len = strlen(to_str);
                auto pos = fname.find("to_string<");
                fname = fname.substr(pos+len);
                return fname.substr(0, fname.find_last_of('>'));
            #else
                
                std::string fname(__PRETTY_FUNCTION__);
                
                #ifdef __clang_major__
                    const char* ftext = "[Type = ";
                    auto pos = fname.find(ftext) + strlen(ftext);
                    fname = fname.substr(pos);
                    fname.pop_back();
                    return fname;

                #elif defined(__ICL)
                    const char* ftext = "type_to_string<";
                    auto pos = fname.find(ftext) + strlen(ftext);
                    fname = fname.substr(pos);
                    pos = fname.find_last_of('>');
                    return fname.substr(0, pos);
                #else
                    const char* ftext = "[with Type = ";
                    auto pos = fname.find(ftext) + strlen(ftext);
                    fname = fname.substr(pos);
                    pos = fname.find_first_of(';');
                    return fname.substr(0, pos);
                 #endif
             #endif

        } // end of type_to_string()

    } // end of namespace types

} // end of namespace tpf

#define Tpf_DebugException(debug_message) tpf::debug_exception{debug_message, __LINE__, __FUNCTION_NAME__, __FILE__}


/**
 * @brief Throw a debug_exception with \a message as argument
 * 
 */
#define Tpf_ThrowDebugException(debug_message) throw tpf::debug_exception{debug_message, __LINE__, __FUNCTION_NAME__, __FILE__}

 /**
  * @brief A macro that returns type_arg's string name
  * @sa <a target ="_blank" href="001-type__to__string_8cpp_source.html">001-type_to_string.cpp</a>
  */
#define Tpf_GetTypeName(type_arg) tpf::types::type_to_string<type_arg>()
 
 /**
  * @brief A macro that returns instance_arg's type category string name 
  * @sa <a target ="_blank" href="001-type__to__string_8cpp_source.html">001-type_to_string.cpp</a>
  */
#define Tpf_GetTypeCategory(instance_arg) Tpf_GetTypeName(decltype(instance_arg))
 
/**
 * @brief A macro that returns instance_arg's value category string name 
 * @sa <a target ="_blank" href="001-type__to__string_8cpp_source.html">001-type_to_string.cpp</a>
 */
#define Tpf_GetValueCategory(instance_arg) Tpf_GetTypeName(decltype((instance_arg)))

/**
 * @brief Root namespace for C++ Extension Library
 * 
 */
namespace tpf
{
    template<typename IndexType, typename ContainerType,
    typename container_t = tpf::remove_cv_ref_t<ContainerType>,
    typename iterator_type = typename container_t::iterator>
    auto index_to_iterator(ContainerType&& cntr, IndexType&& index);

    template<typename IndexType,  typename ContainerType,
    typename container_t = tpf::remove_cv_ref_t<ContainerType>,
     typename reverse_iterator_type = typename container_t::reverse_iterator>
    auto index_to_reverse_iterator(ContainerType&& cntr, IndexType&& offset);

    template<typename ContainerType, 
    typename container_t = tpf::remove_cv_ref_t<ContainerType>,
    typename iterator_type = typename container_t::iterator>
    auto iterator_to_index(ContainerType&& cntr, iterator_type&& offset);

    template<typename ContainerType,
    typename container_t = tpf::remove_cv_ref_t<ContainerType>,
    typename reverse_iterator_type = typename container_t::reverse_iterator>
    auto reverse_iterator_to_index(ContainerType&& cntr, reverse_iterator_type&& offset);

    template<typename ReverseIteratorType,
        typename reverse_iterator_type = std::remove_reference_t<ReverseIteratorType>>
    inline auto reverse_iterator_to_iterator(ReverseIteratorType&& itr)
    {
        return itr.base() - 1;
    }

    template<typename IteratorType,
        typename iterator_type = std::remove_reference_t<IteratorType>>
    inline auto iterator_to_reverse_iterator(IteratorType&& itr)
    {
        return std::make_reverse_iterator(std::forward<IteratorType>(itr));
    }

    template<direction_t direction = direction_t::left, 
    typename ContainerType = std::vector<int>,
    typename container_t = tpf::remove_cv_ref_t<ContainerType>,
    typename iterator_type = typename container_t::iterator,
    typename reverse_iterator_type = typename container_t::reverse_iterator>
    auto make_rotator(ContainerType&& cntr);

    template<direction_t direction = direction_t::left, 
    typename ContainerType = std::vector<int>,
    typename container_t = tpf::remove_cv_ref_t<ContainerType>,
    typename iterator_type = typename container_t::iterator,
    typename reverse_iterator_type = typename container_t::reverse_iterator,
    typename execution_policy_type = std::execution::parallel_unsequenced_policy>
    auto make_rotator(ContainerType&& cntr, execution_policy_type policy);

    template<typename ForwardIterator, typename EleType, typename CompareCallbackType = std::less<>>
    auto find_range_iterators(ForwardIterator first, ForwardIterator last, 
        const EleType& value, CompareCallbackType&& compare_callback = CompareCallbackType{})
    {
        auto range = std::equal_range(first, last, value, std::forward<CompareCallbackType>(compare_callback));
        
        return std::make_tuple(std::distance(range.first, range.second), range.first, range.second);
    }

    template<typename ForwardIterator, typename EleType, typename CompareCallbackType = std::less<>>
    auto find_range_indices(ForwardIterator first, ForwardIterator last, 
        const EleType& value, CompareCallbackType&& compare_callback = CompareCallbackType{})
    {
        auto range = std::equal_range(first, last, value, std::forward<CompareCallbackType>(compare_callback));
        
        return std::make_tuple(std::distance(range.first, range.second),
                std::distance(first, range.first), std::distance(first, range.second));
    }

    template<typename EleType, template<typename, typename...> class ContainerType, typename... Types,
        typename CompareCallbackType = std::less<>>
    auto find_range_iterators(const ContainerType<EleType, Types...>& container, const EleType& value, 
        CompareCallbackType&& compare_callback = CompareCallbackType{})
    {
        return find_range_iterators(container.cbegin(), container.cend(),
            value, std::forward<CompareCallbackType>(compare_callback));
    }

    template<typename EleType, template<typename, typename...> class ContainerType, typename... Types,
        typename CompareCallbackType = std::less<>>
    auto find_range_indices(const ContainerType<EleType, Types...>& container, const EleType& value, 
        CompareCallbackType&& compare_callback = CompareCallbackType{})
    {
        return find_range_indices(container.cbegin(), container.cend(),
            value, std::forward<CompareCallbackType>(compare_callback));
    }

    template<typename ForwardIterator, typename EleType, typename CompareCallbackType = std::less<>>
    auto binary_find_iterator(ForwardIterator first, ForwardIterator last, 
        const EleType& value, CompareCallbackType&& compare_callback = CompareCallbackType{})
    {
        auto start = std::lower_bound(first, last, value, compare_callback);
        
        return start != last && !compare_callback(value, *start) ? start : last;
    }

    template<typename ForwardIterator, typename EleType, typename CompareCallbackType = std::less<>>
    auto binary_find_index(ForwardIterator first, ForwardIterator last, 
        const EleType& value, CompareCallbackType&& compare_callback = CompareCallbackType{})
    {
        auto start = std::lower_bound(first, last, value, compare_callback);
      
        auto iterator = (start != last && !compare_callback(value, *start)) ? start : last;

        return (iterator != last) ? 
            std::distance(first, iterator) : std::distance(first, last);   
    }

    template<typename EleType, template<typename, typename...> class ContainerType, typename... Types,
        typename CompareCallbackType = std::less<>>
    auto binary_find_iterator(const ContainerType<EleType, Types...>& container, const EleType& value, 
        CompareCallbackType&& compare_callback = CompareCallbackType{})
    {
        return binary_find_iterator(container.cbegin(), container.cend(), value,
            std::forward<CompareCallbackType>(compare_callback));
    }

     template<typename ForwardIterator, typename EleType, typename CompareCallbackType = std::less<>>
    auto binary_find_bool_iterator_pair(ForwardIterator first, ForwardIterator last, 
        const EleType& value, CompareCallbackType&& compare_callback = CompareCallbackType{})
    {
        auto iterator = binary_find_iterator(first, last, value,
            std::forward<CompareCallbackType>(compare_callback));

        return (iterator != last) ? 
            std::make_pair(true, iterator) : std::make_pair(false, iterator);
    }

    template<typename EleType, template<typename, typename...> class ContainerType, typename... Types,
        typename CompareCallbackType = std::less<>>
    auto binary_find_bool_iterator_pair(const ContainerType<EleType, Types...>& container, const EleType& value, 
        CompareCallbackType&& compare_callback = CompareCallbackType{})
    {
        return binary_find_bool_iterator_pair(container.cbegin(), container.cend(), value,
            std::forward<CompareCallbackType>(compare_callback));
    }

    template<typename EleType, template<typename, typename...> class ContainerType, typename... Types,
        typename CompareCallbackType = std::less<> >
    auto binary_find_index(const ContainerType<EleType, Types...>& container, const EleType& value, 
        CompareCallbackType&& compare_callback = CompareCallbackType{})
    {
        return binary_find_index(container.cbegin(), container.cend(), value,
            std::forward<CompareCallbackType>(compare_callback));
    }

    template<typename ForwardIterator, typename EleType, typename CompareCallbackType = std::less<>>
    auto binary_find_bool_index_pair(ForwardIterator first, ForwardIterator last, 
        const EleType& value, CompareCallbackType&& compare_callback = CompareCallbackType{})
    {
        auto start = std::lower_bound(first, last, value, compare_callback);

        auto iterator = (start != last && !compare_callback(value, *start)) ? start : last;

        return (iterator != last) ? 
            std::make_pair(true,  std::distance(first, iterator)) :
            std::make_pair(false, std::distance(first, iterator));
    }

    template<typename EleType, template<typename, typename...> class ContainerType, typename... Types,
        typename CompareCallbackType = std::less<>>
    auto binary_find_bool_index_pair(const ContainerType<EleType, Types...>& container, const EleType& value, 
        CompareCallbackType&& compare_callback = CompareCallbackType{})
    {
        return binary_find_bool_index_pair(container.cbegin(), container.cend(), value,
            std::forward<CompareCallbackType>(compare_callback));
    }

    template<typename Type>
    constexpr auto type_max_v = std::numeric_limits<Type>::max();
    constexpr size_t InvalidIndex = type_max_v<size_t>;
    constexpr size_t SelectAll = InvalidIndex;

    using big_integer_t = long long;
    using big_unsigned_t = unsigned long long;

    struct thread_bundle
    {
        int max_thread_count;
        std::atomic<int> thread_count{0};
        std::mutex mutex; 
    };

    struct boolean
	{
		static constexpr bool Left = false;
		static constexpr bool Right = true;

		static constexpr bool Or = false;
		static constexpr bool And = true;

		static constexpr bool No = false;
		static constexpr bool Yes = true;

		static constexpr bool False = false;
		static constexpr bool True = true;

		static constexpr bool Before = false;
		static constexpr bool After = true;

		static constexpr bool Prepend = false;
		static constexpr bool Append = true;
	};

    namespace types
    {
        /**
         * @brief Test if a function is specified with the keyword noexcept
         * 
         * @tparam FuncType 
         * @tparam ArgTypes 
         */
        template<auto FuncType, typename... ArgTypes>
        constexpr auto is_noexcept_v = noexcept(FuncType(std::declval<ArgTypes>()...));
        
        namespace hidden
        {
            template<typename Type>
            struct is_variant_st
            {
                static constexpr bool value = false;
            };

            template<typename... Types>
            struct is_variant_st<std::variant<Types...>>
            {
                static constexpr bool value = true;
            };

            template<typename Type>
            constexpr auto is_variant_v = is_variant_st<Type>::value;

            template<typename Type>
            struct is_unique_ptr_st
            {
                static constexpr bool value = false;
            };

            template<typename Type, typename... Types>
            struct is_unique_ptr_st<std::unique_ptr<Type, Types...>>
            {
                static constexpr bool value = true;
            };

            template<typename Type>
            constexpr auto is_unique_ptr_v = is_unique_ptr_st<Type>::value;

            template<typename Type>
            struct is_pair_st
            {
                static constexpr bool value = false;
            };

            template<typename Type_1, typename Type_2>
            struct is_pair_st<std::pair<Type_1, Type_2>>
            {
                static constexpr bool value = true;
            };

            template<typename Type>
            constexpr auto is_pair_v = is_pair_st<Type>::value;
            
            /////////////////////////////////
            template<typename Type>
            struct is_pair_of_variant_st
            {
                static constexpr bool value = false;
            };

            template<typename Type, typename... Types>
            struct is_pair_of_variant_st<std::pair<Type, Types...>>
            {
                static constexpr bool value = true;
            };

            template<typename Type>
            constexpr auto is_pair_of_variant_v 
                = is_pair_of_variant_st<Type>::value;

            template<typename Type>
            struct is_map_or_unordered_map_st
            {
                using type = Type;
                static constexpr bool value = false;
            };

            template<typename KeyType, typename ValueType, typename... Types>
            struct is_map_or_unordered_map_st<std::map<KeyType, ValueType, Types...>>
            {
                using type = std::pair<KeyType, ValueType>;
                static constexpr bool value = true;
            };

            template<typename KeyType, typename ValueType, typename... Types>
            struct is_map_or_unordered_map_st<std::unordered_map<KeyType, ValueType, Types...>>
            {
                using type = std::pair<KeyType, ValueType>;
                static constexpr bool value = true;
            };

            template<typename Type>
            constexpr auto is_map_or_unordered_map_v = is_map_or_unordered_map_st<remove_cv_ref_t<Type>>::value;

            template<typename Type>
            using map_or_unordered_map_pair_t = typename is_map_or_unordered_map_st<remove_cv_ref_t<Type>>::type;

            template<typename Type>
            struct is_set_or_unordered_set_st
            {
                using type = Type;
                static constexpr bool value = false;
            };
            
            template<typename Type, typename... Types>
            struct is_set_or_unordered_set_st<std::set<Type, Types...>>
            {
                using type = Type;
                static constexpr bool value = true;
            };

            template<typename Type, typename... Types>
            struct is_set_or_unordered_set_st<std::unordered_set<Type, Types...>>
            {
                using type = Type;
                static constexpr bool value = true;
            };

            template<typename Type>
            constexpr auto is_set_or_unordered_set_v = is_set_or_unordered_set_st<Type>::value;

            template<typename Type>
            struct is_tuple_st
            {
                static constexpr bool value = false;
            };

            template<typename... Types>
            struct is_tuple_st<std::tuple<Types...>>
            {
                static constexpr bool value = true;
            };

            template<typename Type>
            constexpr auto is_tuple_v = is_tuple_st<Type>::value;

            template<typename Type>
            struct is_any_st
            {
                static constexpr bool value = false;
            };

            template<>
            struct is_any_st<std::any>
            {
                static constexpr bool value = true;
            };

            template<typename Type>
            constexpr auto is_any_v = is_any_st<Type>::value;

            template<typename Type>
            struct is_basic_string_st
            {
                static constexpr bool value = false;
            };

            template<typename Type, typename... Types>
            struct is_basic_string_st<std::basic_string<Type, Types...>>
            {
                static constexpr bool value = true;
            };

            template<typename Type>
            constexpr auto is_basic_string_v = is_basic_string_st<Type>::value;

            template<typename Type>
            struct is_char_st
            {
                static constexpr bool value = false;
            };

            template<>
            struct is_char_st<char>
            {
                static constexpr bool value = true;
            };

            template<>
            struct is_char_st<unsigned char>
            {
                static constexpr bool value = true;
            };
            
            template<typename Type>
            constexpr bool is_char_v = is_char_st<tpf::remove_cv_ref_t<Type>>::value;

        } // end of namespace hidden

        template<typename Type>
        constexpr bool is_char_v = hidden::is_char_v<Type>;  

        template<typename Type>
        constexpr auto is_variant_v = hidden::is_variant_v<Type>;

        template<typename Type>
        constexpr auto is_unique_ptr_v = hidden::is_variant_v<Type>;

        template<typename Type>
        constexpr auto is_pair_v = hidden::is_pair_v<Type>;

        template<typename Type>
        constexpr auto is_pair_of_variant_v = hidden::is_pair_of_variant_v<Type>;

        template<typename Type>
        constexpr auto is_tuple_v = hidden::is_tuple_v<Type>;

        template<typename Type>
        constexpr auto is_any_v = hidden::is_any_v<Type>;

        template<typename Type>
        constexpr auto is_map_or_unordered_map_v = hidden::is_map_or_unordered_map_v<Type>;

        template<typename Type>
        using map_or_unordered_map_pair_t = hidden::map_or_unordered_map_pair_t<Type>;

        template<typename Type>
        constexpr auto is_basic_string_v = hidden::is_basic_string_v<Type>;

        template<typename Type>
        constexpr auto is_set_or_unordered_set_v = hidden::is_set_or_unordered_set_v<Type>;

    } // end of namespace types
        
    template<template<typename, typename...> class ContainerType, typename EleType, typename... Types>
    struct set_tag
    {
        using set_element_t = EleType;
        
        using set_t = ContainerType<EleType, Types...>;
        using sets_t = ContainerType<ContainerType<EleType, Types...>>;
        using set_of_sets_t = ContainerType<ContainerType<ContainerType<EleType, Types...>>>;
        using sets_of_sets_t = ContainerType<ContainerType<ContainerType<ContainerType<EleType, Types...>>>>;

        using duet_set_element_t = std::tuple<set_element_t, set_element_t>;
        using duet_set_t = std::tuple<set_t, set_t>;
        using duet_sets_t = std::tuple<sets_t, sets_t>;
        using duet_set_of_sets_t = std::tuple<set_of_sets_t, set_of_sets_t>;
        using duet_sets_of_sets_t = std::tuple<sets_of_sets_t, sets_of_sets_t>;

        using set_of_duets_t = ContainerType<duet_set_t>;
        
        using trio_set_element_t = std::tuple<set_element_t, set_element_t, set_element_t>;
        using trio_set_t = std::tuple<set_t, set_t, set_t>;
        using trio_sets_t = std::tuple<sets_t, sets_t, sets_t>;
        using trio_set_of_sets_t = std::tuple<set_of_sets_t, set_of_sets_t, set_of_sets_t>;
        using trio_sets_of_sets_t = std::tuple<sets_of_sets_t, sets_of_sets_t, sets_of_sets_t>;
    };

    template<typename SetTagType = set_tag<std::vector, int>>
    using set_element_t = typename SetTagType::set_element_t;

    template<typename SetTagType = set_tag<std::vector, int>>
    using set_t = typename SetTagType::set_t;
    
    template<typename SetTagType = set_tag<std::vector, int>>
    using sets_t = typename SetTagType::sets_t;

    template<typename SetTagType = set_tag<std::vector, int>>
    using set_of_sets_t = typename SetTagType::set_of_sets_t;
    
    template<typename SetTagType = set_tag<std::vector, int>>
    using sets_of_sets_t = typename SetTagType::sets_of_sets_t;
    
    template<typename SetTagType = set_tag<std::vector, int>>
    using duet_set_element_t = typename SetTagType::duet_set_element_t;
    
    template<typename SetTagType = set_tag<std::vector, int>>
    using duet_set_t = typename SetTagType::duet_set_t;
    
    template<typename SetTagType = set_tag<std::vector, int>>
    using duet_sets_t = typename SetTagType::duet_sets_t;
    
    template<typename SetTagType = set_tag<std::vector, int>>
    using duet_set_of_sets_t = typename SetTagType::duet_set_of_sets_t;

    template<typename SetTagType = set_tag<std::vector, int>>
    using duet_sets_of_sets_t = typename SetTagType::duet_sets_of_sets_t;

    template<typename SetTagType = set_tag<std::vector, int>>
    using set_of_duets_t = typename SetTagType::set_of_duets_t;
    
    template<typename SetTagType = set_tag<std::vector, int>>
    using trio_set_element_t = typename SetTagType::trio_set_element_t;

    template<typename SetTagType = set_tag<std::vector, int>>
    using trio_set_t = typename SetTagType::trio_set_t;

    template<typename SetTagType = set_tag<std::vector, int>>
    using trio_sets_t = typename SetTagType::trio_sets_t;

    template<typename SetTagType = set_tag<std::vector, int>>
    using trio_set_of_sets_t = typename SetTagType::trio_set_of_sets_t;
    
    template<typename SetTagType = set_tag<std::vector, int>>
    using trio_sets_of_sets_t = typename SetTagType::trio_sets_of_sets_t;
    
     /**
     * @brief Type functions are defined.
     * 
     */
    namespace types
    {
        /**
         * @brief This type is used to test validity of a type.
         * 
         */
        struct no_type_t{}; // "zero" in C++ type system
            // no_type_t plays the role of zero in C++ type system.

        struct void_type_t{};
        
        namespace hidden
        {
            template<typename Type> struct return_type_st 
            {
                using type = Type;
            };

            template<> struct return_type_st<void>
            {
                using type = void_type_t;
            };

            template<typename Type>
            using return_type_t = typename return_type_st<Type>::type;

        } // end of namespace hidden

        template<typename Type>
        using return_type_t = hidden::return_type_t<Type>;

        template<typename Type>
        constexpr bool is_no_type_v = std::is_same_v<Type, no_type_t>;

        template<typename Type>
        constexpr bool is_valid_type_v = !is_no_type_v<Type>;

        namespace hidden
        {
            template<typename... Types>
            struct type_count_st
            {
                static constexpr size_t value = sizeof...(Types);
            };

            template<typename... Types>
            struct type_count_st<type_list_t<Types...>>
            {
                static constexpr size_t value = sizeof...(Types);
            };

            template<template<typename...> class TemplateType, typename... Types>
            struct type_count_st<TemplateType<Types...>>
            {
                static constexpr size_t value = sizeof...(Types);
            };

            template<typename... Types>
            constexpr auto type_count_v = type_count_st<Types...>::value;

            // if T is an iterator, this function is enabled
            // and returns the value type of the iterator type T
            // if T is not an iterator, then this function is SFINAEd out
            template<typename T> constexpr std::enable_if_t<true,
                typename std::iterator_traits<T>::value_type>
                iterator_value_type_fn(T&&);

            // this is catch all function for iterator_value_type_fn()
            constexpr no_type_t iterator_value_type_fn(...);

            // if T is an iterator iterator_value_type_fn returns value_type of the 
            // iterator, otherwise NoTypeDummy is returned.
            // if the returned value is Not equal to NoTypeDummy,
            // then T is an iterator, otherwise not an iterator
            template<typename T>
            constexpr bool is_iterator_type_v = 
                is_valid_type_v<decltype(iterator_value_type_fn(std::declval<T>()))>;

            template<typename T>
            constexpr bool is_iterator_excluding_pointer_v = 
                is_iterator_type_v<T> && !std::is_pointer_v<T>;

            // if T is an iterator, it returns T::value_type
            // otherwise, it returns NoTypeDummy
            template<typename T>
            using iterator_value_type_t = decltype(iterator_value_type_fn(std::declval<T>()));

            // if T is an iterator, this returns T
            // otherwise, it is SFINAEd out
            template<typename Type, typename ReturnType>
            using enable_if_iterator_type_t = std::enable_if_t<is_iterator_type_v<Type>, ReturnType>;

            // if T is an iterator, this returns T::value_type
            // otherwise, it is SFINAEd out
            template<typename T>
            using enable_if_iterator_value_type_t = std::enable_if_t<is_iterator_type_v<T>, iterator_value_type_t<T>>;

            // if T is an iterator, this returns T::value_type
            // otherwise, it returns T
            template<typename T>
            using conditional_iterator_value_type_t = 
                typename std::conditional<is_iterator_type_v<T>, iterator_value_type_t<T>, T>::type;

        } // end of namespace hidden
               
        template<typename T>
        constexpr bool is_iterator_type_v = hidden::is_iterator_type_v<remove_cv_ref_t<T>>;

        template<typename T>
        constexpr bool is_iterator_excluding_pointer_v = 
            hidden::is_iterator_excluding_pointer_v<remove_cv_ref_t<T>>;

        template<typename Type, typename ReturnType>
            using enable_if_iterator_type_t = hidden::enable_if_iterator_type_t<remove_cv_ref_t<Type>, ReturnType>;

        template<typename... Types>
        constexpr auto type_count_v = hidden::type_count_v<Types...>;        
         
        template<typename... Types>
        type_list_t<Types...> type_to_string(Types&&... args)
        {
            return {};
        } 

        /**
         * @brief Type list of character types. 
         * 
         */
        using character_list_t = type_list_t<char, unsigned char, wchar_t>;
       
        /**
         * @brief Type list of integers EXCLUSING character type and boolean type. 
         * 
         */
        using integer_list_t = type_list_t<short, unsigned short,
                int, unsigned int, long, unsigned long,
                long long, unsigned long long>;

        /**
         * @brief Signed integers EXCLUDING char and boolean
         * 
         */
        using signed_integer_list_t = type_list_t<short, int, long, long long>;
        
        /**
         * @brief Unsigned integers EXCLUDING unsigned char and boolean
         * 
         */
        using unsigned_integer_list_t = type_list_t<unsigned short, unsigned int, unsigned long, unsigned long long>;
        
        /**
         * @brief Type list of integral type INCLUDING character type, but EXCLUDING boolean type. 
         * 
         */
        using integral_list_t = type_list_t<char, unsigned char, short, unsigned short,
                int, unsigned int, long, unsigned long,
                long long, unsigned long long>;

        /**
         * @brief Type list of unsigned integral type INCLUDING character type, but EXCLUDING boolean type. 
         * 
         */
        using unsigned_integral_list_t = type_list_t<unsigned char, unsigned short,
                unsigned int, unsigned long, unsigned long long>;

         /**
         * @brief Type list of signed integral type INCLUDING character type, but EXCLUDING boolean type. 
         * 
         */
        using signed_integral_list_t = type_list_t<char, short,
                int, long int, long long int>;

        /**
         * @brief Type list of real numbers (floating-point numbers).
         * 
         */
        using real_number_list_t = type_list_t<float, double, long double>;

        /**
         * @brief Numbers adequate for mathematical analysis.
         * 
         */
        using numerical_number_list_t = type_list_t<char, short, int, long, long long, float, double, long double>;

        /**
         * @brief The same to real_number_list_t, real numbers.
         * 
         */
        using floating_point_list_t = real_number_list_t;

        /**
         * @brief Implementations in this scope is meant NOT to be accessed directly by the client.
         * 
         */
        namespace hidden
        {
            template<typename Type>
            struct is_template_st
            {
                using type = type_list_t<Type>;
                static constexpr bool value = false;
                static constexpr size_t count = 1;
            };

            // zero or more template parameters
            template<template<typename...>class ContainerType, typename...Types>
            struct is_template_st<ContainerType<Types...>>
            {
                using type = type_list_t<Types...>;
                static constexpr bool value = true;
                static constexpr size_t count = sizeof...(Types);
            };

            template<typename Type>
            constexpr auto is_template_v = is_template_st<Type>::value;

            template<typename Type>
            constexpr auto template_parameter_count = is_template_st<Type>::count;

            template<typename Type>
            using template_parameter_type_list_t = typename is_template_st<Type>::type;

            template<typename Type1, typename Type2>
            struct is_same_template_type_st
            {
                static constexpr bool value = false;
            };

            template<template<typename...> class ContainerType, typename... Types>
            struct is_same_template_type_st<ContainerType<Types...>, ContainerType<Types...>>
            {
                static constexpr bool value = true;
            };

            template<template<typename, typename...> class ContainerType,
                typename Type, typename... Types>
            struct is_same_template_type_st<ContainerType<Type, Types...>, ContainerType<Type, Types...>>
            {
                static constexpr bool value = true;
            };

            template<template<typename, typename, typename...> class ContainerType,
                typename Type1, typename Type2, typename... Types>
            struct is_same_template_type_st<ContainerType<Type1, Type2, Types...>,
                ContainerType<Type1, Type2, Types...>>
            {
                static constexpr bool value = true;
            };

            template<template<typename, typename, typename, typename...> class ContainerType,
                typename Type1, typename Type2, typename Type3, typename... Types>
            struct is_same_template_type_st<ContainerType<Type1, Type2, Type3, Types...>,
                ContainerType<Type1, Type2, Type3, Types...>>
            {
                static constexpr bool value = true;
            };

            template<template<typename, typename, typename, typename...> class ContainerType,
                typename Type1, typename Type2, typename Type3, typename Type4, typename... Types>
            struct is_same_template_type_st<ContainerType<Type1, Type2, Type3, Type4, Types...>,
                ContainerType<Type1, Type2, Type3, Type4, Types...>>
            {
                static constexpr bool value = true;
            };

            template<typename Type1, typename Type2>
            constexpr auto is_same_template_type_v = is_same_template_type_st<Type1, Type2>::value;

            template<typename Type1, typename Type2>
            struct is_same_template_st
            {
                static constexpr bool value = false;
            };

            template<template<typename...> class ContainerType,
                typename... Types1, typename... Types2>
            struct is_same_template_st<ContainerType<Types1...>, ContainerType<Types2...>>
            {
                static constexpr bool value = true;
            };

            template<template<typename, typename...> class ContainerType,
                typename TypeA, typename... TypeAs,
                typename TypeB, typename... TypeBs>
            struct is_same_template_st<ContainerType<TypeA, TypeAs...>,
                ContainerType<TypeB, TypeBs...>>
            {
                static constexpr bool value = true;
            };

            template<template<typename, typename, typename...> class ContainerType,
                typename TypeA1, typename TypeA2, typename... TypeAs,
                typename TypeB1, typename TypeB2, typename... TypeBs>
            struct is_same_template_st<ContainerType<TypeA1, TypeA2, TypeAs...>,
                 ContainerType<TypeB1, TypeB2, TypeBs...>>
            {
                static constexpr bool value = true;
            };

            template<template<typename, typename, typename, typename...> class ContainerType,
                typename TypeA1, typename TypeA2, typename TypeA3, typename... TypeAs,
                typename TypeB1, typename TypeB2, typename TypeB3, typename... TypeBs>
            struct is_same_template_st<ContainerType<TypeA1, TypeA2, TypeA3, TypeAs...>,
                 ContainerType<TypeB1, TypeB2, TypeB3, TypeBs...>>
            {
                static constexpr bool value = true;
            };

            template<template<typename, typename, typename, typename...> class ContainerType,
                typename TypeA1, typename TypeA2, typename TypeA3, typename TypeA4, typename... TypeAs,
                typename TypeB1, typename TypeB2, typename TypeB3, typename TypeB4, typename... TypeBs>
            struct is_same_template_st<ContainerType<TypeA1, TypeA2, TypeA3, TypeA4, TypeAs...>,
                 ContainerType<TypeB1, TypeB2, TypeB3, TypeB4, TypeBs...>>
            {
                static constexpr bool value = true;
            };

            template<typename Type1, typename Type2>
            constexpr auto is_same_template_v = is_same_template_st<Type1, Type2>::value;
            
        } // end of namespace hidden

        /**
         * @brief Test whether the type parameter is a template type.
         * 
         * @tparam Type for test whether the type is a template type.
         * 
         */
        template<typename Type>
        constexpr auto is_template_v = hidden::is_template_v<Type>;

        template<typename Type>
        constexpr auto template_parameter_count = hidden::template_parameter_count<Type>;
       
        template<typename Type>
        using template_parameter_type_list_t = hidden::template_parameter_type_list_t<Type>;

        template<typename Type1, typename Type2>
        constexpr auto is_same_template_type_v = hidden::is_same_template_type_v<Type1, Type2>;

        template<typename Type1, typename Type2>
        constexpr auto is_same_template_v = hidden::is_same_template_v<Type1, Type2>;
        
        /**
         * @brief Implementations in this scope is meant NOT to be accessed directly by the client.
         * 
         */
        namespace hidden
        {
            template<typename Type>
            struct is_string_st
            {
                static constexpr bool value = false;
            };

            template<>
            struct is_string_st<const char*>
            {
                static constexpr bool value = true;
            };

            template<>
            struct is_string_st<const wchar_t*>
            {
                static constexpr bool value = true;
            };

            template<typename CharType>
            struct is_string_st<std::basic_string<CharType>>
            {
                static constexpr bool value = true;
            };

            template<typename Type>
            constexpr auto is_string_v = is_string_st<remove_cv_ref_t<Type>>::value;          

        } // end of namespace hidden

        /**
         * @brief Test is Type is of string type.
         * 
         * If Type is one of const char*, const wchar_t*, std::string, std::wstring, 
         * Type is_string_v<Type> returns true, otherwise false.
         * 
         * @tparam Type to test if it is of string category.
         */
        template<typename Type>
        constexpr auto is_string_v = hidden::is_string_v<Type>;

        /**
         * @brief Implementation ins this scope is NOT meant to be directly accessed by the client.
         * 
         */
        namespace hidden
        { 
            template<typename Type1, typename Type2>
            constexpr auto is_operable_fn(Type1&& arg1, Type2&& arg2) 
                noexcept(noexcept(std::declval<remove_cv_ref_t<Type1>>()) 
                    && noexcept(std::declval<remove_cv_ref_t<Type2>>())) -> decltype(true ? arg1 : arg2);

            constexpr no_type_t is_operable_fn(...) noexcept;
         
            template<typename Type1, typename Type2>
            using is_operable_t = std::remove_reference_t<decltype(is_operable_fn(std::declval<Type1>(), std::declval<Type2>()))>;

            template<typename Type1, typename Type2>
            constexpr auto is_operable_v = 
                is_valid_type_v<is_operable_t<Type1, Type2>>;

            template<typename Type>
            constexpr auto is_empty_available_fn(Type&& arg)
                noexcept(noexcept(std::declval<remove_cv_ref_t<Type>>()))->decltype(arg.empty());

            constexpr no_type_t is_empty_available_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_empty_available_v = 
                is_valid_type_v<decltype(is_empty_available_fn(std::declval<Type>()))>;

            template<typename Type>
            constexpr auto is_capacity_available_fn(Type&& arg)
                noexcept(noexcept(std::declval<remove_cv_ref_t<Type>>()))->decltype(arg.capacity());

            constexpr no_type_t is_capacity_available_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_capacity_available_v = 
                is_valid_type_v<decltype(is_capacity_available_fn(std::declval<Type>()))>;

            template<typename Type>
            constexpr auto is_shrink_to_fit_available_fn(Type&& arg)
                noexcept(noexcept(std::declval<remove_cv_ref_t<Type>>()))->decltype(arg.shrink_to_fit());

            constexpr no_type_t is_shrink_to_fit_available_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_shrink_to_fit_available_v = 
                is_valid_type_v<decltype(is_shrink_to_fit_available_fn(std::declval<Type>()))>;

            template<typename Type>
            constexpr auto is_size_available_fn(Type&& arg)
                noexcept(noexcept(std::declval<remove_cv_ref_t<Type>>()))->decltype(arg.size());

            constexpr no_type_t is_size_available_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_size_available_v = 
                is_valid_type_v<decltype(is_size_available_fn(std::declval<Type>()))>;

            template<typename Type>
            constexpr auto is_front_available_fn(Type&& arg)
                noexcept(noexcept(std::declval<remove_cv_ref_t<Type>>()))->decltype(arg.front());

            constexpr no_type_t is_front_available_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_front_available_v = 
                is_valid_type_v<decltype(is_front_available_fn(std::declval<Type>()))>;

            template<typename Type>
            constexpr auto is_back_available_fn(Type&& arg)
                noexcept(noexcept(std::declval<remove_cv_ref_t<Type>>()))->decltype(arg.back());

            constexpr no_type_t is_back_available_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_back_available_v = is_valid_type_v<decltype(is_back_available_fn(std::declval<Type>()))>;

            ///////////////////////////////////////////
            template<typename Type>
            constexpr auto is_begin_available_fn(Type&& arg)
                noexcept(noexcept(std::declval<remove_cv_ref_t<Type>>()))->decltype(arg.begin());

            constexpr no_type_t is_begin_available_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_begin_available_v = 
                is_valid_type_v<decltype(is_begin_available_fn(std::declval<Type>()))>;

            ///////////////////////////////////////////
            template<typename Type>
            constexpr auto is_end_available_fn(Type&& arg)
                noexcept(noexcept(std::declval<remove_cv_ref_t<Type>>()))->decltype(arg.end());

            constexpr no_type_t is_end_available_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_end_available_v = 
                is_valid_type_v<decltype(is_end_available_fn(std::declval<Type>()))>;

            ///////////////////////////////////////////
            template<typename Type>
            constexpr auto is_rbegin_available_fn(Type&& arg)
                noexcept(noexcept(std::declval<remove_cv_ref_t<Type>>()))->decltype(arg.rbegin());

            constexpr no_type_t is_rbegin_available_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_rbegin_available_v = 
                is_valid_type_v<decltype(is_rbegin_available_fn(std::declval<Type>()))>;

            ///////////////////////////////////////////
            template<typename Type>
            constexpr auto is_rend_available_fn(Type&& arg)
                noexcept(noexcept(std::declval<remove_cv_ref_t<Type>>()))->decltype(arg.rend());

            constexpr no_type_t is_rend_available_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_rend_available_v = 
                is_valid_type_v<decltype(is_rend_available_fn(std::declval<Type>()))>;
            
            ///////////////////////
            template<template<typename, typename...> class ContainerType,
                typename Type, typename... Types>
            constexpr auto is_push_front_valid_fn(ContainerType<Type, Types...>&& arg)
                noexcept(noexcept(std::declval<ContainerType<Type, Types...>>()))->decltype(arg.push_front(std::declval<Type>()));

            constexpr no_type_t is_push_front_valid_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_push_front_available_v = 
                is_valid_type_v<decltype(is_push_front_valid_fn(std::declval<Type>()))>;

            ////////////////////////////////////////////////
            template<template<typename, typename...> class ContainerType,
                typename Type, typename... Types>
            constexpr auto is_index_operator_valid_fn(ContainerType<Type, Types...>&& arg)
                noexcept(noexcept(std::declval<ContainerType<Type, Types...>>()))->decltype(arg.operator[]((size_t)1));

            constexpr no_type_t is_index_operator_valid_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_index_operator_available_v = 
                is_valid_type_v<decltype(is_index_operator_valid_fn(std::declval<Type>()))>;

            ////////////////////////////////////////////////
            template<template<typename, typename...> class ContainerType,
                typename Type, typename... Types>
            constexpr auto is_push_back_valid_fn(ContainerType<Type, Types...>&& arg)
                noexcept(noexcept(std::declval<ContainerType<Type, Types...>>()))->decltype(arg.push_back(std::declval<Type>()));

            constexpr no_type_t is_push_back_valid_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_push_back_available_v = 
                is_valid_type_v<decltype(is_push_back_valid_fn(std::declval<Type>()))>;

            /////////////////////////////////////////

            template<template<typename, typename...> class ContainerType,
                typename Type, typename... Types>
            constexpr auto is_erase_valid_fn(ContainerType<Type, Types...>&& arg)
                ->decltype(arg.erase(arg.cbegin()));

            constexpr no_type_t is_erase_valid_fn(...);

            template<typename Type>
            constexpr bool is_erase_available_v = 
                is_valid_type_v<decltype(is_erase_valid_fn(std::declval<Type>()))>;

            /////////////////////////////////////////

            template<template<typename, typename...> class ContainerType,
                typename Type, typename... Types>
            constexpr auto is_reserve_valid_fn(ContainerType<Type, Types...>&& arg)
                ->decltype(arg.reserve((size_t)0));

            constexpr no_type_t is_reserve_valid_fn(...);

            template<typename Type>
            constexpr bool is_reserve_available_v = 
                is_valid_type_v<decltype(is_reserve_valid_fn(std::declval<Type>()))>;
            
            ////////////////////////////            
            template<template<typename, typename...> class ContainerType,
                typename Type, typename... Types>
            constexpr auto is_insert_valid_fn(ContainerType<Type, Types...>&& arg)
                noexcept(noexcept(std::declval<ContainerType<Type, Types...>>()))->decltype(arg.insert(std::declval<Type>()));

            constexpr no_type_t is_insert_valid_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_insert_available_v = 
                is_valid_type_v<decltype(is_insert_valid_fn(std::declval<tpf::remove_cv_ref_t<Type>>()))>;

            /////////////////////////////////////////
            
            template<template<typename, typename...> class ContainerType,
                typename Type, typename... Types>
            constexpr auto is_insert_iterator_valid_fn(ContainerType<Type, Types...>&& arg)
                noexcept(noexcept(std::declval<ContainerType<Type, Types...>>()))->decltype(arg.insert(arg.cend(), std::declval<Type>()));

            constexpr no_type_t is_insert_iterator_valid_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_insert_iterator_available_v = 
                is_valid_type_v<decltype(is_insert_iterator_valid_fn(std::declval<tpf::remove_cv_ref_t<Type>>()))>;

            ////////////////////////////////////////////////
            template<template<typename, typename...> class ContainerType,
                typename Type, typename... Types>
            constexpr auto is_resize_valid_fn(ContainerType<Type, Types...>&& arg)
                noexcept(noexcept(std::declval<ContainerType<Type, Types...>>()))->decltype(arg.resize(std::declval<size_t>()));

            constexpr no_type_t is_resize_valid_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_resize_available_v = 
                is_valid_type_v<decltype(is_resize_valid_fn(std::declval<Type>()))>;

            ////////////////////////////////////////
            template<template<typename, typename...> class ContainerType,
                typename Type, typename... Types>
            constexpr auto is_emplace_front_valid_fn(ContainerType<Type, Types...>&& arg)
                noexcept(noexcept(std::declval<ContainerType<Type, Types...>>()))->decltype(arg.emplace_front(std::declval<Type>()));

            constexpr no_type_t is_emplace_front_valid_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_emplace_front_available_v = 
                is_valid_type_v<decltype(is_emplace_front_valid_fn(std::declval<Type>()))>;

            ////////////////////////////////////////////////
            template<template<typename, typename...> class ContainerType,
                typename Type, typename... Types>
            constexpr auto is_emplace_back_valid_fn(ContainerType<Type, Types...>&& arg)
                noexcept(noexcept(std::declval<ContainerType<Type, Types...>>()))->decltype(arg.emplace_back(std::declval<Type>()));

            constexpr no_type_t is_emplace_back_valid_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_emplace_back_available_v = 
                is_valid_type_v<decltype(is_emplace_back_valid_fn(std::declval<Type>()))>;

            ////////////////////////////////////////

            template<template<typename, typename...> class ContainerType,
                typename Type, typename... Types>
            constexpr auto is_emplace_valid_fn(ContainerType<Type, Types...>&& arg)
                noexcept(noexcept(std::declval<ContainerType<Type, Types...>>()))->decltype(arg.emplace(arg.cbegin(), std::declval<Type>()));

            constexpr no_type_t is_emplace_valid_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_emplace_available_v = 
                is_valid_type_v<decltype(is_emplace_valid_fn(std::declval<Type>()))>;

            ////////////////////////////////////////////

            template<typename Type>
            constexpr auto is_pop_front_available_fn(Type&& arg)
                noexcept(noexcept(std::declval<remove_cv_ref_t<Type>>()))->decltype(arg.pop_front());

            constexpr no_type_t is_pop_front_available_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_pop_front_available_v = 
                is_valid_type_v<decltype(is_pop_front_available_fn(std::declval<Type>()))>;
            
            template<typename Type>
            constexpr auto is_pop_back_available_fn(Type&& arg)
                noexcept(noexcept(std::declval<remove_cv_ref_t<Type>>()))->decltype(arg.pop_back());

            constexpr no_type_t is_pop_back_available_fn(...) noexcept;

            template<typename Type>
            constexpr bool is_pop_back_available_v = 
                is_valid_type_v<decltype(is_pop_back_available_fn(std::declval<Type>()))>;

            ///////////////////////////////////////////////////

            template<typename Type>
            constexpr bool is_container_type_v = 
                is_empty_available_v<Type> && is_size_available_v<Type> && 
                is_begin_available_v<Type>;
               
            template<typename Type, typename ReturnType = void>
            using enable_if_container_type_t = std::enable_if_t< is_container_type_v<remove_cv_ref_t<Type>>, ReturnType>;

            template<typename Type, typename... Types>
            struct is_same_st;

            template<typename Type>
            struct is_same_st<Type>
            {
                static constexpr bool value = true;
            };

            template<typename Type1, typename Type2>
            struct is_same_st<Type1, Type2>
            {
                static constexpr bool value = std::is_same_v<Type1, Type2>;
            };

            template<typename Type1, typename Type2, typename... Types>
            struct is_same_st<Type1, Type2, Types...>
            {
                static constexpr bool value = is_same_st<Type1, Type2>::value && 
                    is_same_st<Type2, Types...>::value;
            };

            template<typename Type>
            struct is_same_st<type_list_t<Type>>
            {
                static constexpr bool value = true;
            };

            template<typename Type1, typename Type2>
            struct is_same_st<type_list_t<Type1, Type2>>
            {
                static constexpr bool value = is_same_st<Type1, Type2>::value;
            };

            template<typename Type1, typename Type2, typename... Types>
            struct is_same_st<type_list_t<Type1, Type2, Types...>>
            {
                static constexpr bool value = 
                    is_same_st<Type1, Type2, Types...>::value;
            };

            template<typename Type, typename... Types>
            constexpr auto is_same_v = is_same_st<Type, Types...>::value;

            // test if TestType is in the list
            template<typename TestType, typename... Types>
            struct is_in_list_st
            {
                static constexpr bool value = false;
            };

            template<typename TestType>
            struct is_in_list_st<TestType>
            {
                static constexpr bool value = false;
            };

            template<typename TestType, typename Type>
            struct is_in_list_st<TestType, Type>
            {
                static constexpr bool value = std::is_same_v<TestType, Type>;
            };

            template<typename TestType, typename Type, typename... Types>
            struct is_in_list_st<TestType, Type, Types...>
            {
                static constexpr bool value = 
                    std::is_same_v<TestType, Type> 
                        || is_in_list_st<TestType, Types...>::value;
            };

            template<typename TestType>
            struct is_in_list_st<TestType, type_list_t<>>
            {
                static constexpr bool value = false;
            };

            template<typename TestType, typename Type>
            struct is_in_list_st<TestType, type_list_t<Type>>
            {
                static constexpr bool value = is_in_list_st<TestType, Type>::value;
            };

            template<typename TestType, typename Type, typename... Types>
            struct is_in_list_st<TestType, type_list_t<Type, Types...>>
            {
                static constexpr bool value = is_in_list_st<TestType, Type, Types...>::value;
            };

            template<typename TestType, typename... Types>
            constexpr bool is_in_list_v = is_in_list_st<TestType, Types...>::value;

            template<typename TypeList, typename... TestTypes>
            struct are_all_in_list_st;

            template<typename... Types>
            struct are_all_in_list_st<type_list_t<Types...>>
            {
                static constexpr bool value = false;
            };

            template<typename... Types, typename TestType>
            struct are_all_in_list_st<type_list_t<Types...>, TestType>
            {
                static constexpr bool value = is_in_list_v<TestType, type_list_t<Types...>>; 
            };

            template<typename... Types, typename TestType, typename... TestTypes>
            struct are_all_in_list_st<type_list_t<Types...>, TestType, TestTypes...>
            {
                static constexpr bool tmp_value = is_in_list_v<TestType, type_list_t<Types...>>; 

                static constexpr bool value = sizeof...(TestTypes) == 0 ? tmp_value :
                    tmp_value && are_all_in_list_st<type_list_t<Types...>, TestTypes...>::value;
            };

            template<typename... Types>
            struct are_all_in_list_st<type_list_t<Types...>, type_list_t<>>
            {
                static constexpr bool value = false;
            };

            template<typename... Types, typename TestType>
            struct are_all_in_list_st<type_list_t<Types...>, type_list_t<TestType>>
            {
                static constexpr bool value = is_in_list_v<TestType, type_list_t<Types...>>; 
            };

            template<typename... Types, typename TestType, typename... TestTypes>
            struct are_all_in_list_st<type_list_t<Types...>, type_list_t<TestType, TestTypes...>>
            {
                static constexpr bool value = 
                    are_all_in_list_st<type_list_t<Types...>, TestType, TestTypes...>::value;
            };

            template<typename TypeList, typename... TestTypes>
            constexpr auto are_all_in_list_v = are_all_in_list_st<TypeList, TestTypes...>::value;

            template<typename Type>
            constexpr auto is_integer_v = is_in_list_v<Type, integer_list_t>;
                        
            template<typename Type>
            constexpr auto is_unsigned_integer_v = is_in_list_v<Type, unsigned_integer_list_t>;
            
            template<typename Type>
            constexpr auto is_signed_integer_v = is_in_list_v<Type, signed_integer_list_t>;

            template<typename Type>
            constexpr auto is_integral_v = is_in_list_v<Type, integral_list_t>;

            template<typename Type>
            constexpr auto is_unsigned_integral_v = is_in_list_v<Type, unsigned_integral_list_t>;

            template<typename Type>
            constexpr auto is_signed_integral_v = is_in_list_v<Type, signed_integral_list_t>;

            template<typename Type>
            constexpr auto is_real_number_v = is_in_list_v<Type, real_number_list_t>;

            template<typename Type>
            constexpr auto is_numerical_number_v = is_in_list_v<Type, numerical_number_list_t>;

            template<typename... Types>
            constexpr auto are_integers_v = are_all_in_list_v<integer_list_t, Types...>;

            template<typename... Types>
            constexpr auto are_unsigned_integers_v = are_all_in_list_v<unsigned_integer_list_t, Types...>;
            
            template<typename... Types>
            constexpr auto are_signed_integers_v = are_all_in_list_v<signed_integer_list_t, Types...>;

            template<typename... Types>
            constexpr auto are_integrals_v = are_all_in_list_v<integral_list_t, Types...>;

            template<typename... Types>
            constexpr auto are_unsigned_integrals_v = are_all_in_list_v<unsigned_integral_list_t, Types...>;

            template<typename... Types>
            constexpr auto are_signed_integrals_v = are_all_in_list_v<signed_integral_list_t, Types...>;

            template<typename... Types>
            constexpr auto are_real_numbers_v = are_all_in_list_v<real_number_list_t, Types...>;

            template<typename... Types>
            constexpr auto are_numerical_numbers_v = are_all_in_list_v<numerical_number_list_t, Types...>;
           
            template<typename Type, typename ReturnType = Type>
			using enable_if_integral_t = 
				std::enable_if_t<is_integral_v<Type>, ReturnType>;

			template<typename Type, typename ReturnType = Type>
			using enable_if_signed_integral_t = 
				std::enable_if_t<is_signed_integral_v<Type>, ReturnType>;

			template<typename Type, typename ReturnType = Type>
			using enable_if_unsigned_integral_t = 
				std::enable_if_t<is_unsigned_integral_v<Type>, ReturnType>;

            template<typename Type, typename ReturnType = Type>
			using enable_if_integer_t = 
				std::enable_if_t<is_integer_v<Type>, ReturnType>;

            template<typename Type, typename ReturnType = Type>
			using enable_if_not_integer_t = 
				std::enable_if_t<!is_integer_v<Type>, ReturnType>;

			template<typename Type, typename ReturnType = Type>
			using enable_if_signed_integer_t = 
				std::enable_if_t<is_signed_integer_v<Type>, ReturnType>;

			template<typename Type, typename ReturnType = Type>
			using enable_if_unsigned_integer_t = 
				std::enable_if_t<is_unsigned_integer_v<Type>, ReturnType>;

            template<typename Type, typename ReturnType = Type>
			using enable_if_real_number_t = 
                std::enable_if_t<is_real_number_v<Type>, ReturnType>;

            template<typename Type, typename ReturnType = Type>
			using enable_if_numerical_number_t = 
                std::enable_if_t<is_numerical_number_v<Type>, ReturnType>;
	           
            template<typename Type, bool bInteger = false>
            struct make_signed_st
            {
                using type = no_type_t;
            };

            template<typename Type>
            struct make_signed_st<Type, true>
            {
                using type = std::make_signed_t<Type>;
            };

            template<typename Type>
            using make_signed_t = typename make_signed_st<Type, is_integer_v<Type>>::type;

            template<typename Type, bool bInteger = false>
            struct make_unsigned_st
            {
                using type = no_type_t;
            };

            template<typename Type>
            struct make_unsigned_st<Type, true>
            {
                using type = std::make_unsigned_t<Type>;
            };

            template<typename Type>
            using make_unsigned_t = typename make_unsigned_st<Type, is_integer_v<Type>>::type;

            template<typename Type, bool bIntegral = false>
            struct make_signed_integral_st
            {
                using type = no_type_t;
            };

            template<typename Type>
            struct make_signed_integral_st<Type, true>
            {
                using type = std::make_signed_t<Type>;
            };

            template<typename Type>
            using make_signed_integral_t = typename make_signed_integral_st<Type, is_integral_v<Type>>::type;

            template<typename Type, bool bIntegral = false>
            struct make_unsigned_integral_st
            {
                using type = no_type_t;
            };

            template<typename Type>
            struct make_unsigned_integral_st<Type, true>
            {
                using type = std::make_signed_t<Type>;
            };

            template<typename Type>
            using make_unsigned_integral_t = typename make_unsigned_integral_st<Type, is_integral_v<Type>>::type;

            template<typename Type, typename... Types>
            struct common_type_st;

            template<typename Type>
            struct common_type_st<Type>
            {
                using type = Type;
            };

            template<typename Type1, typename Type2>
            struct common_type_st<Type1, Type2>
            {
                using type =  is_operable_t<Type1, Type2>;
            };

            template<typename Type1, typename Type2, typename... Types>
            struct common_type_st<Type1, Type2, Types...>
            {
                using type =  is_operable_t<typename common_type_st<Type1, Type2>::type,
                    typename common_type_st<Type2, Types...>::type>;
            };

            template<>
            struct common_type_st<type_list_t<>>
            {
                using type = no_type_t;
            };

            template<typename Type>
            struct common_type_st<type_list_t<Type>>
            {
                using type = Type;
            };

            template<typename Type1, typename Type2>
            struct common_type_st<type_list_t<Type1, Type2>>
            {
                using type = typename common_type_st<Type1, Type2>::type;
            };

            template<typename Type1, typename Type2, typename... Types>
            struct common_type_st<type_list_t<Type1, Type2, Types...>>
            {
                using type = typename common_type_st<Type1, Type2, Types...>::type;
            };

            template<typename Type, typename... Types>
            using common_type_t = typename common_type_st<Type, Types...>::type;

            template<typename Type, typename... Types>
            constexpr auto common_type_v = is_valid_type_v<common_type_t<Type, Types...>>;
               
            template<typename... Types>
            struct select_first_type_st;

            template<>
            struct select_first_type_st<>
            {
                using type = no_type_t;
            };

            template<typename Type>
            struct select_first_type_st<Type>
            {
                using type = Type;
            };

            template<typename Type, typename... Types>
            struct select_first_type_st<Type, Types...>
            {
                using type = Type;
            };

            template<>
            struct select_first_type_st<type_list_t<>>
            {
                using type = no_type_t;
            };

            template<typename Type>
            struct select_first_type_st<type_list_t<Type>>
            {
                using type = Type;
            };

            template<typename Type, typename... Types>
            struct select_first_type_st<type_list_t<Type, Types...>>
            {
                using type = Type;
            };
        
            template<typename... Types>
            using select_first_type_t = typename select_first_type_st<Types...>::type;

            template<typename... Types>
            using first_type_t = select_first_type_t<Types...>;

            template<typename... Types>
            using front_type_t = select_first_type_t<Types...>;
            
            template<typename... Types>
            struct select_last_type_st;

            template<>
            struct select_last_type_st<>
            {
                using type = no_type_t;
            };

            template<typename Type>
            struct select_last_type_st<Type>
            {
                using type = Type;
            };

            template<typename Type, typename... Types>
            struct select_last_type_st<Type, Types...>
            {
                using type = std::conditional_t<sizeof...(Types)==0, 
                    Type, typename select_last_type_st<Types...>::type>;
            };

            template<>
            struct select_last_type_st<type_list_t<>>
            {
                using type = no_type_t;
            };

            template<typename Type>
            struct select_last_type_st<type_list_t<Type>>
            {
                using type = Type;
            };

            template<typename Type, typename... Types>
            struct select_last_type_st<type_list_t<Type, Types...>>
            {
                using type = std::conditional_t<sizeof...(Types)==0, 
                    Type, typename select_last_type_st<Types...>::type>;
            };

            template<typename... Types>
            using select_last_type_t = typename select_last_type_st<Types...>::type;
    
            template<typename... Types>
            using last_type_t = select_last_type_t<Types...>;

            template<typename... Types>
            using back_type_t = select_last_type_t<Types...>;

            template<auto SelectIndex, typename... Types>
            struct select_nth_type_st;

            template<auto SelectIndex>
            struct select_nth_type_st<SelectIndex>
            {
                using type = no_type_t;
            };

            template<typename Type, typename... Types>
            struct select_nth_type_st<0, Type, Types...>
            {
                using type = Type;
            };

            template<auto SelectIndex, typename Type, typename... Types>
            struct select_nth_type_st<SelectIndex, Type, Types...>
            {
                using type = std::conditional_t<SelectIndex==0, 
                    Type, typename select_nth_type_st<SelectIndex-1, Types...>::type>;
            };

            template<auto SelectIndex>
            struct select_nth_type_st<SelectIndex, type_list_t<>>
            {
                using type = no_type_t;
            };

            template<typename Type, typename... Types>
            struct select_nth_type_st<0, type_list_t<Type, Types...>>
            {
                using type = Type;
            };

            template<auto SelectIndex, typename Type, typename... Types>
            struct select_nth_type_st<SelectIndex, type_list_t<Type, Types...>>
            {
                using type = std::conditional_t<SelectIndex==0, 
                    Type, typename select_nth_type_st<SelectIndex-1, Types...>::type>;
            };

            template<typename Type>
            struct is_reference_wrapper_st
            {
                static constexpr bool value = false;
            };

            template<typename Type>
            struct is_reference_wrapper_st<std::reference_wrapper<Type>>
            {
                static constexpr bool value = true;
            };

            template<typename Type>
            constexpr auto is_reference_wrapper_v = 
                is_reference_wrapper_st<remove_cv_ref_t<Type>>::value;

            template<auto SelectIndex, typename... Types>
            using select_nth_type_t = typename select_nth_type_st<SelectIndex, Types...>::type;

            template<auto SelectIndex, typename... Types>
            using nth_type_t = select_nth_type_t<SelectIndex, Types...>;

            template<typename Type>
            using first_parameter_type_t = first_type_t<template_parameter_type_list_t<Type>>;

            template<typename Type>
            constexpr auto is_template_template_v = is_template_v<first_parameter_type_t<Type>>;

            template<typename Type>
            using last_parameter_type_t = last_type_t<template_parameter_type_list_t<Type>>;

            template<auto SelectIndex, typename Type>
            using nth_parameter_type_t = nth_type_t<SelectIndex, template_parameter_type_list_t<Type>>;
           
            template<typename ArgType, typename... Types>
            struct push_front_type_st
            {
                using type = type_list_t<ArgType, Types...>;
            };

            template<typename ArgType, typename... Types>
            struct push_front_type_st<ArgType, type_list_t<Types...>>
            {
                using type = type_list_t<ArgType, Types...>;
            };

            template<typename ArgType, typename... Types>
            using push_front_type_t = typename push_front_type_st<ArgType, Types...>::type;

            template<typename ArgType, typename... Types>
            struct push_back_type_st
            {
                using type = type_list_t<Types..., ArgType>;
            };
            
            template<typename ArgType, typename... Types>
            struct push_back_type_st<ArgType, type_list_t<Types...>>
            {
                using type = type_list_t<Types..., ArgType>;
            };

            template<typename ArgType, typename... Types>
            using push_back_type_t = typename push_back_type_st<ArgType, Types...>::type;

            template<typename ListType>
            struct pop_front_type_st;

            template<>
            struct pop_front_type_st<type_list_t<>>
            {
                using type = type_list_t<>;
            };

            template<typename Type, typename... Types>
            struct pop_front_type_st<type_list_t<Type, Types...>>
            {
                using type = type_list_t<Types...>;
            };

            template<typename... Types> 
            struct pop_front_wrapper_st
            {
                using type = typename pop_front_type_st<type_list_t<Types...>>::type;
            };

            template<typename... Types> 
            struct pop_front_wrapper_st<type_list_t<Types...>>
            {
                using type = typename pop_front_type_st<type_list_t<Types...>>::type;
            };
        
            template<typename... Types>
            using pop_front_type_t = typename pop_front_wrapper_st<Types...>::type;

            template<typename LeftList, typename RightList>
            struct pop_back_type_st;

            template<typename... LeftTypes>
            struct pop_back_type_st<type_list_t<LeftTypes...>, type_list_t<>>
            {
                using type = type_list_t<LeftTypes...>;
            };

            template<typename... LeftTypes, typename Type, typename... RightTypes>
            struct pop_back_type_st<type_list_t<LeftTypes...>, type_list_t<Type, RightTypes...>>
            {
                using left_list = push_back_type_t<Type, type_list_t<LeftTypes...>>;
                using right_list = type_list_t<RightTypes...>;

                using type = std::conditional_t<sizeof...(RightTypes) == 0,
                    type_list_t<LeftTypes...>, typename pop_back_type_st<left_list, right_list>::type>;
            };

            template<typename... Types>
            struct pop_back_type_wrapper_st
            {
                using type = typename pop_back_type_st<type_list_t<>, type_list_t<Types...>>::type;
            };

            template<typename... Types>
            struct pop_back_type_wrapper_st<type_list_t<Types...>>
            {
                using type = typename pop_back_type_st<type_list_t<>, type_list_t<Types...>>::type;
            };

            template<typename... Types>
            using pop_back_type_t = typename pop_back_type_wrapper_st<Types...>::type;

            //////////////////////////////////////////////////
            template<size_t FirstN, typename LeftList, typename RightList> struct first_n_types_list_st;

            template<>
            struct first_n_types_list_st<0, type_list_t<>, type_list_t<>>
            {
                using type = type_list_t<>;
            };

            template<typename RightType, typename... RightTypes>
            struct first_n_types_list_st<0, type_list_t<>, type_list_t<RightType, RightTypes...>>
            {
                using type = type_list_t<>;
            };

            template<typename... LeftTypes>
            struct first_n_types_list_st<1, type_list_t<LeftTypes...>, type_list_t<>>
            {
                using type = type_list_t<LeftTypes...>;
            };

            template<typename... LeftTypes, typename RightType, typename... RightTypes>
            struct first_n_types_list_st<1, type_list_t<LeftTypes...>, type_list_t<RightType, RightTypes...>>
            {
                using type = type_list_t<LeftTypes..., RightType>;
            };

            template<size_t FirstN, typename... LeftTypes, typename RightType, typename... RightTypes>
            struct first_n_types_list_st<FirstN, type_list_t<LeftTypes...>, type_list_t<RightType, RightTypes...>>
            {
                // when FirstN == 0
                using type_list_0 = type_list_t<LeftTypes...>;
                
                // when FirstN > 0, FirstN = 1, 2, 3...
                using type_list_1 =  std::conditional_t<FirstN == 1, type_list_t<LeftTypes..., RightType>,
                    typename first_n_types_list_st<FirstN-1, type_list_t<LeftTypes..., RightType>, type_list_t<RightTypes...>>::type>;

                using type = std::conditional_t<FirstN == 0, type_list_0, type_list_1>;
            };

            template<size_t FirstN, typename... Types> struct first_n_types_st;
            
            template<size_t FirstN, typename... RightTypes>
            struct first_n_types_st<FirstN, type_list_t<>, RightTypes...>
            {
                // static_assert(FirstN <= sizeof...(RightTypes), "FirstN out of range");

                using type = std::conditional_t<FirstN == 0, type_list_t<>,
                    std::conditional_t<FirstN >= sizeof...(RightTypes), type_list_t<RightTypes...>,
                    typename first_n_types_list_st<FirstN, type_list_t<>, type_list_t<RightTypes...>>::type>>;
            };

            template<size_t FirstN, typename... RightTypes>
            struct first_n_types_st<FirstN, type_list_t<>, type_list_t<RightTypes...>>
            {
                // static_assert(FirstN <= sizeof...(RightTypes), "FirstN out of range");

                using type = std::conditional_t<FirstN == 0, type_list_t<>,
                    std::conditional_t<FirstN >= sizeof...(RightTypes), type_list_t<RightTypes...>,
                    typename first_n_types_list_st<FirstN, type_list_t<>, type_list_t<RightTypes...>>::type>>;
            };

            template<size_t FirstN, typename... RightTypes>
            using first_n_types_t = typename first_n_types_st<FirstN, type_list_t<>, RightTypes...>::type;

            template<size_t FirstN, typename... RightTypes>
            using select_first_n_types_t = first_n_types_t<FirstN, RightTypes...>;

            ////////////////////////////////////////////////////////////////////////////////////////////////
            template<size_t LastN, typename LeftList, typename RightList> struct last_n_types_list_st;

            template<> 
            struct last_n_types_list_st<0, type_list_t<>, type_list_t<>>
            {
                using type = type_list_t<>;
            };

            template<typename LeftType, typename... LeftTypes> 
            struct last_n_types_list_st<0, type_list_t<LeftType, LeftTypes...>, type_list_t<>>
            {
                using type = type_list_t<>;
            };

            template<typename... RightTypes> 
            struct last_n_types_list_st<1, type_list_t<>, type_list_t<RightTypes...>>
            {
                using type = type_list_t<>;
            };

            template<typename LeftType, typename... LeftTypes, typename... RightTypes> 
            struct last_n_types_list_st<1, type_list_t<LeftType, LeftTypes...>, type_list_t<RightTypes...>>
            {
                using type = type_list_t<select_last_type_t<type_list_t<LeftType, LeftTypes...>>, RightTypes...>;
            };

            template<size_t LastN, typename LeftType, typename... LeftTypes, typename... RightTypes> 
            struct last_n_types_list_st<LastN, type_list_t<LeftType, LeftTypes...>, type_list_t<RightTypes...>>
            {
                // LastN == 0
                using type0 = type_list_t<RightTypes...>;

                using new_right = type_list_t<select_last_type_t<type_list_t<LeftType, LeftTypes...>>, RightTypes...>;
                using new_left = pop_back_type_t<type_list_t<LeftType, LeftTypes...>>;

                // LastN = 1, 2, 3
                using type1 = std::conditional_t<LastN == 1, new_right, 
                    typename last_n_types_list_st<LastN-1, new_left, new_right>::type>;

                using type = std::conditional_t<LastN==0, type0, type1>;
            };

            template<size_t LastN, typename... LeftTypes> 
            struct last_n_types_st
            {
                // static_assert(FirstN <= sizeof...(LeftTypes), "FirstN out of range");

                using type = std::conditional_t<LastN==0, type_list_t<>, 
                    std::conditional_t<LastN >= sizeof...(LeftTypes), type_list_t<LeftTypes...>, 
                    typename last_n_types_list_st<LastN, type_list_t<LeftTypes...>, type_list_t<>>::type>>;
            };

            template<size_t LastN, typename... LeftTypes> 
            struct last_n_types_st<LastN, type_list_t<LeftTypes...>>
            {
                // static_assert(FirstN <= sizeof...(LeftTypes), "FirstN out of range");

                using type = std::conditional_t<LastN==0, type_list_t<>, 
                    std::conditional_t<LastN >= sizeof...(LeftTypes), type_list_t<LeftTypes...>, 
                    typename last_n_types_list_st<LastN, type_list_t<LeftTypes...>, type_list_t<>>::type>>;
            };

            template<size_t LastN, typename... LeftTypes> 
            using last_n_types_t = typename last_n_types_st<LastN, LeftTypes...>::type;

            template<size_t LastN, typename... LeftTypes> 
            using select_last_n_types_t = last_n_types_t<LastN, LeftTypes...>;

            template<typename ArgType, typename... Types>
            struct is_type_in_list_st;

            template<typename ArgType>
            struct is_type_in_list_st<ArgType>
            {
                static constexpr bool value = false;
            };

            template<typename ArgType, typename Type, typename... RightTypes>
            struct is_type_in_list_st<ArgType, Type, RightTypes...>
            {
                static constexpr bool value = std::is_same_v<ArgType, Type> ? true :
                    is_type_in_list_st<ArgType, RightTypes...>::value;
            };

            template<typename ArgType>
            struct is_type_in_list_st<ArgType, type_list_t<>>
            {
                static constexpr bool value = false;
            };

            template<typename ArgType, typename Type, typename... RightTypes>
            struct is_type_in_list_st<ArgType, type_list_t<Type, RightTypes...>>
            {
                static constexpr bool value = is_type_in_list_st<ArgType, Type, RightTypes...>::value;
            };

            template<typename ArgType, typename... Types>
            constexpr auto is_type_in_list_v = is_type_in_list_st<ArgType, Types...>::value;

            template<typename TestType, typename TypeList, typename ReturnType = TestType>
            using enable_if_in_list_t = std::enable_if_t<is_type_in_list_v<TestType, TypeList>, ReturnType>;

            template<typename TestTypeList, typename TypeList, typename ReturnType = void>
            using enable_if_all_in_list_t = std::enable_if_t<are_all_in_list_v<TypeList, TestTypeList>, ReturnType>;

            template<typename ListType, typename... Types>
            struct unique_types_st;

            template<typename... Types>
            struct unique_types_st<type_list_t<Types...>>
            {
                using type = type_list_t<Types...>;
            };

            template<typename... Types, typename Type>
            struct unique_types_st<type_list_t<Types...>, Type>
            {
                using list = type_list_t<Types...>;

                using type = std::conditional_t<is_type_in_list_v<Type, list>,
                    list, type_list_t<Types..., Type>>;
            };

            template<typename... Types, typename Type, typename... RightTypes>
            struct unique_types_st<type_list_t<Types...>, Type, RightTypes...>
            {
                using list = typename unique_types_st<type_list_t<Types...>, Type>::type;

                using type = typename unique_types_st<list, RightTypes...>::type;
            };

            template<typename... Types, typename... RightTypes>
            struct unique_types_st<type_list_t<Types...>, type_list_t<RightTypes...>>
            {
                using type = typename unique_types_st<type_list_t<Types...>, RightTypes...>::type;
            };

            template<typename... Types>
            using unique_types_t = typename unique_types_st<type_list_t<>, Types...>::type;

            template<typename Type, typename... Types>
            struct to_variant_st
            {
                using type = std::variant<Type, Types...>;
            };

            template<typename Type, typename... Types>
            struct to_variant_st<type_list_t<Type, Types...>>
            {
                using type = std::variant<Type, Types...>;
            };      

            template<typename Type, typename... Types>
            using to_variant_t = typename to_variant_st<Type, Types...>::type;    

            template<typename... Types>
            struct to_tuple_st
            {
                using type = std::tuple<Types...>;
            };

            template<typename... Types>
            struct to_tuple_st<type_list_t<Types...>>
            {
                using type = std::tuple<Types...>;
            };      

            template<typename... Types>
            using to_tuple_t = typename to_tuple_st<Types...>::type;    

            template<typename ArgType, typename RightList>
            struct prepend_type_st;

            template<typename ArgType, typename... RightTypes>
            struct prepend_type_st<ArgType, type_list_t<RightTypes...>>
            {
                using type = type_list_t<ArgType, RightTypes...>;
            };

            template<typename... ArgTypes, typename... RightTypes>
            struct prepend_type_st<type_list_t<ArgTypes...>, type_list_t<RightTypes...>>
            {
                using type = type_list_t<ArgTypes..., RightTypes...>;
            };

            template<typename ArgType, typename RightList>
            using prepend_type_t = typename prepend_type_st<ArgType, RightList>::type;

            template<typename LeftList, typename RightList>
            struct append_type_st;

            template<typename ArgType, typename... RightTypes>
            struct append_type_st<ArgType, type_list_t<RightTypes...>>
            {
                using type = type_list_t<RightTypes..., ArgType>;
            };

            template<typename... ArgTypes, typename... RightTypes>
            struct append_type_st<type_list_t<ArgTypes...>, type_list_t<RightTypes...>>
            {
                using type = type_list_t<RightTypes..., ArgTypes...>;
            };

            template<typename ArgType, typename RightList>
            using append_type_t = typename append_type_st<ArgType, RightList>::type;

            template<typename LeftList, typename... Types>
            struct union_type_st;
            
            template<typename... Types>
            struct union_type_st< type_list_t<Types...> >
            {
                using type = type_list_t<Types...>;
            };

            template<typename... Types, typename Type>
            struct union_type_st< type_list_t<Types...>, Type>
            {
                using list = type_list_t<Types...>;

                using type = std::conditional_t<is_type_in_list_v<Type, list>,
                    list, type_list_t<Types..., Type>>;
            };

            template<typename... Types, typename Type, typename... RightTypes>
            struct union_type_st<type_list_t<Types...>, Type, RightTypes...>
            {
                using list = typename union_type_st<type_list_t<Types...>, Type>::type;

                using type = std::conditional_t<sizeof...(RightTypes)==0,
                    list, typename union_type_st<list, RightTypes...>::type>;
            };

            template<typename ArgType, typename... Types>
            struct union_type_st<ArgType, type_list_t<Types...>>
            {
                using list = type_list_t<Types...>;
                using type = std::conditional_t<is_in_list_v<ArgType, list>,
                    list, type_list_t<ArgType, Types...>>;
            };

            template<typename... Types>
            struct union_type_st<type_list_t<Types...>, type_list_t<>>
            {
                using type = type_list_t<Types...>;
            };

            template<typename... Types, typename Type>
            struct union_type_st< type_list_t<Types...>, type_list_t<Type>>
            {
                using type = typename union_type_st<type_list_t<Types...>, Type>::type;
            };

            template<typename... Types, typename Type, typename... RightTypes>
            struct union_type_st<type_list_t<Types...>, type_list_t<Type, RightTypes...>>
            {
                using type = typename union_type_st<type_list_t<Types...>, Type, RightTypes...>::type;
            };

            template<typename LeftList, typename RightList>
            using union_type_t = typename union_type_st<LeftList, RightList>::type;

            template<typename LeftType, typename... Types>
            struct intersection_type_st;

            template<typename... Types>
            struct intersection_type_st<type_list_t<Types...>>
            {
                using type = type_list_t<Types...>;
            };

            template<typename... Types, typename Type>
            struct intersection_type_st<type_list_t<Types...>, Type>
            {
                using list = type_list_t<Types...>;

                using type = std::conditional_t<is_type_in_list_v<Type, list>,
                    type_list_t<Type>, type_list_t<>>;
            };

            template<typename... Types, typename Type, typename... RightTypes>
            struct intersection_type_st<type_list_t<Types...>, Type, RightTypes...>
            {
                using left_list = type_list_t<Types...>;
                using list = typename intersection_type_st<left_list, Type>::type;

                using type = std::conditional_t<sizeof...(RightTypes) == 0,
                    list, append_type_t<list, typename intersection_type_st<left_list, RightTypes...>::type>>;
            };
            
            template<typename... Types>
            struct intersection_type_st<type_list_t<Types...>, type_list_t<>>
            {
                using type = type_list_t<Types...>;
            };

            template<typename... Types, typename Type>
            struct intersection_type_st<type_list_t<Types...>, type_list_t<Type>>
            {
                using type = typename intersection_type_st<type_list_t<Types...>, Type>::type;
            };

            template<typename... Types, typename Type, typename... RightTypes>
            struct intersection_type_st<type_list_t<Types...>, type_list_t<Type, RightTypes...>>
            {
                using type = typename intersection_type_st<type_list_t<Types...>, Type, RightTypes...>::type;
            };

            template<typename LeftList, typename RightList>
            using intersection_type_t = typename intersection_type_st<LeftList, RightList>::type;

            template<typename ArgType, typename... Types>
            struct remove_type_st;

            template<typename ArgType>
            struct remove_type_st<ArgType>
            {
                using type = type_list_t<>;
            };

            template<typename ArgType, typename Type>
            struct remove_type_st<ArgType, Type>
            {
                using type = std::conditional_t<std::is_same_v<ArgType, Type>,
                    type_list_t<>, type_list_t<Type>>;
            };

            template<typename ArgType, typename Type, typename... RightTypes>
            struct remove_type_st<ArgType, Type, RightTypes...>
            {
                using list = typename remove_type_st<ArgType, Type>::type;

                using type = std::conditional_t<sizeof...(RightTypes) == 0,
                    list, prepend_type_t<list, typename remove_type_st<ArgType, RightTypes...>::type>>;
            };

            template<typename ArgType>
            struct remove_type_st<ArgType, type_list_t<>>
            {
                using type = type_list_t<>;
            };

            template<typename ArgType, typename Type>
            struct remove_type_st<ArgType, type_list_t<Type>>
            {
                using type = typename remove_type_st<ArgType, Type>::type;
            };

            template<typename ArgType, typename Type, typename... RightTypes>
            struct remove_type_st<ArgType, type_list_t<Type, RightTypes...>>
            {
                using type = typename remove_type_st<ArgType, Type, RightTypes...>::type;
            };

            template<typename ArgType, typename... Types>
            struct remove_type_wrapper_st
            {
                using type = typename remove_type_st<ArgType, type_list_t<Types...>>::type;
            };

            template<typename ArgType, typename... Types>
            struct remove_type_wrapper_st<ArgType, type_list_t<Types...>>
            {
                using type = typename remove_type_st<ArgType, type_list_t<Types...>>::type;
            };

            template<typename ArgType, typename... Types>
            using remove_type_t = 
                typename remove_type_wrapper_st<ArgType, Types...>::type;

            template<typename LeftList, typename... Types>
            struct difference_type_st;

            template<typename... Types>
            struct difference_type_st<type_list_t<Types...>>
            {
                using type = type_list_t<Types...>;
            };

            template<typename... Types, typename Type>
            struct difference_type_st<type_list_t<Types...>, Type>
            {
                using type = remove_type_t<Type, type_list_t<Types...>>;
            };

            template<typename... Types, typename Type, typename... RightTypes>
            struct difference_type_st<type_list_t<Types...>, Type, RightTypes...>
            {
                using list = typename difference_type_st<type_list_t<Types...>, Type>::type;

                using type = std::conditional_t<sizeof...(RightTypes) == 0,
                    list, typename difference_type_st<list, RightTypes...>::type>;
            };

            template<typename... Types>
            struct difference_type_st<type_list_t<Types...>, type_list_t<>>
            {
                using type = type_list_t<Types...>;
            };

            template<typename... Types, typename Type>
            struct difference_type_st<type_list_t<Types...>, type_list_t<Type>>
            {
                using type = typename difference_type_st<type_list_t<Types...>, Type>::type;
            };

            template<typename... Types, typename Type, typename... RightTypes>
            struct difference_type_st<type_list_t<Types...>, type_list_t<Type, RightTypes...>>
            {
                using type = typename difference_type_st<type_list_t<Types...>, Type, RightTypes...>::type;
            };

            template<typename LeftList, typename RightList>
            using difference_type_t = typename difference_type_st<LeftList, RightList>::type;

            template<typename NewType, typename OldType, typename... Types>
            struct replace_type_st;

            template<typename NewType, typename OldType>
            struct replace_type_st<NewType, OldType>
            {
                using type = type_list_t<>;
            };

            template<typename NewType, typename OldType, typename Type>
            struct replace_type_st<NewType, OldType, Type>
            {
                using type = std::conditional_t< std::is_same_v<OldType, Type>,
                    type_list_t<NewType>, type_list_t<Type>>;             
            };

            template<typename NewType, typename OldType, typename Type, typename... RightTypes>
            struct replace_type_st<NewType, OldType, Type, RightTypes...>
            {
                using list = typename replace_type_st<NewType, OldType, Type>::type;

                using type = std::conditional_t< sizeof...(RightTypes), list,
                    prepend_type_t<list, typename replace_type_st<NewType, OldType, RightTypes...>::type>>;        
            };

            template<typename NewType, typename OldType>
            struct replace_type_st<NewType, OldType, type_list_t<>>
            {
                using type = type_list_t<>;
            };

            template<typename NewType, typename OldType, typename Type>
            struct replace_type_st<NewType, OldType, type_list_t<Type>>
            {
                using type = typename replace_type_st<NewType, OldType, Type>::type;             
            };

            template<typename NewType, typename OldType, typename Type, typename... RightTypes>
            struct replace_type_st<NewType, OldType, type_list_t<Type, RightTypes...>>
            {
                using type = typename replace_type_st<NewType, OldType, Type, RightTypes...>::type;        
            };

            template<typename NewType, typename OldType, typename TypeList>
            using replace_type_t =  typename replace_type_st<NewType, OldType, TypeList>::type;

            template<typename Type, typename... Types>
            struct is_type_list_equivalent_st;

            template<typename... LeftTypes>
            struct is_type_list_equivalent_st<type_list_t<LeftTypes...>>
            {
                static constexpr bool value = true; 
            };

            template<typename... LeftTypes, typename Type>
            struct is_type_list_equivalent_st<type_list_t<LeftTypes...>, Type>
            {
                static constexpr bool value = 
                    is_type_in_list_v<Type, type_list_t<LeftTypes...>>; 
            };

            template<typename... LeftTypes, typename Type, typename... RightTypes>
            struct is_type_list_equivalent_st<type_list_t<LeftTypes...>, Type, RightTypes...>
            {
                static constexpr bool tmp_value = 
                    is_type_list_equivalent_st< type_list_t<LeftTypes...>, Type>::value;

                static constexpr bool value = sizeof...(RightTypes)==0 ? tmp_value :
                    tmp_value && is_type_list_equivalent_st<type_list_t<LeftTypes...>, RightTypes...>::value;
            };

            template<typename... LeftTypes, typename... RightTypes>
            struct is_type_list_equivalent_st<type_list_t<LeftTypes...>, type_list_t<RightTypes...>>
            {
                static constexpr bool value = sizeof...(LeftTypes) != sizeof...(RightTypes) ?
                    false : is_type_list_equivalent_st<type_list_t<LeftTypes...>, RightTypes...>::value;
            };

            template<typename LeftList, typename RightList>
            constexpr auto is_type_list_equivalent_v = is_type_list_equivalent_st<LeftList, RightList>::value;

        } // end of namespace hidden

        template<typename Type>
        constexpr auto is_reference_wrapper_v = hidden::is_reference_wrapper_v<Type>;

        /**
         * @brief Test if all types are the same
         * 
         * @tparam Type for the first type
         * @tparam Types for the rest of types
         * 
         */
        template<typename Type, typename... Types>
        constexpr auto is_same_v = hidden::is_same_v<Type, Types...>;
        
        template<typename Type, typename... Types>
        using flat_type_list_t = tpf::types::type_list_t<decay_remove_cv_ref_t<Type>, decay_remove_cv_ref_t<Types>...>;

        template<typename Type, typename... Types>
        constexpr auto is_same_flat_v = is_same_v<flat_type_list_t<Type, Types...>>;

        template<typename ReturnType, typename Type, typename... Types>
        using enable_if_same_t = std::enable_if_t< is_same_v<Type, Types...>, ReturnType>;

        template<typename ReturnType, typename Type, typename... Types>
        using enable_if_same_flat_t = std::enable_if_t< is_same_flat_v<Type, Types...>, ReturnType>;


        /**
         * @brief test if TestType exists in Types...
         * 
         * @tparam TestType for type to test its existance
         * @tparam Types for type list to test against
         * 
         */
        template<typename TestType, typename... Types>
        constexpr auto is_in_list_v = hidden::is_in_list_v<TestType, Types...>;

        template<typename Type>
        constexpr auto is_integer_v = hidden::is_integer_v<Type>;

        template<typename Type>
        constexpr auto is_signed_integer_v = hidden::is_signed_integer_v<Type>;

        template<typename Type>
        constexpr auto is_unsigned_integer_v = hidden::is_unsigned_integer_v<Type>;

        template<typename Type>
        constexpr auto is_integral_v = hidden::is_integral_v<Type>;

        template<typename Type>
        constexpr auto is_signed_integral_v = hidden::is_signed_integral_v<Type>;

        template<typename Type>
        constexpr auto is_unsigned_integral_v = hidden::is_unsigned_integral_v<Type>;

        template<typename Type>
        constexpr auto is_real_number_v = hidden::is_real_number_v<Type>;

        template<typename Type>
        constexpr auto is_numerical_number_v = hidden::is_numerical_number_v<Type>;

        template<typename TypeList, typename... TestTypes>
        constexpr auto are_all_in_list_v = hidden::are_all_in_list_v<TypeList, TestTypes...>;

        template<typename... Types>
        constexpr auto are_integers_v = hidden::are_integers_v<Types...>;

        template<typename... Types>
        constexpr auto are_signed_integers_v = hidden::are_signed_integers_v<Types...>;

        template<typename... Types>
        constexpr auto are_unsigned_integers_v = hidden::are_unsigned_integers_v<Types...>;

        template<typename... Types>
        constexpr auto are_integrals_v = hidden::are_integrals_v<Types...>;

        template<typename... Types>
        constexpr auto are_signed_integrals_v = hidden::are_signed_integrals_v<Types...>;

        template<typename... Types>
        constexpr auto are_unsigned_integrals_v = hidden::are_unsigned_integrals_v<Types...>;

        template<typename... Types>
        constexpr auto are_real_numbers_v = hidden::are_real_numbers_v<Types...>;

        template<typename... Types>
        constexpr auto are_numerical_numbers_v = hidden::are_numerical_numbers_v<Types...>;
      
        template<typename Type, typename ReturnType = Type>
        using enable_if_integral_t = hidden::enable_if_integral_t<Type, ReturnType>;
        
        template<typename Type, typename ReturnType = Type>
        using enable_if_signed_integral_t = hidden::enable_if_signed_integral_t<Type, ReturnType>;
        
        template<typename Type, typename ReturnType = Type>
        using enable_if_unsigned_integral_t = hidden::enable_if_unsigned_integral_t<Type, ReturnType>;
        
        template<typename Type, typename ReturnType = Type>
        using enable_if_integer_t = hidden::enable_if_integer_t<Type, ReturnType>;

        template<typename Type, typename ReturnType = Type>
        using enable_if_not_integer_t = hidden::enable_if_not_integer_t<Type, ReturnType>;
        
        template<typename Type, typename ReturnType = Type>
        using enable_if_signed_integer_t = hidden::enable_if_signed_integer_t<Type, ReturnType>;
        
        template<typename Type, typename ReturnType = Type>
        using enable_if_unsigned_integer_t = hidden::enable_if_unsigned_integer_t<Type, ReturnType>;

        template<typename Type, typename ReturnType = Type>
        using enable_if_real_number_t = hidden::enable_if_real_number_t<Type, ReturnType>;
        
        template<typename Type, typename ReturnType = Type>
        using enable_if_numerical_number_t = hidden::enable_if_numerical_number_t<Type, ReturnType>;
        
        template<typename Type>
        using make_unsigned_t = hidden::make_unsigned_t<Type>;

        template<typename Type>
        using make_signed_t = hidden::make_signed_t<Type>;

        template<typename Type>
        using make_unsigned_integral_t = hidden::make_unsigned_integral_t<Type>;

        template<typename Type>
        using make_signed_integral_t = hidden::make_signed_integral_t<Type>;

        template<typename Type1, typename Type2>
        constexpr auto is_operable_v = hidden::is_operable_v<Type1, Type2>;

        template<typename Type, typename... Types>
        using common_type_t = hidden::common_type_t<Type, Types...>;

        template<typename Type, typename... Types>
        constexpr auto common_type_v = hidden::common_type_v<Type, Types...>;

        template<typename Type>
        constexpr bool is_empty_available_v = hidden::is_empty_available_v<Type>;

        template<typename Type>
        constexpr bool is_capacity_available_v = hidden::is_capacity_available_v<Type>;

        template<typename Type>
        constexpr bool is_shrink_to_fit_available_v = hidden::is_shrink_to_fit_available_v<Type>;

        template<typename Type>
        constexpr bool is_index_operator_available_v = hidden::is_index_operator_available_v<remove_cv_ref_t<Type>>;

        template<typename Type>
        constexpr bool is_push_front_available_v = hidden::is_push_front_available_v<remove_cv_ref_t<Type>>;

        template<typename Type>
        constexpr bool is_push_back_available_v = hidden::is_push_back_available_v<remove_cv_ref_t<Type>>;

        template<typename Type>
        constexpr bool is_begin_available_v = hidden::is_begin_available_v<remove_cv_ref_t<Type>>;

        template<typename Type>
        constexpr bool is_end_available_v = hidden::is_end_available_v<remove_cv_ref_t<Type>>;

        template<typename Type>
        constexpr bool is_rbegin_available_v = hidden::is_rbegin_available_v<remove_cv_ref_t<Type>>;

        template<typename Type>
        constexpr bool is_rend_available_v = hidden::is_rend_available_v<remove_cv_ref_t<Type>>;

        template<typename Type>
        constexpr bool is_erase_available_v = hidden::is_erase_available_v<remove_cv_ref_t<Type>>;

        template<typename Type>
        constexpr bool is_resize_available_v = hidden::is_resize_available_v<remove_cv_ref_t<Type>>;

        template<typename Type>
        constexpr bool is_reserve_available_v = hidden::is_reserve_available_v<remove_cv_ref_t<Type>>;
        
        template<typename Type>
        constexpr bool is_size_available_v = hidden::is_size_available_v<remove_cv_ref_t<Type>>;

        template<typename Type>
        constexpr bool is_insert_available_v = hidden::is_insert_available_v<Type>; 

        template<typename Type>
        constexpr bool is_insert_iterator_available_v = hidden::is_insert_iterator_available_v<Type>; 

        template<typename Type>
        constexpr bool is_emplace_front_available_v = hidden::is_emplace_front_available_v<remove_cv_ref_t<Type>>;

        template<typename Type>
        constexpr bool is_emplace_back_available_v = hidden::is_emplace_back_available_v<remove_cv_ref_t<Type>>;

        template<typename Type>
        constexpr bool is_emplace_available_v = hidden::is_emplace_available_v<remove_cv_ref_t<Type>>;

        template<typename Type>
        constexpr bool is_front_available_v = hidden::is_front_available_v<remove_cv_ref_t<Type>>;

        template<typename Type>
        constexpr bool is_back_available_v = hidden::is_back_available_v<remove_cv_ref_t<Type>>;

        template<typename Type>
        constexpr bool is_pop_front_available_v = hidden::is_pop_front_available_v<remove_cv_ref_t<Type>>;

        template<typename Type>
        constexpr bool is_pop_back_available_v = hidden::is_pop_back_available_v<remove_cv_ref_t<Type>>;

        template<typename Type>
        constexpr bool is_container_type_v = hidden::is_container_type_v<remove_cv_ref_t<Type>>;

        template<typename Type, typename ReturnType = void>
        using enable_if_container_type_t = hidden::enable_if_container_type_t<Type, ReturnType>;

        template<typename... Types>
        using select_first_type_t = hidden::select_first_type_t<Types...>;

        template<typename... Types>
        using first_type_t = hidden::first_type_t<Types...>;

        template<typename... Types>
        using front_type_t = hidden::front_type_t<Types...>;

        template<typename... Types>
        using select_last_type_t = hidden::select_last_type_t<Types...>;

        template<typename... Types>
        using last_type_t = hidden::last_type_t<Types...>;

        template<typename... Types>
        using back_type_t = hidden::back_type_t<Types...>;

        template<auto SelectIndex, typename... Types>
        using select_nth_type_t = hidden::select_nth_type_t<SelectIndex, Types...>;

        template<auto SelectIndex, typename... Types>
        using nth_type_t = hidden::nth_type_t<SelectIndex, Types...>;

        template<typename Type>
        using first_parameter_type_t = hidden::first_parameter_type_t<Type>;

        template<typename Type>
        using last_parameter_type_t = hidden::last_type_t<Type>;

        template<auto SelectIndex, typename Type>
        using nth_parameter_type_t = hidden::nth_type_t<SelectIndex, Type>;

        template<typename ArgType, typename... Types>
        using push_front_type_t = hidden::push_front_type_t<ArgType, Types...>;

        template<typename ArgType, typename... Types>
        using push_back_type_t = hidden::push_back_type_t<ArgType, Types...>;

        template<typename... Types>
        using pop_front_type_t = hidden::pop_front_type_t<Types...>;

        template<typename... Types>
        using pop_back_type_t = hidden::pop_back_type_t<Types...>;

        template<size_t FirstN, typename... Types>
        using first_n_types_t = hidden::first_n_types_t<FirstN, Types...>;

        template<size_t FirstN, typename... Types>
        using select_first_n_types_t = hidden::select_first_n_types_t<FirstN, Types...>;

        template<size_t LastN, typename... Types> 
        using last_n_types_t = hidden::last_n_types_t<LastN, Types...>;

        template<size_t LastN, typename... Types> 
        using select_last_n_types_t = hidden::select_last_n_types_t<LastN, Types...>;

        template<typename ArgType, typename... Types>
        constexpr auto is_type_in_list_v = hidden::is_type_in_list_v<ArgType, Types...>;

        template<typename... Types>
        using unique_types_t = hidden::unique_types_t<Types...>;

        template<typename Type, typename... Types>
        using to_variant_t = hidden::to_variant_t<unique_types_t<Type, Types...>>;

        template<typename... Types>
        using to_tuple_t = hidden::to_tuple_t<Types...>;

        template<typename ArgType, typename RightList>
        using prepend_type_t = hidden::prepend_type_t<ArgType, RightList>;

        template<typename ArgType, typename RightList>
        using append_type_t = hidden::append_type_t<ArgType, RightList>;

        template<typename LeftList, typename RightList>
        using union_type_t = hidden::union_type_t<unique_types_t<LeftList>, unique_types_t<RightList>>;

        template<typename LeftList, typename RightList>
        using intersection_type_t = hidden::intersection_type_t<unique_types_t<LeftList>, unique_types_t<RightList>>;

        template<typename ArgType, typename... Types>
        using remove_type_t = hidden::remove_type_t<ArgType, Types...>;

        template<typename LeftList, typename RightList>
        using difference_type_t = hidden::difference_type_t<LeftList, RightList>;

        template<typename NewType, typename OldType, typename TypeList>
        using replace_type_t =  hidden::replace_type_t<NewType, OldType, TypeList>;

        template<typename LeftList, typename RightList>
        constexpr auto is_type_list_equivalent_v = 
            hidden::is_type_list_equivalent_v<unique_types_t<LeftList>, unique_types_t<RightList>>;

        //////////////////////////////////////////////////////////////////////////////////////////
        namespace hidden
        {
            template<typename... Types>
            struct arg_list{ };

            template<typename T>
            struct st_is_arg_list 
            {
                using type = T;
            };

            template<typename... Ts>
            struct st_is_arg_list<arg_list<Ts...>>
            {
                using type = type_list_t<Ts...>;
            };

            template<typename Type>
            using arg_to_type_t = typename st_is_arg_list<Type>::type;

            template<typename CallbackType, typename... ArgTypes> struct st_is_invocable;
            
            template<typename CallbackType, typename... ArgTypes>
            struct st_is_invocable<CallbackType, arg_list<ArgTypes...>>
            {
                static constexpr bool value = std::is_invocable_v<CallbackType, ArgTypes...>;
            };

        } // end of namespace hidden

        template<typename CallbackType, typename... Types>
        constexpr bool is_invocable_v = hidden::st_is_invocable<CallbackType, Types...>::value;

        namespace hidden
        {
            template<typename CallbackType, typename... Types> struct st_is_callable;
            
            template<typename CallbackType, typename... CallableTypes, typename... NonCallableTypes> 
            struct st_is_callable<CallbackType, type_list_t<CallableTypes...>, type_list_t<NonCallableTypes...>>
            {
                private:
                    static constexpr bool value = is_invocable_v<CallbackType>;

                    using callable_list = type_list_t<CallableTypes...>;
                    using non_callable_list = type_list_t<NonCallableTypes...>;
                
                public:

                using callables = std::conditional_t<value, types::push_back_type_t<void, callable_list>, callable_list>;
                using non_callables = std::conditional_t<!value, types::push_back_type_t<void, non_callable_list>, non_callable_list>;
            };

            template<typename CallbackType, typename... CallableTypes, typename... NonCallableTypes, typename Type> 
            struct st_is_callable<CallbackType, type_list_t<CallableTypes...>, type_list_t<NonCallableTypes...>, Type>
            {
                private:
                    static constexpr bool value = is_invocable_v<CallbackType, Type>;
                    using callable_list = type_list_t<CallableTypes...>;
                    using non_callable_list = type_list_t<NonCallableTypes...>;

                public:

                using callables = std::conditional_t<value, types::push_back_type_t<Type, callable_list>, callable_list>;
                using non_callables = std::conditional_t<!value, types::push_back_type_t<Type, non_callable_list>, non_callable_list>;
            };

            template<typename CallbackType, typename... CallableTypes, typename... NonCallableTypes, typename Type, typename... Types> 
            struct st_is_callable<CallbackType, type_list_t<CallableTypes...>, type_list_t<NonCallableTypes...>, Type, Types...>
            {
                private:
                    static constexpr bool value = is_invocable_v<CallbackType, Type>;

                    using callable_list = type_list_t<CallableTypes...>;
                    using non_callable_list = type_list_t<NonCallableTypes...>;

                    using callables_tmp = std::conditional_t<value, types::push_back_type_t<Type, callable_list>, callable_list>;
                    using non_callables_tmp = std::conditional_t<!value, types::push_back_type_t<Type, non_callable_list>, non_callable_list>;

                    using base_type = st_is_callable<CallbackType, callables_tmp, non_callables_tmp, Types...>;
                public:

                using callables = typename base_type::callables;
                using non_callables = typename base_type::non_callables;
            };

            template<typename CallbackType, typename... CallableTypes, typename... NonCallableTypes, typename... Types> 
            struct st_is_callable<CallbackType, type_list_t<CallableTypes...>, type_list_t<NonCallableTypes...>, type_list_t<Types...>>
            {
                using base_type = st_is_callable<CallbackType, type_list_t<CallableTypes...>, type_list_t<NonCallableTypes...>, Types...>;

                using callables = typename base_type::callables;
                using non_callables = typename base_type::non_callables;
            };

            template<typename... Types>  struct st_build_arg_types;

            template<typename... Heads, typename... Tails>
            struct st_build_arg_types<type_list_t<Heads...>, type_list_t<Tails...>>
            {
                using type = type_list_t<hidden::arg_list<Heads, Tails...>...>;
            };

            template<typename... Types> struct st_arg_to_type_list;

            template<typename... Types>
            struct st_arg_to_type_list<arg_list<Types...>>
            {
                using type = type_list_t<Types...>;
            };

            template<typename... Types>
            struct st_arg_to_type_list<type_list_t<Types...>>
            {
                using type = type_list_t<arg_to_type_t<Types>...>;
            };

        } // end of namespace hidden

        template<typename... Types>
        using arg_to_type_list_t = typename hidden::st_arg_to_type_list<Types...>::type;

        template<typename Heads, typename Tails>
        using arg_list_t = typename hidden::st_build_arg_types<Heads, Tails>::type;

        template<typename CallbackType, typename... Types>
        using callable_list_t = typename hidden::st_is_callable<CallbackType, type_list_t<>, type_list_t<>, Types...>::callables;

        template<typename CallbackType, typename... Types>
        using non_callable_list_t = typename hidden::st_is_callable<CallbackType, type_list_t<>, type_list_t<>, Types...>::non_callables;

        template<typename CallbackType, typename... Types>
        constexpr bool is_all_callable_v = types::type_count_v<callable_list_t<CallbackType, Types...>> == types::type_count_v<Types...>;

        template<typename CallbackType, typename... Types>
        constexpr bool is_any_callable_v = types::type_count_v<callable_list_t<CallbackType, Types...>> != 0;

        //////////////////////////////////////////////////////////////////////////////////////////

        template<typename... Types>
		struct concate_type_st;

        template<> struct concate_type_st<>
        {
            using type = type_list_t<>;
        };

        template<> struct concate_type_st<type_list_t<>>
        {
            using type = type_list_t<>;
        };

        template<typename Type> struct concate_type_st<Type>
		{
			using type = type_list_t<Type>;
		};

        template<typename Type> struct concate_type_st<type_list_t<Type>>
		{
			using type = type_list_t<Type>;
		};

        template<typename Type, typename... Types>
		struct concate_type_st<Type, Types...>
		{
			using type = type_list_t<Type, Types...>;
		};

        template<typename Type, typename... Types>
		struct concate_type_st<type_list_t<Type, Types...>>
		{
			using type = type_list_t<Type, Types...>;
		};

		template<typename Head, typename...Tails, typename... Types>
		struct concate_type_st<type_list_t<Head, Tails...>, Types...>
		{
			using type = type_list_t<Head, Tails..., Types...>;
		};
		
		template<typename Type, typename Head2, typename... Tails2>
		struct concate_type_st<Type, type_list_t<Head2, Tails2...>>
		{
			using type = type_list_t<Type, Head2, Tails2...>;
		};

		template<typename... Types1, typename... Types2>
			struct concate_type_st<type_list_t<Types1...>, type_list_t<Types2...>>
		{
			using type = type_list_t<Types1..., Types2...>;
		};

        template<typename... Types>
	    using concate_type_t = typename concate_type_st<Types...>::type;

        template<typename Type>
        constexpr auto is_template_template_v = hidden::is_template_template_v<Type>;

        template<bool OrAnd,
			bool LeftRight,
			typename Type,
			template<typename, typename...> class BinaryPredicate,
			typename ListHead, typename... ListTails>
		struct type_over_set_st;

		template<bool LeftRight,
			typename Type,
			template<typename, typename...> class BinaryPredicate,
			typename ListHead, typename... ListTails>
		struct type_over_set_st<boolean::Or, LeftRight, Type, BinaryPredicate, ListHead, ListTails...>
		{
			static constexpr bool value =
				type_over_set_st<boolean::Or, LeftRight, Type, BinaryPredicate, ListHead>::value
				|| type_over_set_st<boolean::Or, LeftRight, Type, BinaryPredicate, ListTails...>::value;
		};

		template<bool LeftRight,
			typename Type,
			template<typename, typename...> class BinaryPredicate,
			typename ListHead, typename... ListTails>
		struct type_over_set_st<boolean::And, LeftRight, Type, BinaryPredicate, ListHead, ListTails...>
		{
			static constexpr bool value =
				type_over_set_st<boolean::And, LeftRight, Type, BinaryPredicate, ListHead>::value
				&& type_over_set_st<boolean::And, LeftRight, Type, BinaryPredicate, ListTails...>::value;
		};

		template<typename Type,
			template<typename, typename...> class BinaryPredicate,
			typename ListHead, typename... ListTails>
		struct type_over_set_st<boolean::Or, boolean::Left, Type, BinaryPredicate, ListHead, ListTails...>
		{
			static constexpr bool value =
				type_over_set_st<boolean::Or, boolean::Left, Type, BinaryPredicate, ListHead>::value
				|| type_over_set_st<boolean::Or, boolean::Left, Type, BinaryPredicate, ListTails...>::value;
		};

		template<typename Type,
			template<typename, typename...> class BinaryPredicate,
			typename ListHead, typename... ListTails>
		struct type_over_set_st<boolean::And, boolean::Left, Type, BinaryPredicate, ListHead, ListTails...>
		{
			static constexpr bool value =
				type_over_set_st<boolean::And, boolean::Left, Type, BinaryPredicate, ListHead>::value
				&& type_over_set_st<boolean::And, boolean::Left, Type, BinaryPredicate, ListTails...>::value;
		};

		template<typename Type,
			template<typename, typename...> class BinaryPredicate,
			typename ListHead, typename... ListTails>
		struct type_over_set_st<boolean::Or, boolean::Right, Type, BinaryPredicate, ListHead, ListTails...>
		{
			static constexpr bool value =
				type_over_set_st<boolean::Or, boolean::Right, Type, BinaryPredicate, ListHead>::value
				|| type_over_set_st<boolean::Or, boolean::Right, Type, BinaryPredicate, ListTails...>::value;
		};

		template<typename Type,
			template<typename, typename...> class BinaryPredicate,
			typename ListHead, typename... ListTails>
		struct type_over_set_st<boolean::And, boolean::Right, Type, BinaryPredicate, ListHead, ListTails...>
		{
			static constexpr bool value =
				type_over_set_st<boolean::And, boolean::Right, Type, BinaryPredicate, ListHead>::value
				&& type_over_set_st<boolean::And, boolean::Right, Type, BinaryPredicate, ListTails...>::value;
		};

		template<typename Type, template<typename, typename...> class BinaryPredicate, typename ListHead>
		struct type_over_set_st<boolean::Or, boolean::Left, Type, BinaryPredicate, ListHead>
		{
			static constexpr bool value = BinaryPredicate<Type, ListHead>::value;
		};

		template<typename Type, template<typename, typename...> class BinaryPredicate, typename ListHead>
		struct type_over_set_st<boolean::And, boolean::Left, Type, BinaryPredicate, ListHead>
		{
			static constexpr bool value = BinaryPredicate<Type, ListHead>::value;
		};

		template<typename Type, template<typename, typename...> class BinaryPredicate, typename ListHead>
		struct type_over_set_st<boolean::Or, boolean::Right, Type, BinaryPredicate, ListHead>
		{
			static constexpr bool value = BinaryPredicate<ListHead, Type>::value;
		};

		template<typename Type, template<typename, typename...> class BinaryPredicate, typename ListHead>
		struct type_over_set_st<boolean::And, boolean::Right, Type, BinaryPredicate, ListHead>
		{
			static constexpr bool value = BinaryPredicate<ListHead, Type>::value;
		};

        template<bool OrAnd,
			bool LeftRight,
			typename Type,
			template<typename, typename...> class BinaryPredicate,
			typename ListHead, typename... ListTails>
		struct type_opr_over_set_st
		{
			static constexpr bool value =
				type_over_set_st<OrAnd, LeftRight, Type, BinaryPredicate, ListHead, ListTails...>::value;
		};

		template<bool OrAnd,
			bool LeftRight,
			typename Type,
			template<typename, typename...> class BinaryPredicate,
			typename ListHead, typename... ListTails>
		struct type_opr_over_set_st<OrAnd, LeftRight, Type, BinaryPredicate, 
            type_list_t<ListHead, ListTails...>>
		{
			static constexpr bool value =
				type_over_set_st<OrAnd, LeftRight, Type, BinaryPredicate, ListHead, ListTails...>::value;
		};

		template<bool OrAnd,
			bool LeftRight,
			typename Type,
			template<typename, typename...> class BinaryPredicate,
			typename Head, typename ListHead, typename... ListTails>
		struct type_opr_over_set_st<OrAnd, LeftRight, Type, BinaryPredicate,
			Head, type_list_t<ListHead, ListTails...>>
		{
			static constexpr bool value =
				type_over_set_st<OrAnd, LeftRight, Type, BinaryPredicate,
				Head, ListHead, ListTails...>::value;
		};

		template<bool OrAnd,
			bool LeftRight,
			typename Type,
			template<typename, typename...> class BinaryPredicate,
			typename ListHead, typename... ListTails, typename Head, typename... Tails>
		struct type_opr_over_set_st<OrAnd, LeftRight, Type, BinaryPredicate,
			type_list_t<ListHead, ListTails...>, Head, Tails...>
		{
			static constexpr bool value =
				type_over_set_st<OrAnd, LeftRight, Type, BinaryPredicate,
				ListHead, ListTails..., Head, Tails...>::value;
		};

		template<bool OrAnd,
			bool LeftRight,
			typename Type,
			template<typename, typename...> class BinaryPredicate,
			typename ListHead, typename... ListTails, typename Head, typename... Tails>
		struct type_opr_over_set_st<OrAnd, LeftRight, Type, BinaryPredicate,
			type_list_t<ListHead, ListTails...>, type_list_t<Head, Tails...>>
		{
			static constexpr bool value =
				type_over_set_st<OrAnd, LeftRight, Type, BinaryPredicate,
				ListHead, ListTails..., Head, Tails...>::value;
		};

        template<typename Type,
		typename ListHead, typename... ListTails>
		constexpr bool is_type_in_the_set_v = type_opr_over_set_st<boolean::Or, boolean::Left,
		    Type, std::is_same, ListHead, ListTails...>::value;

	    template<typename Type,
		typename ListHead, typename... ListTails>
		constexpr bool is_constructible_over_the_set_v = type_opr_over_set_st<boolean::Or, boolean::Right,
            Type, std::is_constructible, ListHead, ListTails...>::value;

	    template<typename Type,
		typename ListHead, typename... ListTails>
		constexpr bool is_assignable_to_the_set_v = type_opr_over_set_st<boolean::Or, boolean::Right,
		    std::add_lvalue_reference_t<Type>, std::is_assignable, ListHead, ListTails...>::value;

	    template<typename Type,
		typename ListHead, typename... ListTails>
		constexpr bool is_assignable_from_the_set_v = type_opr_over_set_st<boolean::Or, boolean::Left,
		    std::add_lvalue_reference_t<Type>, std::is_assignable, ListHead, ListTails...>::value;
	
        template<typename TestType, typename TypeList, typename ReturnType = TestType>
        using enable_if_in_list_t = hidden::enable_if_in_list_t<TestType, TypeList, ReturnType>;

        template<typename TestTypeList, typename TypeList, typename ReturnType = void>
        using enable_if_all_in_list_t = hidden::enable_if_all_in_list_t<TestTypeList, TypeList, ReturnType>;

        namespace hidden
        {
            template<template<typename, typename...> class ContainerType, typename... ElementTypes>
            class container_of_variants_class: public ContainerType<std::variant<ElementTypes...>>
            {
                public:
                    using base_type = ContainerType<std::variant<ElementTypes...>>;
                    using base_type::base_type;
                    using value_type = typename base_type::value_type;
                    using variant_type = value_type; 
                    using element_types_t = type_list_t<ElementTypes...>;

                    decltype(auto) crbegin() const noexcept
                    {
                        return base_type::rcbegin();
                    }

                    decltype(auto) crend()  const noexcept
                    {
                        return base_type::crend();
                    }
            };

            template<typename KeyType, typename... ElementTypes>
            class container_of_variants_class<std::pair, KeyType, ElementTypes...>: 
                public std::pair<KeyType, std::variant<ElementTypes...>>
            {
                public:
                    using base_type = std::pair<KeyType, std::variant<ElementTypes...>>;
                    using base_type::base_type;
                    
                    using first_type  = typename base_type::first_type;
                    using second_type = typename base_type::second_type;

                    using element_types_t = type_list_t<ElementTypes...>;
            };

            template<typename KeyType, typename... ElementTypes>
            class container_of_variants_class<std::map, KeyType, ElementTypes...>: 
                public std::map<KeyType, std::variant<ElementTypes...>>
            {
                public:
                    using base_type = std::map<KeyType, std::variant<ElementTypes...>>;
                    using base_type::base_type;
                    using value_type = typename base_type::value_type;
                    using variant_type = value_type; 
                    using element_types_t = type_list_t<ElementTypes...>;

                    decltype(auto) crbegin() const noexcept
                    {
                        return base_type::rcbegin();
                    }

                    decltype(auto) crend()  const noexcept
                    {
                        return base_type::crend();
                    }
            };

            template<typename KeyType, typename... ElementTypes>
            class container_of_variants_class<std::multimap, KeyType, ElementTypes...>: 
                public std::multimap<KeyType, std::variant<ElementTypes...>>
            {
                public:
                    using base_type = std::multimap<KeyType, std::variant<ElementTypes...>>;
                    using base_type::base_type;
                    using value_type = typename base_type::value_type;
                    using variant_type = value_type; 
                    using element_types_t = type_list_t<ElementTypes...>;
            };

            template<typename KeyType, typename... ElementTypes>
            class container_of_variants_class<std::unordered_map, KeyType, ElementTypes...>: 
                public std::unordered_map<KeyType, std::variant<ElementTypes...>>
            {
                public:
                    using base_type = std::unordered_map<KeyType, std::variant<ElementTypes...>>;
                    using base_type::base_type;
                    using value_type = typename base_type::value_type;
                    using variant_type = value_type; 
                    using element_types_t = type_list_t<ElementTypes...>;
            };

            template<typename KeyType, typename... ElementTypes>
            class container_of_variants_class<std::unordered_multimap, KeyType, ElementTypes...>: 
                public std::unordered_multimap<KeyType, std::variant<ElementTypes...>>
            {
                public:
                    using base_type = std::unordered_multimap<KeyType, std::variant<ElementTypes...>>;
                    using base_type::base_type;
                    using value_type = typename base_type::value_type;
                    using variant_type = value_type; 
                    using element_types_t = type_list_t<ElementTypes...>;
            };

            template<template<typename, typename...> class ContainerType, typename... ElementTypes>
                struct container_of_variants_st
            {
                using type = container_of_variants_class<ContainerType, ElementTypes...>;
            };

            template<template<typename, typename...> class ContainerType, typename... ElementTypes>
                struct container_of_variants_st<ContainerType, type_list_t<ElementTypes...>>
            {
                using type = container_of_variants_class<ContainerType, ElementTypes...>;
            };

            template<typename KeyType, typename... ElementTypes>
                struct container_of_variants_st<std::pair, KeyType, type_list_t<ElementTypes...>>
            {
                using type = container_of_variants_class<std::pair, KeyType, ElementTypes...>;
            };

            template<typename KeyType, typename... ElementTypes>
                struct container_of_variants_st<std::map, KeyType, type_list_t<ElementTypes...>>
            {
                using type = container_of_variants_class<std::map, KeyType, ElementTypes...>;
            };

            template<typename KeyType, typename... ElementTypes>
            struct container_of_variants_st<std::multimap, KeyType, type_list_t<ElementTypes...>>
            {
                using type = container_of_variants_class<std::multimap, KeyType, ElementTypes...>;
            };

            template<typename KeyType, typename... ElementTypes>
            struct container_of_variants_st<std::unordered_map, KeyType, type_list_t<ElementTypes...>>
            {
                using type = container_of_variants_class<std::unordered_map, KeyType, ElementTypes...>;
            };
            
            template<typename KeyType, typename... ElementTypes>
            struct container_of_variants_st<std::unordered_multimap, KeyType, type_list_t<ElementTypes...>>
            {
                using type = container_of_variants_class<std::unordered_multimap, KeyType, ElementTypes...>;
            };
            
            template<template<typename, typename...> class ContainerType, typename... ElementTypes>
            using container_of_variants_t = 
                typename container_of_variants_st<ContainerType, unique_types_t<ElementTypes...>>::type; 

            template<template<typename, typename...> class ContainerType,
                typename KeyType, typename... ElementTypes>
            using container_map_of_variants_t = 
                typename container_of_variants_st<ContainerType, KeyType, unique_types_t<ElementTypes...>>::type; 

            template<typename... ElementTypes>
            using vector_of_variants_t = container_of_variants_t<std::vector, ElementTypes...>;

            template<typename... ElementTypes>
            using deque_of_variants_t = container_of_variants_t<std::deque, ElementTypes...>;

            template<typename... ElementTypes>
            using list_of_variants_t = container_of_variants_t<std::list, ElementTypes...>;

            template<typename... ElementTypes>
            using set_of_variants_t = container_of_variants_t<std::set, ElementTypes...>;

            template<typename... ElementTypes>
            using multiset_of_variants_t = container_of_variants_t<std::multiset, ElementTypes...>;

            template<typename... ElementTypes>
            using unordered_set_of_variants_t = container_of_variants_t<std::unordered_set, ElementTypes...>;

            template<typename... ElementTypes>
            using unordered_multiset_of_variants_t = container_of_variants_t<std::unordered_multiset, ElementTypes...>;

            template<typename... ElementTypes>
            using multiset_of_variants_t = container_of_variants_t<std::multiset, ElementTypes...>;

            template<typename KeyType, typename... ElementTypes>
            using pair_of_variants_t = container_map_of_variants_t<std::pair, KeyType, ElementTypes...>;

            template<typename KeyType, typename... ElementTypes>
            using map_of_variants_t = container_map_of_variants_t<std::map, KeyType, ElementTypes...>;

            template<typename KeyType, typename... ElementTypes>
            using multimap_of_variants_t = container_map_of_variants_t<std::multimap, KeyType, ElementTypes...>;

            template<typename KeyType, typename... ElementTypes>
            using unordered_map_of_variants_t = container_map_of_variants_t<std::unordered_map, KeyType, ElementTypes...>;

            template<typename KeyType, typename... ElementTypes>
            using unordered_multimap_of_variants_t = container_map_of_variants_t<std::unordered_multimap, KeyType, ElementTypes...>;

        } // end of namespace hidden

        template<typename Type1, typename Type2,
            typename common_t = common_type_t<Type1, Type2>, // get the common type of type1_t and type2_t
            bool is_integral_type = is_integral_v<common_t>, // test if common_t is of integral type
            typename result_type = std::conditional_t< 
                is_integral_type, // is common type integral?
                make_signed_t<common_t>, // if integral type, then get signed integeral type
                common_t> >
        using signed_common_t = result_type;

        template<typename Type1, typename Type2,
            typename common_t = common_type_t<Type1, Type2>, // get the common type of type1_t and type2_t
            bool is_integral_type = is_integral_v<common_t>, // test if common_t is of integral type
            typename result_type = std::conditional_t< 
                is_integral_type, // is common type integral?
                make_unsigned_t<common_t>, // if integral type, then get signed integeral type
                common_t> >
        using unsigned_common_t = result_type;

        template<template<typename, typename...> class ContainerType, typename... ElementTypes>
        using container_of_variants_t = hidden::container_of_variants_t<ContainerType, ElementTypes...>;
        
        template<typename... ElementTypes>
        using vector_of_variants_t = hidden::vector_of_variants_t<ElementTypes...>;

        template<typename... ElementTypes>
        using deque_of_variants_t = hidden::deque_of_variants_t<ElementTypes...>;

        template<typename... ElementTypes>
        using list_of_variants_t = hidden::list_of_variants_t<ElementTypes...>;

        template<typename... ElementTypes>
        using set_of_variants_t = hidden::set_of_variants_t<ElementTypes...>;

        template<typename... ElementTypes>
        using multiset_of_variants_t = hidden::multiset_of_variants_t<ElementTypes...>;

        template<typename... ElementTypes>
        using unordered_set_of_variants_t = hidden::unordered_set_of_variants_t<ElementTypes...>;

        template<typename... ElementTypes>
        using unordered_multiset_of_variants_t = hidden::unordered_multiset_of_variants_t<ElementTypes...>;

        template<typename... ElementTypes>
        using multiset_of_variants_t = hidden::multiset_of_variants_t<ElementTypes...>;

        template<typename KeyType, typename... ElementTypes>
        using map_of_variants_t = hidden::map_of_variants_t<KeyType, ElementTypes...>;

        template<typename KeyType, typename... ElementTypes>
        using multimap_of_variants_t = hidden::multimap_of_variants_t<KeyType, ElementTypes...>;

        template<typename KeyType, typename... ElementTypes>
        using unordered_map_of_variants_t = hidden::unordered_map_of_variants_t<KeyType, ElementTypes...>;

        template<typename KeyType, typename... ElementTypes>
        using unordered_multimap_of_variants_t = hidden::unordered_multimap_of_variants_t<KeyType, ElementTypes...>;

        ////////////////////////////////////////////////////////////////
        namespace hidden
        {
            template<typename Type, typename... Types> 
            struct types_to_template_class_st
            {
                using type = no_type_t;
            };

            template<template<typename...>class ClassTemplate, 
                typename... InnerTypes, typename... Types>
            struct types_to_template_class_st<ClassTemplate<InnerTypes...>, Types...>
            {
                using type = ClassTemplate<Types...>;
            };

            template<template<typename...>class ClassTemplate, 
                typename... InnerTypes, typename... Types>
            struct types_to_template_class_st<ClassTemplate<InnerTypes...>,
                type_list_t<Types...>>
            {
                using type = ClassTemplate<Types...>;
            };

            template<typename Type, typename... Types> 
            struct types_to_template_class_wrapper_st
            {
                using type = typename 
                    types_to_template_class_st<Type, Types...>::type;
            };

            template<template<typename...>class ClassTemplate, 
                typename... InnerTypes, typename... Types>
            struct types_to_template_class_wrapper_st<ClassTemplate<InnerTypes...>, Types...>
            {
                using type = typename 
                    types_to_template_class_st<ClassTemplate<InnerTypes...>, Types...>::type;
            };

            template<typename... InnerTypes, typename... Types>
            struct types_to_template_class_wrapper_st<std::variant<InnerTypes...>, Types...>
            {
                using type = typename 
                    types_to_template_class_st<std::variant<InnerTypes...>, unique_types_t<Types...>>::type;
            };
            
            template<template<typename...>class ClassTemplate, 
                typename... InnerTypes, typename... Types>
            struct types_to_template_class_wrapper_st<ClassTemplate<InnerTypes...>,
                type_list_t<Types...>>
            {
                using type = 
                    typename types_to_template_class_st<ClassTemplate<InnerTypes...>, Types...>::type;
            };

            template<typename... InnerTypes, typename... Types>
            struct types_to_template_class_wrapper_st<std::variant<InnerTypes...>, type_list_t<Types...>>
            {
                using type = 
                    typename types_to_template_class_st<std::variant<InnerTypes...>, unique_types_t<Types...>>::type;
            };

            template<typename Type, typename... Types>
            using types_to_template_class_t = 
                typename types_to_template_class_wrapper_st<Type, Types...>::type;

            template<template<typename...>class ClassTemplate, typename... Types>
            struct type_list_to_template_class_st
            {
                using type = ClassTemplate<Types...>;
            };

            template<template<typename...>class ClassTemplate, typename... Types>
            struct type_list_to_template_class_st<ClassTemplate, type_list_t<Types...>>
            {
                using type = ClassTemplate<Types...>;
            };

            template<template<typename...>class ClassTemplate, typename... Types>
            struct type_list_to_template_class_wrapper_st
            {
                using type = typename type_list_to_template_class_st<ClassTemplate, Types...>::type;
            };

            template<template<typename...>class ClassTemplate, typename... Types>
            struct type_list_to_template_class_wrapper_st<ClassTemplate, type_list_t<Types...>>
            {
                using type = typename type_list_to_template_class_st<ClassTemplate, Types...>::type;
            };

            template<typename... Types>
            struct type_list_to_template_class_wrapper_st<std::variant, Types...>
            {
                using type = typename type_list_to_template_class_st<std::variant,
                        unique_types_t<Types...>>::type;
            };

            template<typename... Types>
            struct type_list_to_template_class_wrapper_st<std::variant, type_list_t<Types...>>
            {
                using type = typename type_list_to_template_class_st<std::variant,
                        unique_types_t<Types...>>::type;
            };

            template<template<typename...>class ClassTemplate, typename... Types>
            using type_list_to_template_class_t = 
                typename type_list_to_template_class_wrapper_st<ClassTemplate, Types...>::type;

            //////////////////////////////////////////////////////////////////////////
            template<size_t TypeIndex, typename TemplateClass, typename... Types>
            struct nth_type_to_template_class_st;

            template<size_t TypeIndex, 
                template<typename...> class TemplateClass,
                typename... InnerTypes, typename... Types> 
            struct nth_type_to_template_class_st<TypeIndex, TemplateClass<InnerTypes...>, Types...>
            {
                static_assert(TypeIndex < sizeof...(Types), "TypeIndex is out of range");

                using nth_type = select_nth_type_t<TypeIndex, type_list_t<Types...>>;               
                using type = std::conditional_t<is_valid_type_v<nth_type>, TemplateClass<nth_type>, nth_type>;
            };

            template<size_t TypeIndex, 
                template<typename...> class TemplateClass,
                typename... InnerTypes, typename... Types> 
            struct nth_type_to_template_class_st<TypeIndex, TemplateClass<InnerTypes...>, type_list_t<Types...>>
            {
                static_assert(TypeIndex < sizeof...(Types), "TypeIndex is out of range");
                
                using nth_type = select_nth_type_t<TypeIndex, type_list_t<Types...>>;
                using type = std::conditional_t<is_valid_type_v<nth_type>, TemplateClass<nth_type>, nth_type>;
            };
            
            template<size_t TypeIndex, typename TemplateClass, typename... Types>
            using nth_type_to_template_class_t = 
                typename nth_type_to_template_class_st<TypeIndex, TemplateClass, Types...>::type;

            ////////////////////////////////////////////////////////////////////////////////////////
            template<size_t FirstN,
                template<typename...> typename TemplateClass, typename... Types> 
            struct first_n_types_list_to_template_class_st
            {
                static_assert(FirstN <= sizeof...(Types), "FirstN is out of range");
                using n_types = first_n_types_t<FirstN, type_list_t<Types...>>;
                
                using class_t = std::conditional_t<is_valid_type_v<n_types>, 
                    type_list_to_template_class_t<TemplateClass, n_types>, no_type_t>;

                using type = std::conditional_t<is_valid_type_v<class_t>, class_t, no_type_t>;
            };

            template<size_t FirstN, template<typename...> class TemplateClass, typename... Types> 
            struct first_n_types_list_to_template_class_st<FirstN, TemplateClass, type_list_t<Types...>>
            {
                static_assert(FirstN <= sizeof...(Types), "FirstN is out of range");
                using n_types = first_n_types_t<FirstN, type_list_t<Types...>>;
                
                using class_t = std::conditional_t<is_valid_type_v<n_types>, 
                    type_list_to_template_class_t<TemplateClass, n_types>, no_type_t>;

                using type = std::conditional_t<is_valid_type_v<class_t>, class_t, no_type_t>;
            };
            
            template<size_t FirstN, template<typename...> typename TemplateClass, typename... Types>
            using first_n_types_list_to_template_class_t = 
                typename first_n_types_list_to_template_class_st<FirstN, TemplateClass, Types...>::type;

            /////////////////////////////////////////////////////////////////////////////////////////
            template<size_t FirstN, typename TemplateClass, typename... Types>
            struct first_n_types_to_template_class_st;

            template<size_t FirstN, 
                template<typename...> class TemplateClass,
                typename... InnerTypes, typename... Types> 
            struct first_n_types_to_template_class_st<FirstN, TemplateClass<InnerTypes...>, Types...>
            {
                static_assert(FirstN <= sizeof...(Types), "FirstN is out of range");
                using n_types = first_n_types_t<FirstN, type_list_t<Types...>>;
                
                using class_t = std::conditional_t<is_valid_type_v<n_types>, 
                    type_list_to_template_class_t<TemplateClass, n_types>, no_type_t>;

                using type = std::conditional_t<is_valid_type_v<class_t>, class_t, no_type_t>;
            };

            template<size_t FirstN, 
                template<typename...> class TemplateClass,
                typename... InnerTypes, typename... Types> 
            struct first_n_types_to_template_class_st<FirstN, TemplateClass<InnerTypes...>, type_list_t<Types...>>
            {
                static_assert(FirstN <= sizeof...(Types), "FirstN is out of range");
                using n_types = first_n_types_t<FirstN, type_list_t<Types...>>;
                
                using class_t = std::conditional_t<is_valid_type_v<n_types>, 
                    type_list_to_template_class_t<TemplateClass, n_types>, no_type_t>;

                using type = std::conditional_t<is_valid_type_v<class_t>, class_t, no_type_t>;
            };
            
            template<size_t FirstN, typename TemplateClass, typename... Types>
            using first_n_types_to_template_class_t = 
                typename first_n_types_to_template_class_st<FirstN, TemplateClass, Types...>::type;
                
            //////////////////////////////////////////////////


            template<template<typename, typename...> class ContainerType, typename... ElementTypes>
            class container_of_tuples_class : public ContainerType< std::tuple<ElementTypes...> >
            {
                public:

                using base_type = ContainerType< std::tuple<ElementTypes...> >;
                using base_type::base_type;

                using value_type = typename base_type::value_type;
                using tuple_type = value_type; 
                
                using element_types_t = type_list_t<ElementTypes...>;
            };

            template<typename KeyType, typename... ElementTypes>
            class container_of_tuples_class<std::map, KeyType, ElementTypes...> 
                : public std::map<KeyType, std::tuple<ElementTypes...>>
            {
                public:

                using base_type = std::map<KeyType, std::tuple<ElementTypes...>>;
                using base_type::base_type;

                using value_type = typename base_type::value_type;
                using tuple_type = std::tuple<ElementTypes...>; 
                
                using element_types_t = type_list_t<ElementTypes...>;
            };

            template<typename KeyType, typename... ElementTypes>
            class container_of_tuples_class<std::multimap, KeyType, ElementTypes...> 
                : public std::multimap<KeyType, std::tuple<ElementTypes...>>
            {
                public:

                using base_type = std::multimap<KeyType, std::tuple<ElementTypes...>>;
                using base_type::base_type;

                using value_type = typename base_type::value_type;
                using tuple_type = std::tuple<ElementTypes...>; 
                
                using element_types_t = type_list_t<ElementTypes...>;
            };

            template<typename KeyType, typename... ElementTypes>
            class container_of_tuples_class<std::unordered_map, KeyType, ElementTypes...> 
                : public std::unordered_map<KeyType, std::tuple<ElementTypes...>>
            {
                public:

                using base_type = std::unordered_map<KeyType, std::tuple<ElementTypes...>>;
                using base_type::base_type;

                using value_type = typename base_type::value_type;
                using tuple_type = std::tuple<ElementTypes...>; 
                
                using element_types_t = type_list_t<ElementTypes...>;
            };

            template<typename KeyType, typename... ElementTypes>
            class container_of_tuples_class<std::unordered_multimap, KeyType, ElementTypes...> 
                : public std::unordered_multimap<KeyType, std::tuple<ElementTypes...>>
            {
                public:

                using base_type = std::unordered_multimap<KeyType, std::tuple<ElementTypes...>>;
                using base_type::base_type;

                using value_type = typename base_type::value_type;
                using tuple_type = std::tuple<ElementTypes...>; 
                
                using element_types_t = type_list_t<ElementTypes...>;
            };

            template<template<typename, typename...> class ContainerType, typename... ElementTypes>
                struct container_of_tuples_st
            {
                using type = container_of_tuples_class<ContainerType, ElementTypes...>;
            };

            template<template<typename, typename...> class ContainerType, typename... ElementTypes>
                struct container_of_tuples_st<ContainerType, type_list_t<ElementTypes...>>
            {
                using type = container_of_tuples_class<ContainerType, ElementTypes...>;
            };

            template<template<typename, typename...> class ContainerType, typename... ElementTypes>
            using container_of_tuples_t = typename container_of_tuples_st<ContainerType, ElementTypes...>::type;

            template<typename... ElementTypes>
            using vector_of_tuples_t = container_of_tuples_t<std::vector, ElementTypes...>;

            template<typename... ElementTypes>
            using deque_of_tuples_t = container_of_tuples_t<std::deque, ElementTypes...>;

            template<typename... ElementTypes>
            using list_of_tuples_t = container_of_tuples_t<std::list, ElementTypes...>;

            template<typename... ElementTypes>
            using set_of_tuples_t = container_of_tuples_t<std::set, ElementTypes...>;

            template<typename KeyType, typename... ElementTypes>
            using map_of_tuples_t = container_of_tuples_t<std::map, KeyType, ElementTypes...>;

            template<typename KeyType, typename... ElementTypes>
            using multimap_of_tuples_t = container_of_tuples_t<std::multimap, KeyType, ElementTypes...>;

            template<typename KeyType, typename... ElementTypes>
            using unordered_map_of_tuples_t = container_of_tuples_t<std::unordered_map, KeyType, ElementTypes...>;

            template<typename KeyType, typename... ElementTypes>
            using unordered_multimap_of_tuples_t = container_of_tuples_t<std::unordered_multimap, KeyType, ElementTypes...>;

        } // end of namespace hidden

        template<typename Type, typename... Types>
        using types_to_template_class_t = hidden::types_to_template_class_t<Type, Types...>;

        template<template<typename...> class ClassTemplate, typename... Types>
        using type_list_to_template_class_t = hidden::type_list_to_template_class_t<ClassTemplate, Types...>;

        template<size_t SelectTypeIndex, typename TemplateClass, typename... Types>
        using nth_type_to_template_class_t = 
            hidden::nth_type_to_template_class_t<SelectTypeIndex, TemplateClass, Types...>;

        template<size_t FirstN, typename TemplateClass, typename... Types>
        using first_n_types_to_template_class_t = 
            hidden::first_n_types_to_template_class_t<FirstN, TemplateClass, Types...>;

        template<size_t FirstN, template<typename...> typename TemplateClass, typename... Types>
        using first_n_types_list_to_template_class_t = 
            hidden::first_n_types_list_to_template_class_t<FirstN, TemplateClass, Types...>;

        template<template<typename, typename...> class ContainerType, typename... ElementTypes>
        using container_of_tuples_t = hidden::container_of_tuples_t<ContainerType, ElementTypes...>;

        template<typename... ElementTypes>
        using vector_of_tuples_t = hidden::vector_of_tuples_t<ElementTypes...>;

        template<typename... ElementTypes>
        using deque_of_tuples_t = hidden::deque_of_tuples_t<ElementTypes...>;

        template<typename... ElementTypes>
        using list_of_tuples_t = hidden::list_of_tuples_t<ElementTypes...>;

        template<typename... ElementTypes>
        using set_of_tuples_t = hidden::set_of_tuples_t<ElementTypes...>;

        template<typename KeyType, typename... ElementTypes>
        using map_of_tuples_t = hidden::map_of_tuples_t<KeyType, ElementTypes...>;

        template<typename KeyType, typename... ElementTypes>
        using multimap_of_tuples_t = hidden::multimap_of_tuples_t<KeyType, ElementTypes...>;

        template<typename KeyType, typename... ElementTypes>
        using unordered_map_of_tuples_t = hidden::unordered_map_of_tuples_t<KeyType, ElementTypes...>;

        template<typename KeyType, typename... ElementTypes>
        using unordered_multimap_of_tuples_t = hidden::unordered_multimap_of_tuples_t<KeyType, ElementTypes...>;

        ////////////////////////////////////////////////////////////////

        template<template<typename, typename...> class ContainerType,
            typename EleType, typename... Types>
        auto erase(ContainerType<EleType, Types...>& container, size_t index)
        {
            auto itr = container.begin();
            std::advance(itr, index);
            return container.erase(itr);
        }

        template<template<typename, typename...> class ContainerType, typename Type, typename... Types>
        auto pop_front(ContainerType<Type, Types...>& container)
        {
            if(container.empty())
            {
                Tpf_ThrowDebugException("container empty");
            }

            if constexpr (is_front_available_v<decltype(container)>)
            {
                auto front = container.front();

                if constexpr(is_pop_front_available_v<decltype(container)>)
                    container.pop_front();
                else
                {
                    auto front_itr = container.begin();
                    container.erase(front_itr);
                }
                
                return front;
            }
            else
            {
                if constexpr (is_pop_front_available_v<decltype(container)>)
                {
                    auto front = *container.begin();
                    container.pop_front();
                    return front;
                }
                else
                {
                    auto front_itr = container.begin();
                    auto front = *front_itr;
                    container.erase(front_itr);
                    return front;
                }
            }
        }

        template<template<typename, typename...> class ContainerType, typename Type, typename... Types>
        auto pop_back(ContainerType<Type, Types...>& container)
        {
            if(container.empty())
            {
                Tpf_ThrowDebugException("container empty");
            }

            auto back = container.back();
            container.pop_back();
            return back;
        }
        
        template<template<typename, typename...> class ContainerType,
            typename EleType, typename Type, typename... Types>
        void push_front(ContainerType<Type, Types...>& container, EleType&& ele)
        {
            if constexpr(is_push_front_available_v<decltype(container)>)
            {
                container.push_front(std::forward<EleType>(ele));
            }
            else if constexpr(is_insert_iterator_available_v<decltype(container)>)
            {
                container.insert(container.cbegin(), std::forward<EleType>(ele));
            }
            else if constexpr(is_insert_available_v<decltype(container)>)
            {
                 container.insert(std::forward<EleType>(ele));
            }
            else
            {
                Tpf_ThrowDebugException("Cannot push front");
            }
        }

        template<template<typename, typename...> class ContainerType,
        typename EleType, typename Type, typename... Types>
        void push_back(ContainerType<Type, Types...>& container, EleType&& ele)
        {
            if constexpr(is_push_back_available_v<decltype(container)>)
            {
                container.push_back(std::forward<EleType>(ele));
            }
            else if constexpr(is_insert_iterator_available_v<decltype(container)>)
            {
                container.insert(container.cend(), std::forward<EleType>(ele));
            }
            else if constexpr(is_insert_available_v<decltype(container)>)
            {
                container.insert(std::forward<EleType>(ele));
            }
            else
            {
                Tpf_ThrowDebugException("Cannot push back");
            }
        }

        template<template<typename, typename...> class ContainerType,
            typename... EleTypes, typename Type, typename... Types>
        void emplace_front(ContainerType<Type, Types...>& container, EleTypes&&... eles)
        {
            if constexpr(is_emplace_front_available_v<decltype(container)>)
            {
                container.emplace_front(std::forward<EleTypes>(eles)...);
            }
            else if constexpr(is_emplace_available_v<decltype(container)>)
            {
                container.emplace(container.cbegin(), std::forward<EleTypes>(eles)...);
            }
            else
            {
                container.insert(container.cbegin(), std::forward<EleTypes>(eles)...);
            }
        }

        template<template<typename, typename...> class ContainerType,
        typename... EleTypes, typename Type, typename... Types>
        void emplace_back(ContainerType<Type, Types...>& container, EleTypes&&... eles)
        {
            if constexpr(is_emplace_back_available_v<decltype(container)>)
            {
                container.emplace_back(std::forward<EleTypes>(eles)...);
            }
            else if constexpr(is_emplace_available_v<decltype(container)>)
            {
                container.emplace_back(container.cend(), std::forward<EleTypes>(eles)...);
            }
            else
            {
                container.insert(container.cend(), std::forward<EleTypes>(eles)...);
            }
        }

        template<template<typename, typename...> class ContainerType, typename Type, typename... Types>
        ContainerType<Type, Types...> reverse_order(const ContainerType<Type, Types...>& container)
        {
            return {container.crbegin(), container.crend()};
        }

        template<template<typename, typename...> class ContainerType, typename Type, typename... Types>
        void reverse_order_in_place(ContainerType<Type, Types...>& container)
        {
            container = ContainerType<Type, Types...>{container.crbegin(), container.crend()};
        }
        
        template<bool bReverseOrder, typename TargetContainerType, typename SourceContainerType>
        void append_to_container(TargetContainerType& target_container, SourceContainerType&& source_container)
        {
            if constexpr(std::is_rvalue_reference_v<decltype(source_container)>)
            {
                if constexpr (bReverseOrder)
                {
                    target_container.insert(target_container.cend(), 
                        std::make_move_iterator(source_container.rbegin()),
                        std::make_move_iterator(source_container.rend()));
                }
                else
                {
                    target_container.insert(target_container.cend(), 
                        std::make_move_iterator(source_container.begin()),
                        std::make_move_iterator(source_container.end()));
                }
            }
            else
            {
                if constexpr(bReverseOrder)
                {
                    target_container.insert(target_container.cend(), 
                        source_container.crbegin(),
                        source_container.crend());
                }
                else
                {
                    target_container.insert(target_container.cend(), 
                        source_container.cbegin(),
                        source_container.cend());
                }
            }
        }

        template<bool bReverseOrder, typename TargetContainerType, typename SourceContainerType>
        void prepend_to_container(TargetContainerType& target_container, SourceContainerType&& source_container)
        {
            if constexpr(std::is_rvalue_reference_v<decltype(source_container)>)
            {
                if constexpr(bReverseOrder)
                {
                    target_container.insert(target_container.cbegin(), 
                        std::make_move_iterator(source_container.rbegin()),
                        std::make_move_iterator(source_container.rend()));
                }
                else
                {
                    target_container.insert(target_container.cbegin(), 
                        std::make_move_iterator(source_container.begin()),
                        std::make_move_iterator(source_container.end()));
                }
            }
            else
            {
                if constexpr (bReverseOrder)
                {
                    target_container.insert(target_container.cbegin(), 
                        source_container.crbegin(),
                        source_container.crend());
                }
                else
                {
                    target_container.insert(target_container.cbegin(), 
                        source_container.cbegin(),
                        source_container.cend());
                }
            }
        }
        
        template<template<typename, typename...> class ContainerType, typename Type, typename... Types>
        auto make_random_access_container(Type&& arg, Types&&... args)
        {
            using parameter_types = decay_remove_cv_ref_type_list_t<Type, Types...>;
            using common_type = common_type_t<parameter_types>;

            static_assert(common_type_v<parameter_types>, "Common Type Does Not Exist");

            if constexpr(is_same_v<parameter_types>)
            {
                using container_t = ContainerType<common_type>;
                
                return container_t{ std::forward<Type>(arg), std::forward<Types>(args)... };
            }
            else if constexpr(tpf::types::is_integral_v<common_type>)
            {
                // test if all types are of unsigned integral types
                if constexpr (are_unsigned_integrals_v<parameter_types>)
                {
                    using container_t = ContainerType<common_type>;
                                    
                    return container_t{ static_cast<common_type>(std::forward<Type>(arg) ), 
                            static_cast<common_type>( std::forward<Types>(args) )...};
                }
                else
                {
                    using element_t = std::make_signed_t<common_type>;
                    using container_t = ContainerType<element_t>;
                                    
                    return container_t{ 
                        static_cast<element_t>(std::forward<Type>(arg)), 
                        static_cast<element_t>(std::forward<Types>(args))... };
                }
            }
            else 
            {
                using element_t = common_type;
                using container_t = ContainerType<element_t>;
                
                return container_t{ static_cast<element_t>(std::forward<Type>(arg)), 
                                    static_cast<element_t>(std::forward<Types>(args))... };
            }
        }

        template<typename Type, typename... Types>
        auto make_vector(Type&& arg, Types&&... args)
        {
            using parameter_types = decay_remove_cv_ref_type_list_t<Type, Types...>;
            using common_type = common_type_t<parameter_types>;

            static_assert(common_type_v<parameter_types>, "Common Type Does Not Exist");

            if constexpr(is_same_v<parameter_types>)
            {
                using container_t = std::vector<common_type>;
                
                return container_t{ std::forward<Type>(arg), std::forward<Types>(args)... };
            }
            else if constexpr(tpf::types::is_integral_v<common_type>)
            {
                // test if all types are of unsigned integral types
                if constexpr (are_unsigned_integrals_v<parameter_types>)
                {
                    using container_t = std::vector<common_type>;
                                    
                    return container_t{ static_cast<common_type>(std::forward<Type>(arg) ), 
                            static_cast<common_type>( std::forward<Types>(args) )...};
                }
                else
                {
                    using element_t = std::make_signed_t<common_type>;
                    using container_t = std::vector<element_t>;
                                    
                    return container_t{ 
                        static_cast<element_t>(std::forward<Type>(arg)), 
                        static_cast<element_t>(std::forward<Types>(args))... };
                }
            }
            else 
            {
                using element_t = common_type;
                using container_t = std::vector<element_t>;
                
                return container_t{ static_cast<element_t>(std::forward<Type>(arg)), 
                                    static_cast<element_t>(std::forward<Types>(args))... };
            }
        }

        template<typename Type, typename... Types>
        auto make_deque(Type&& arg, Types&&... args)
        {
            using parameter_types = decay_remove_cv_ref_type_list_t<Type, Types...>;
            using common_type = common_type_t<parameter_types>;

            static_assert(common_type_v<parameter_types>, "Common Type Does Not Exist");

            if constexpr(is_same_v<parameter_types>)
            {
                using container_t = std::deque<common_type>;
                
                return container_t{ std::forward<Type>(arg), std::forward<Types>(args)... };
            }
            else if constexpr(tpf::types::is_integral_v<common_type>)
            {
                // test if all types are of unsigned integral types
                if constexpr (are_unsigned_integrals_v<parameter_types>)
                {
                    using container_t = std::deque<common_type>;
                                    
                    return container_t{ static_cast<common_type>(std::forward<Type>(arg) ), 
                            static_cast<common_type>( std::forward<Types>(args) )...};
                }
                else
                {
                    using element_t = std::make_signed_t<common_type>;
                    using container_t = std::deque<element_t>;
                                    
                    return container_t{ 
                        static_cast<element_t>(std::forward<Type>(arg)), 
                        static_cast<element_t>(std::forward<Types>(args))... };
                }
            }
            else 
            {
                using element_t = common_type;
                using container_t = std::deque<element_t>;
                
                return container_t{ static_cast<element_t>(std::forward<Type>(arg)), 
                                    static_cast<element_t>(std::forward<Types>(args))... };
            }
        }

        template<typename Type, typename... Types>
        auto make_container(Type&& arg, Types&&... args)
        {
            using parameter_types = decay_remove_cv_ref_type_list_t<Type, Types...>;
            
            if constexpr(is_same_v<parameter_types> || common_type_v<parameter_types>)
            {
                return make_vector(std::forward<Type>(arg), std::forward<Types>(args)...);
            }
            else
            {
                return std::make_tuple(std::forward<Type>(arg), std::forward<Types>(args)...);
            }
        }

        #if !defined(__clang_major__)

        template<typename Type, typename... Types>
        auto make_variants(Type&& arg, Types&&... args)
        {
            using parameter_types = decay_remove_cv_ref_type_list_t<Type, Types...>;

            if constexpr(is_same_v<parameter_types> || common_type_v<parameter_types>)
            {
                return make_vector(std::forward<Type>(arg), std::forward<Types>(args)...);
            }
            else
            {
                using element_t = types::to_variant_t<parameter_types>;
              
                return std::vector<element_t>{ element_t{ std::forward<Type>(arg) },
                   element_t{ std::forward<Types>(args) }... };
            }
        }
        
        #endif
        
        template<typename ContainerType>
        class reverse_st
        {
            private:
                ContainerType m_container;
            
            public:

            reverse_st(ContainerType container): 
                m_container{ container } { }

            auto empty() const noexcept { return m_container.empty(); }
            auto size() const noexcept { return m_container.size(); }

            decltype(auto) begin() noexcept //(noexcept(m_container.rbegin()))
            {
                static_assert(!is_const_reference_v<ContainerType>, "--- use const auto&");

                return m_container.rbegin();
            }

            decltype(auto) end() noexcept // (noexcept(m_container.rend()))
            {
                static_assert(!is_const_reference_v<ContainerType>, "--- use const auto&");
                return m_container.rend();
            }

            decltype(auto) cbegin() const noexcept //(noexcept(m_container.crbegin()))
            {
                return m_container.crbegin();
            }

            decltype(auto) cend() const noexcept // (noexcept(m_container.crend()))
            {
                return m_container.crend();
            }

            auto clone() const
            {
                using container_type = tpf::remove_cv_ref_t<ContainerType>;
                
                return container_type{ m_container.crbegin(), m_container.crend() };
            }
        };

        template<typename ElementType, size_t ElementCount>
        class reverse_st<ElementType(&)[ElementCount]>
        {
            private:
                using ContainerType = ElementType(&)[ElementCount];
                
                ContainerType m_container;
            public:

                auto empty() const noexcept { return false; }
                auto size() const noexcept { return ElementCount; }

                reverse_st(ContainerType container): m_container{container} { }

                using reverse_iterator = std::reverse_iterator<ElementType*>;
                                   
                decltype(auto) begin() noexcept
                {
                    return reverse_iterator{&m_container[ElementCount]};
                }

                decltype(auto) end() noexcept
                {
                    return reverse_iterator{&m_container[0]};
                }
                
                decltype(auto) cbegin() const noexcept
                {
                    return reverse_iterator{&m_container[ElementCount]};
                }

                decltype(auto) cend() const noexcept
                {
                    return reverse_iterator{&m_container[0]};
                }

                auto clone() const
                {
                    using element_t = std::remove_cv_t<ElementType>;
                    return std::vector<element_t>{ cbegin(), cend() };
                }
        };

        template<typename ContainerType>
        auto reverse(ContainerType&& container)
        {
            using reserve_t = reverse_st<ContainerType>;

            return reserve_t{ std::forward<ContainerType>(container) };
        }
        
        template<typename ElementType, size_t ElementCount> 
        auto reverse(ElementType(&array)[ElementCount])
        {
            using array_type = ElementType(&)[ElementCount];

            using reverse_t = reverse_st<array_type>;
            
            return reverse_t{array};
        }

        template<typename Type, typename... Types>
        auto reverse(Type&& arg, Types&&... args)
        {
            using parameter_types = decay_remove_cv_ref_type_list_t<Type, Types...>;

            static_assert(common_type_v<parameter_types>, "Common Type Does Not Exist");

            auto v = make_vector(std::forward<Type>(arg), std::forward<Types>(args)...);

            return reverse_st<decltype(v)>{ std::move(v) };
        }

        template<typename ContainerType, typename IndexType>
        decltype(auto) get_element(ContainerType container, IndexType index)
        {
            using container_t = tpf::remove_cv_ref_t<ContainerType>;

            if constexpr(tpf::types::is_index_operator_available_v<container_t>)
            {
                return container[(size_t)index];
            }
            else
            {
                if constexpr(std::is_const_v<ContainerType>)
                {
                    auto itr = container.cbegin();
                    std::advance(itr, index);
                    return *itr; 
                }
                else
                {
                    auto itr = container.begin();
                    std::advance(itr, index);
                    return *itr; 
                }
            }
        }

        template<size_t StartIndex, size_t EndIndex>
        struct static_loop_struct
        {
            /////////////////////////////////////////////////////
            template<typename VisitorType, typename PairType>
            static std::enable_if_t<is_pair_of_variant_v<remove_cv_ref_t<PairType>>>       
            visit_variant(VisitorType&& visitors, PairType&& vpr)
            {
                if constexpr(StartIndex < EndIndex)
                {
                    auto& [key, vt] = vpr;
                    
                    if(auto ptr = std::get_if<StartIndex>(&vt))
                    {
                        std::get<StartIndex>(visitors.m_visitors)(key, *ptr); 
                        return;
                    }
                }

                if constexpr(StartIndex + 1 < EndIndex)
                {
                    static_loop_struct<StartIndex+1, EndIndex>:: 
                        template visit_variant(std::forward<VisitorType>(visitors),
                            std::forward<PairType>(vpr));
                }
            }

            template<typename VisitorType, typename VariantType>
            static std::enable_if_t<is_variant_v<remove_cv_ref_t<VariantType>>>
            visit_variant(VisitorType&& visitors, VariantType&& vpr)
            {
                if constexpr(StartIndex < EndIndex)
                {
                    if(auto ptr = std::get_if<StartIndex>(&vpr))
                    {
                        std::get<StartIndex>(visitors.m_visitors)(*ptr);
                        return;
                    }
                }

                if constexpr(StartIndex + 1 < EndIndex)
                {
                    static_loop_struct<StartIndex+1, EndIndex>:: 
                        template visit_variant(std::forward<VisitorType>(visitors),
                            std::forward<VariantType>(vpr));
                }
            }

            //////////////////////////////////////////////
            /////////////////////////////////////////////////////
            template<typename VisitorType, typename IteratorType, typename PairType>
            static std::enable_if_t<is_pair_of_variant_v<remove_cv_ref_t<PairType>>>       
            visit_variant(VisitorType&& visitors, IteratorType&& itr, PairType&& vpr)
            {
                if constexpr(StartIndex < EndIndex)
                {
                    auto& [key, vt] = vpr;
                    
                    if(auto ptr = std::get_if<StartIndex>(&vt))
                    {
                        std::get<StartIndex>(visitors.m_visitors)(std::forward<IteratorType>(itr), key, *ptr); 
                        return;
                    }
                }

                if constexpr(StartIndex + 1 < EndIndex)
                {
                    static_loop_struct<StartIndex+1, EndIndex>:: 
                        template visit_variant(std::forward<VisitorType>(visitors),
                        std::forward<IteratorType>(itr), std::forward<PairType>(vpr));
                }
            }

            template<typename VisitorType, typename IteratorType, typename VariantType>
            static std::enable_if_t<is_variant_v<remove_cv_ref_t<VariantType>>>
            visit_variant(VisitorType&& visitors, IteratorType&& itr, VariantType&& vpr)
            {
                if constexpr(StartIndex < EndIndex)
                {
                    if(auto ptr = std::get_if<StartIndex>(&vpr))
                    {
                        std::get<StartIndex>(visitors.m_visitors)(std::forward<IteratorType>(itr), *ptr);
                        return;
                    }
                }

                if constexpr(StartIndex + 1 < EndIndex)
                {
                    static_loop_struct<StartIndex+1, EndIndex>:: 
                        template visit_variant(std::forward<VisitorType>(visitors),
                        std::forward<IteratorType>(itr), std::forward<VariantType>(vpr));
                }
            }
            
        }; // end of static_loop_struct
        
        template<typename VisitorType, typename PairType>
        std::enable_if_t<is_pair_of_variant_v<remove_cv_ref_t<PairType>>> 
        visit_variant(VisitorType&& visit, PairType&& vpr)
        {
            using pair_t = remove_cv_ref_t<PairType>;
            using second_type = typename pair_t::second_type;

            static_loop_struct<0, std::variant_size_v<second_type>>:: template
                visit_variant(std::forward<VisitorType>(visit), std::forward<PairType>(vpr));
        }

        template<typename VisitorType, typename VariantType>
        std::enable_if_t<is_variant_v<remove_cv_ref_t<VariantType>>> 
            visit_variant(VisitorType&& visit, VariantType&& vt)
        {
            using variant_t = remove_cv_ref_t<VariantType>;
            
            static_loop_struct<0, std::variant_size_v<variant_t>>:: template
                visit_variant(std::forward<VisitorType>(visit),
                    std::forward<VariantType>(vt));
        }

        template<typename VisitorType, typename IteratorType, typename PairType>
        std::enable_if_t<is_pair_of_variant_v<remove_cv_ref_t<PairType>>> 
        visit_variant(VisitorType&& visit, IteratorType&& itr, PairType&& vpr)
        {
            using pair_t = remove_cv_ref_t<PairType>;
            using second_type = typename pair_t::second_type;

            static_loop_struct<0, std::variant_size_v<second_type>>:: template
                visit_variant(std::forward<VisitorType>(visit),
                    std::forward<IteratorType>(itr), std::forward<PairType>(vpr));
        }

        template<typename VisitorType, typename IteratorType, typename VariantType>
        std::enable_if_t<is_variant_v<remove_cv_ref_t<VariantType>>> 
            visit_variant(VisitorType&& visit, IteratorType&& itr, VariantType&& vt)
        {
            using variant_t = remove_cv_ref_t<VariantType>;
            
            static_loop_struct<0, std::variant_size_v<variant_t>>:: template
                visit_variant(std::forward<VisitorType>(visit),
                    std::forward<IteratorType>(itr), std::forward<VariantType>(vt));
        }

        ///////////////////////////////////////////////////
        template<typename... CallbackTypes>
        struct variant_visitors
        {
            using visitors_t = std::tuple<CallbackTypes...>;
            
            visitors_t m_visitors;

            variant_visitors(CallbackTypes... visitors):
                m_visitors{ std::move(visitors)... } { }
            
            template<typename Type>
            decltype(auto) handle (Type&& item)
            {
                return visit_variant(*this, std::forward<Type>(item));
            }

            template<typename ContainerType>
            void for_each(ContainerType&& container) 
            {
                for(decltype(auto) item: std::forward<ContainerType>(container))
                {
                    visit_variant(*this, std::forward<decltype(item)>(item));
                }
            }

            template<typename ContainerType>
            void for_each_reverse(ContainerType&& container) 
            {
                for(decltype(auto) item: reverse(std::forward<ContainerType>(container)))
                {
                    visit_variant(*this, std::forward<decltype(item)>(item));
                }
            }

            ///////////////////////////////////////////////////
            template<typename ContainerType>
            void for_each_iterator(ContainerType&& container) 
            {
                if constexpr (is_const_reference_v<ContainerType>)
                {
                    for(decltype(auto) itr = container.cbegin(); itr != container.cend(); ++itr)
                        visit_variant(*this, std::forward<decltype(itr)>(itr),
                            std::forward<decltype(*itr)>(*itr));
                }
                else
                {
                    for(decltype(auto) itr = container.begin(); itr != container.end(); ++itr)
                        visit_variant(*this, std::forward<decltype(itr)>(itr),
                            std::forward<decltype(*itr)>(*itr));
                }
            }

            ///////////////////////////
            template<typename ContainerType>
            void for_each_index(ContainerType&& container) 
            {
                if constexpr (is_const_reference_v<ContainerType>)
                {
                    for(decltype(auto) itr = container.cbegin(); 
                        itr != container.cend(); ++itr)
                    {
                        auto index = std::distance(container.cbegin(), itr);
                        visit_variant(*this, index, std::forward<decltype(*itr)>(*itr));
                    }
                }
                else
                {
                    for(decltype(auto) itr = container.begin(); 
                        itr != container.end(); ++itr)
                    {
                        auto index = std::distance(container.begin(), itr);
                        visit_variant(*this, index, std::forward<decltype(*itr)>(*itr));
                    }
                }
            }
            
            template<typename ContainerType>
            void for_each_reverse_iterator(ContainerType&& container) 
            {
                for_each_iterator(types::reverse(std::forward<ContainerType>(container)));
            }

            template<typename ContainerType>
            void for_each_reverse_index(ContainerType&& container) 
            {
                 for_each_index(types::reverse(std::forward<ContainerType>(container)));
            }

            /////////////////////////////////
            template<typename VariantType>
            std::enable_if_t<is_variant_v<remove_cv_ref_t<VariantType>>>
            operator()(VariantType&& vt)
            {
                visit_variant(*this, std::forward<VariantType>(vt));
            }

            template<typename PairType>
            std::enable_if_t<is_pair_of_variant_v<remove_cv_ref_t<PairType>>>
            operator()(PairType&& vt)
            {
                visit_variant(*this, std::forward<PairType>(vt));
            }
        };
        
        template<typename... CallbackTypes>
        variant_visitors(CallbackTypes...) -> variant_visitors<CallbackTypes...>;

        template<typename... CallbackTypes>
        variant_visitors<remove_cv_ref_t<CallbackTypes>...> 
        make_variant_visitors(CallbackTypes&& ... visitors)
        {
            return { std::forward<CallbackTypes>(visitors)... };
        }

    } // end of namespace types

    template<typename ContainerType, typename IndexType>
        decltype(auto) get_element(ContainerType container, IndexType index)
    {
        return tpf::types::get_element<ContainerType, IndexType>(container, index);
    }

    template<template<typename, typename...> class ContainerType, typename Type, typename... Types>
    decltype(auto) make_random_access_container(Type&& arg, Types&&... args)
    {
        return types::make_random_access_container<ContainerType>(std::forward<Type>(arg), std::forward<Types>(args)...);
    }

    template<typename Type, typename... Types>
    decltype(auto) make_vector(Type&& arg, Types&&... args)
    {
        return types::make_vector(std::forward<Type>(arg), std::forward<Types>(args)...);
    }

     template<typename Type, typename... Types>
    decltype(auto) make_deque(Type&& arg, Types&&... args)
    {
        return types::make_deque(std::forward<Type>(arg), std::forward<Types>(args)...);
    }

    template<typename Type, typename... Types>
    decltype(auto) make_container(Type&& arg, Types&&... args)
    {
        return types::make_container(std::forward<Type>(arg), std::forward<Types>(args)...);
    }

    #if !defined(__clang_major__)
    
    template<typename Type, typename... Types>
    decltype(auto) make_variants(Type&& arg, Types&&... args)
    {
        return types::make_variants(std::forward<Type>(arg), std::forward<Types>(args)...);
    }
    
    #endif

    template<typename ContainerType>
    decltype(auto) reverse(ContainerType&& container)
    {
        return types::reverse(std::forward<ContainerType>(container));
    }

    template<typename ElementType, size_t ElementCount> 
    decltype(auto) reverse(ElementType(&array)[ElementCount])
    {
       return types::reverse(array);
    }

    template<typename Type, typename... Types>
    decltype(auto) reverse(Type&& arg, Types&&... args)
    {
        return types::reverse(std::forward<Type>(arg), std::forward<Types>(args)...);
    }

    template<typename IndexType, typename ContainerType, typename iterator_type>
    inline auto index_to_iterator(ContainerType&& cntr, IndexType&& index)
    {
        using offset_t = tpf::remove_cv_ref_t<IndexType>;
        using diff_t = typename iterator_type::difference_type;
        auto pos = cntr.begin(); std::advance(pos, (diff_t)index);
        return pos;
    }

    template<typename IndexType, typename ContainerType, typename reverse_iterator_type>
    inline auto index_to_reverse_iterator(ContainerType&& cntr, IndexType&& index)
    {
        using offset_t = tpf::remove_cv_ref_t<IndexType>;
        using diff_t = typename reverse_iterator_type::difference_type;
        auto pos = cntr.begin(); std::advance(pos, (diff_t)index);
        
        return reverse_iterator_type{ pos };
    }

    template<typename ContainerType, typename iterator_type>
    inline auto iterator_to_index(ContainerType&& cntr, iterator_type&& itr)
    {
        return (size_t)std::distance(cntr.begin(), itr);
    }

    template<typename ContainerType, typename reverse_iterator_type>
    inline auto reverse_iterator_to_index(ContainerType&& cntr, reverse_iterator_type&& rev_itr)
    {
        auto itr = typename ContainerType::iterator_type{ rev_itr.base() };
        return (size_t)std::distance(cntr.begin(), itr);
    }

    template<direction_t direction, 
    typename ContainerType,
    typename container_t,
    typename iterator_type,
    typename reverse_iterator_type>
    auto make_rotator(ContainerType&& cntr)
    {
		using container_type = decltype(cntr);
		
        if constexpr(direction == direction_t::left)
        {
            return [](iterator_type begin, auto&& offset, iterator_type end)
            {
                using offset_t = tpf::remove_cv_ref_t<decltype(offset)>;

                if constexpr(tpf::types::is_integral_v<offset_t>)
                {   
                    using diff_t = typename iterator_type::difference_type;
                    auto offset_pos = begin; std::advance(offset_pos, (diff_t)offset);

                    return std::rotate(begin, offset_pos, end);
                }
                else if constexpr(std::is_same_v<reverse_iterator_type, offset_t>)
                {
                    return std::rotate(begin, offset.base()-1, end);
                }
                else
                    return std::rotate(begin, offset, end);
            };
        }
        else
        {
            return [](iterator_type begin, auto&& offset, iterator_type end)
            {
                using offset_t = tpf::remove_cv_ref_t<decltype(offset)>;
                                
                if constexpr(tpf::types::is_integral_v<offset_t>)
                {
                    using diff_t = typename reverse_iterator_type::difference_type;

                    auto offset_pos = reverse_iterator_type{end};
                    std::advance(offset_pos, (diff_t)offset);

                    return std::rotate(reverse_iterator_type{end}, 
                        offset_pos, reverse_iterator_type{begin});
                }
                else if constexpr(std::is_same_v<reverse_iterator_type, offset_t>)
                    return std::rotate(reverse_iterator_type{end}, offset, reverse_iterator_type{begin});
                else
                    return std::rotate(reverse_iterator_type{end}, 
                        reverse_iterator_type{offset}, reverse_iterator_type{begin});
            };
        }
    }

    template<direction_t direction, 
    typename ContainerType,
    typename container_t,
    typename iterator_type,
    typename reverse_iterator_type,
    typename execution_policy_type>
    auto make_rotator(ContainerType&& cntr, execution_policy_type policy)
    {
		using container_type = decltype(cntr);
		
        if constexpr(direction == direction_t::left)
        {
            return [policy](iterator_type begin, auto&& offset, iterator_type end)
            {
                using offset_t = tpf::remove_cv_ref_t<decltype(offset)>;

                if constexpr(tpf::types::is_integral_v<offset_t>)
                {   
                    using diff_t = typename iterator_type::difference_type;
                    auto offset_pos = begin; std::advance(offset_pos, (diff_t)offset);

                    return std::rotate(policy, begin, offset_pos, end);
                }
                else if constexpr(std::is_same_v<reverse_iterator_type, offset_t>)
                {
                    return std::rotate(policy, begin, offset.base()-1, end);
                }
                else
                    return std::rotate(policy, begin, offset, end);
            };
        }
        else
        {
            return [policy](iterator_type begin, auto&& offset, iterator_type end)
            {
                using offset_t = tpf::remove_cv_ref_t<decltype(offset)>;
                                
                if constexpr(tpf::types::is_integral_v<offset_t>)
                {
                    using diff_t = typename reverse_iterator_type::difference_type;

                    auto offset_pos = reverse_iterator_type{end};
                    std::advance(offset_pos, (diff_t)offset);

                    return std::rotate(policy, reverse_iterator_type{end}, 
                        offset_pos, reverse_iterator_type{begin});
                }
                else if constexpr(std::is_same_v<reverse_iterator_type, offset_t>)
                    return std::rotate(policy, reverse_iterator_type{end}, offset, reverse_iterator_type{begin});
                else
                    return std::rotate(policy, reverse_iterator_type{end}, 
                        reverse_iterator_type{offset}, reverse_iterator_type{begin});
            };
        }
    }

} // end of namespace tpf

/**
 * @brief A macro that tells if type_arg is a template type
 * 
 */
#define Tpf_IsTemplateV(type_arg) tpf::types::is_template_v<type_arg>

/**
 * @brief A macro that tells if instance_arg is of a template type.
 * 
 */
#define Tpf_IsTemplateInstanceV(instance_arg) tpf::types::is_template_v<decltype(instance_arg)>

#ifdef _TPF_TYPES_MIN_DEFINED
#pragma pop_macro("min")
#undef _TPF_TYPES_MIN_DEFINED
#endif 

#ifdef _TPF_TYPES_MAX_DEFINED
#pragma pop_macro("max")
#undef _TPF_TYPES_MAX_DEFINED
#endif 

#endif // end of file _TPF_TYPES_HPP
