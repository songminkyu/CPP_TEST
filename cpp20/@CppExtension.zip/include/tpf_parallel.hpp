﻿/**
 * @file tpf_parallel.hpp
 * @author your name (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2019-10-26
 * 
 * @copyright Copyright (c) 2019
 * 
 */

#ifndef _TPF_PARALLEL_HPP
#define _TPF_PARALLEL_HPP

#ifdef _MSVC_LANG  
	#if _MSVC_LANG < 201703L
		#error This libary requires C++17 Standard (Visual Studio 2017).
	#endif
#else

	#if __cplusplus < 201703
		#error This library requires C++17 Standard (GNU g++ version 8.0 or clang++ version 8.0 above)
	#endif // end of __cplusplus 

#endif // end of _MSVC_LANG

#ifdef _MSVC_LANG
    #define TBB_SUPPRESS_DEPRECATED_MESSAGES 1
#endif // end of _MSVC_LANG

#if !defined(DEBUGGING_MODE)
    #if defined(_DEBUG)
        #define DEBUGGING_MODE 1
    #elif defined(TBB_USE_DEBUG)
        #if TBB_USE_DEBUG==1
            #define DEBUGGING_MODE 1
        #else
            #define DEBUGGING_MODE 0
        #endif // TBB_USE_DEBUG==1
    #else
        #define DEBUGGING_MODE 0
    #endif // defined(_DEBUG)
#endif // !defined(DEBUGGING_MODE)

#ifndef LIB_INTERNAL_PutDebugMessageAndExit
    #define LIB_INTERNAL_PutDebugMessageAndExit(error_msg) \
    { std::cerr<<"File name ["<<__FILE__<< "]\n" \
    << "Line " << __LINE__ << " : " << error_msg; \
    std::exit(1); }
#endif // end of LIB_INTERNAL_PutDebugMessageAndExit

#ifndef Tpf_PutDebugMessageAndExit
    #define Tpf_PutDebugMessageAndExit(error_msg) LIB_INTERNAL_PutDebugMessageAndExit(error_msg)
#endif // end of Tpf_PutDebugMessageAndExit

#include <tpf_types.hpp>
#include <atomic>
#include <algorithm>
#include <execution>

#ifdef max
#define _TPF_PARALLEL_MAX_DEFINED
#pragma push_macro("max")
#undef max
#endif 

#ifdef min
#define _TPF_PARALLEL_MIN_DEFINED
#pragma push_macro("min")
#undef min
#endif 

/**
 * @brief Root namespace for C++ Extension Library
 * 
 */
namespace tpf
{
    /**
     * @brief Implements set operations
     * 
     */
    namespace parallel
    {
        template<typename ElementType, typename Operation>
        inline void atomic_operation(std::atomic<ElementType>& atom, Operation&& opr)
        {
            ElementType old_value = atom;
            ElementType new_value = opr(old_value);

            while(!atom.compare_exchange_strong(old_value, new_value))
            {
                old_value = atom;
                new_value = opr(old_value);
            }
        }

        #ifndef _TPF_ITERATOR
        #define _TPF_ITERATOR

        #ifdef __TBB_iterators_H
            
            template <typename IntType>
            using counting_iterator = tbb::counting_iterator<IntType>;

        #else
            // By courtesy of Intel's Threading Building Blocks team!!
            // With best respect and gratitude for Intel Corporation.
            template <typename IntType>
            class counting_iterator {
                static_assert(std::numeric_limits<IntType>::is_integer, "Cannot instantiate counting_iterator with a non-integer type");
            public:
                typedef typename std::make_signed<IntType>::type difference_type;
                typedef IntType value_type;
                typedef const IntType* pointer;
                typedef const IntType& reference;
                typedef std::random_access_iterator_tag iterator_category;

                counting_iterator() : my_counter() {}
                explicit counting_iterator(IntType init) : my_counter(init) {}

                reference operator*() const { return my_counter; }
                value_type operator[](difference_type i) const { return *(*this + i); }

                difference_type operator-(const counting_iterator& it) const { return my_counter - it.my_counter; }

                counting_iterator& operator+=(difference_type forward) { my_counter += forward; return *this; }
                counting_iterator& operator-=(difference_type backward) { return *this += -backward; }
                counting_iterator& operator++() { return *this += 1; }
                counting_iterator& operator--() { return *this -= 1; }

                counting_iterator operator++(int) {
                    counting_iterator it(*this);
                    ++(*this);
                    return it;
                }
                counting_iterator operator--(int) {
                    counting_iterator it(*this);
                    --(*this);
                    return it;
                }

                counting_iterator operator-(difference_type backward) const { return counting_iterator(my_counter - backward); }
                counting_iterator operator+(difference_type forward) const { return counting_iterator(my_counter + forward); }
                friend counting_iterator operator+(difference_type forward, const counting_iterator it) { return it + forward; }

                bool operator==(const counting_iterator& it) const { return *this - it == 0; }
                bool operator!=(const counting_iterator& it) const { return !(*this == it); }
                bool operator<(const counting_iterator& it) const {return *this - it < 0; }
                bool operator>(const counting_iterator& it) const { return it < *this; }
                bool operator<=(const counting_iterator& it) const { return !(*this > it); }
                bool operator>=(const counting_iterator& it) const { return !(*this < it); }

            private:
                IntType my_counter;

            }; // end of class counting_iterator
        #endif // end of __TBB_iterators_H

        #endif // end of _TPF_ITERATOR

        // The programmer can modify or adjust this value
        constexpr size_t ConcurrencyLimit = 10;

        // The programmer should not modify this value
        constexpr size_t ForceSequential = ConcurrencyLimit - 1; 
        constexpr size_t ForceParallel = ConcurrencyLimit + 1; 

        inline bool go_parallel(size_t element_count, size_t greater_than)
        {
            return (element_count > std::thread::hardware_concurrency() * greater_than);
        }

        template<typename IteratorType>
        inline bool go_parallel(IteratorType begin, IteratorType end, size_t greater_than)
        {
            auto distance = std::distance(begin, end);
            if(distance < 0) distance = - distance;

            size_t element_count = (size_t)distance;

            // return (element_count > std::thread::hardware_concurrency() * greater_than);
            return go_parallel(element_count, greater_than);
        }

        template<typename ContainerType>
        inline bool go_parallel(ContainerType&& container, size_t greater_than)
        {
            size_t element_count = container.size();
            
            //return (element_count > std::thread::hardware_concurrency()*greater_than);
            return go_parallel(element_count, greater_than);
        }

        template<typename IndexType, typename CallbackType>
        void for_index(IndexType begin_index, IndexType end_index, CallbackType&& callback,
            size_t greater_than = ConcurrencyLimit)
        {
            auto counting_begin = counting_iterator<size_t>{(size_t)begin_index};
            auto counting_end = counting_iterator<size_t>{(size_t)end_index};

            size_t minimum = begin_index < end_index ? begin_index : end_index;
            size_t maximum = begin_index < end_index ? end_index : begin_index;

            if(go_parallel(maximum - minimum, greater_than))
                std::for_each(std::execution::par_unseq,
                counting_begin, counting_end, std::forward<CallbackType>(callback));
            else
                std::for_each(counting_begin, counting_end, std::forward<CallbackType>(callback));          
       }

       template<typename ContainerType, typename CallbackType>
        void for_index(ContainerType&& container, CallbackType&& callback,
            size_t greater_than = ConcurrencyLimit)
        {
            for_index(size_t{}, container.size(),
                std::forward<CallbackType>(callback), greater_than);
        }

       template<typename IndexType, typename InitType,
            typename SumupType, typename HandleParallelType>
        auto reduce_index(IndexType begin_index, IndexType end_index, InitType&& init_value,
            SumupType&& sum_up, HandleParallelType&& handle_parallel,
            size_t greater_than = ConcurrencyLimit)
        {
            auto counting_begin = counting_iterator<size_t>{(size_t)begin_index};
            auto counting_end = counting_iterator<size_t>{(size_t)end_index};

            size_t minimum = begin_index < end_index ? begin_index : end_index;
            size_t maximum = begin_index < end_index ? end_index : begin_index;

            if(go_parallel(maximum - minimum, greater_than))
                return std::transform_reduce(std::execution::par_unseq,
                    counting_begin, counting_end, std::forward<InitType>(init_value),
                    std::forward<SumupType>(sum_up),
                    std::forward<HandleParallelType>(handle_parallel));
            else
                return std::transform_reduce(std::execution::seq,
                    counting_begin, counting_end, std::forward<InitType>(init_value),
                    std::forward<SumupType>(sum_up),
                    std::forward<HandleParallelType>(handle_parallel));          
       }

       template<typename ContainerType, typename InitType,
            typename SumupType, typename HandleParallelType>
        auto reduce_index(ContainerType&& container, InitType&& init_value,
             SumupType&& sum_up, HandleParallelType&& handle_parallel,
            size_t greater_than = ConcurrencyLimit)
        {
            return reduce_index(size_t{}, container.size(), 
                std::forward<InitType>(init_value),
                std::forward<SumupType>(sum_up),
                std::forward<HandleParallelType>(handle_parallel));         
        }

       // We will add more algorithms to augment C++ Standard library
       
    } // end of namespace parallel

} // end of namespace tpf

#ifdef _TPF_PARALLEL_MIN_DEFINED
#pragma pop_macro("min")
#undef _TPF_PARALLEL_MIN_DEFINED
#endif 

#ifdef _TPF_PARALLEL_MAX_DEFINED
#pragma pop_macro("max")
#undef _TPF_PARALLEL_MAX_DEFINED
#endif 

#endif // end of file _TPF_PARALLEL_HPP
