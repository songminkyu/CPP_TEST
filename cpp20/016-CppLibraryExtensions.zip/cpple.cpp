﻿#include <tpf_output.hpp>

/*

    g++ -std=c++17 cpple.cpp -ltbb -o g.exe
    clang++ -std=c++17 cpple.cpp -ltbb -o c.exe

    cl /EHsc /std:c++17 cpple.cpp /Fe: m.exe
*/
tpf::sstream stream;
auto endl = tpf::endl;

namespace types = tpf::types;

void test_cpp_library_extension()
{
    using age_t = int;
    using weight_t = double;
    using name_t = const char*;

    using people_t = types::container_of_tuples_t<std::list, age_t, weight_t, name_t>;
    using person_t = people_t::value_type;

    /*
        container people_t can hold persons of type person_t
    */

   stream <<"person_t: " << Tpf_GetTypeName(person_t) << endl;
   stream << "people_t: " << Tpf_GetTypeName(people_t) << endl << endl;

   people_t my_class_mates;

   my_class_mates.emplace_back(20, 56.0, "Thomas Kim");
   my_class_mates.emplace_back(19, 60.0, "Alice Lee");
   my_class_mates.emplace_back(18, 52.0, "Sophie Turner");
   my_class_mates.emplace_back(21, 70.0, "Smart Park");
   
   stream <<"My class mates are : " << my_class_mates << endl;

   stream << "We are all class mates: " << endl;

   for(auto& mate: my_class_mates)
   {
       auto& [age, weight, name] = mate;

       stream <<"I am "<< name<<", weigh " << weight << " kg, " << age <<" years old." << endl;
   }
}

int main()
{
    test_cpp_library_extension();
}