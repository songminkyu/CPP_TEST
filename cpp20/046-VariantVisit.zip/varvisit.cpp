﻿#include <tpf_output.hpp>

// clang++ -std=c++17 varvisit.cpp -ltbb -o c.exe

tpf::sstream stream;
auto endl = tpf::endl;

template<typename... Types>
struct VariantVisitor: Types...
{
    using Types::operator()...;
};

// std::remove_cvref_t<> is introduced to C++20 Standard
template<typename... Types>
// VariantVisitor(Types&&...)->VariantVisitor< std::remove_cvref_t<Types>... >;
VariantVisitor(Types&&...)->VariantVisitor< tpf::remove_cv_ref_t<Types>... >;

void test_variant_visit()
{
    using age_t = int;
    using weight_t = double;

    using item_t = std::variant<age_t, weight_t>;
    
    // container_t = std::vector<std::variant<int, double>>
    using container_t = std::vector<item_t>;

    age_t sum_of_age = 0;
    weight_t sum_of_weight = 0;

    // weight_t or double is IMPLICITLY CONVERTED TO TYPE age_t or int
    auto handle_age = [&sum_of_age](const age_t& value)
    {
        sum_of_age += value; // summation of age
    };

    // age_t or int is IMPLICITLY CONVERTED TO TYPE weight_t or double

    // prior to C++20, there is no simple and easy way
    // to prevent IMPLICIT TYPE CONVERSION!!
    auto handle_weight = [&sum_of_weight](const weight_t& value)
    {
        sum_of_weight += value; // summation of weight
    };

    container_t bag;

    bag.emplace_back(10); // age_t or int
    bag.emplace_back(20); // age_t or int
    bag.emplace_back(100.5); // weight_t or double
    bag.emplace_back(200.5); // weight_t or double

    for(auto&& var: bag)
    {
        std::visit(handle_age, var);
    }

    stream <<"sum of age: " << sum_of_age << endl;

    for(auto&& var: bag)
    {
        std::visit(handle_weight, var);
    }

    stream <<"sum of weight: " << sum_of_weight << endl;

}


void test_variant_visit_proper_way_in_cpp17()
{
    using age_t = int;
    using weight_t = double;

    using item_t = std::variant<age_t, weight_t>;
    
    // container_t = std::vector<std::variant<int, double>>
    using container_t = std::vector<item_t>;

    age_t sum_of_age = 0;
    weight_t sum_of_weight = 0;

    // weight_t or double is IMPLICITLY CONVERTED TO TYPE age_t or int
    auto handle_age = [&sum_of_age](const age_t& value)
    {
        sum_of_age += value; // summation of age
    };

    // age_t or int is IMPLICITLY CONVERTED TO TYPE weight_t or double

    // prior to C++20, there is no simple and easy way
    // to prevent IMPLICIT TYPE CONVERSION!!
    auto handle_weight = [&sum_of_weight](const weight_t& value)
    {
        sum_of_weight += value; // summation of weight
    };

    container_t bag;

    bag.emplace_back(10); // age_t or int
    bag.emplace_back(20); // age_t or int
    bag.emplace_back(100.5); // weight_t or double
    bag.emplace_back(200.5); // weight_t or double

    VariantVisitor handler{ handle_age, handle_weight };

    for(auto&& var: bag)
    {
        std::visit(handler, var);
    }

    stream <<"sum of age: " << sum_of_age << endl;
    stream <<"sum of weight: " << sum_of_weight << endl;
}


int main()
{
    // test_variant_visit();

    test_variant_visit_proper_way_in_cpp17();
}