﻿/*
    As of today, May 31, 2020, only GNU g++ version 10.1 supports C++20 ranges library

    g++ -std=c++20 ranges.cpp -ltbb -o g.exe
*/

#include <tpf_output.hpp>
#include <ranges> // for G++20 ranges library, MSVC and clang++ does not yet support ranges library

tpf::sstream stream;
auto endl = tpf::endl; // single carriage return and flush out to console
auto endL = tpf::endL; // two carriage returns and flush out to console

void test_range_views_filter()
{
    std::vector container{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    stream << "Ranges in action"<<endl;

    for(auto&& i: container)
    {
        stream << i << ", ";
    }
    stream << endL;

    // the type of i is forwarding reference
    auto even = []<typename T>(T&& i) // template parameter for lambda was introduced to C++20 Core Language.
    {
        return !(i % 2);
    };

    // the type of i is forwarding reference
    auto odd = [](auto&& i)
    {
        return i % 2; // odd number
    };

    // the type of i is forwarding reference
    auto square = [](auto&& i)
    {
        return i * i;
    };

    stream << "Ranges in action"<<endl;

    // what will be the type of i
    for(auto&& i: container)
    {
        stream << "type of i: " << Tpf_GetTypeCategory(i) << endl;

        stream << i << ", ";
    }
    stream << endL;

    // what will be the type of j
    for(auto&& j: {2, 3, 5, 7, 11} )
    {
        stream << "type of j: " << Tpf_GetTypeCategory(j) << endl;
        
        stream << j << ", ";
    }
    stream << endL;

    // whenever your algorithm does not work as expected or predicted,
    // double-check the type of the variable using Tpf_GetTypeCategory

    stream <<"Ranges in action - filter even numbers"<< endl;
    for(auto&& i: container | std::views::filter(even) )
    {
        stream << i << ", ";
    }

    stream << endL;

    stream << "Ranges in action - filter odd numbers" << endl;
    for(auto&& i: container | std::views::filter(odd))
    {
        stream << i << ", ";
    }

    stream << endL;

    //////////////////////////
    stream <<"Ranges in action - filter even numbers and square"<< endl;
    for(auto&& i: container | std::views::filter(even) | std::views::transform(square) )
    {
        stream << i << ", ";
    }

    stream << endL;

    stream << "Ranges in action - filter odd numbers and square" << endl;
    for(auto&& i: container | std::views::filter(odd) | std::views::transform(square))
    {
        stream << i << ", ";
    }

    stream << endL;
}

int main()
{
    test_range_views_filter();
}
