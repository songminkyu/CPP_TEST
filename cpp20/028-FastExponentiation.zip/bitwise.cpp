﻿#include <tpf_output.hpp>

tpf::sstream stream;
auto endl = tpf::endL;

// count bits in the mask
// mask ( 7)      : 0000 0111,  should return 3
// mask (-1)      : 1111 1111,  should return 8
// mask (0x80)    : 1000 0000,  should return 1
// mask (0)       : 0000 0000,  should return 0
// mask (1)       : 0000 0001,  should return 1

template<typename T>
using enable_if_integral = std::enable_if_t<std::is_integral<T>::value>;

template<typename T, typename = enable_if_integral<T>>
using unsigned_t = std::make_unsigned_t<T>;

template<typename T>
constexpr int bits_count = sizeof(T) * 8;

template<typename T>
constexpr unsigned_t<T> high_bit_mask 
	= unsigned_t<T>(1) << (bits_count<T>-1);

template<typename T, typename = enable_if_integral<T>>
int CountSetBits(T bits)
{
	unsigned_t<T> mask = bits;

	int count = 0;

	for (; mask; mask >>= 1)
		count += (int)(mask & 1);

	return count;
}

template<typename T, typename = enable_if_integral<T>>
std::string to_string(T bits)
{
	unsigned_t<T> mask = bits;
	
	int count = 0; std::string str;

	for (int pos = bits_count<T>; pos; mask <<= 1, --pos)
	{
		if (!str.empty() && (pos % 4 == 0))
			str.push_back(' ');

		str.push_back((mask & high_bit_mask<T>) ? '1' : '0');
	}

	return str;
}

// When it comes to shift-left bitwise operation,
// there is a huge difference between signed and unsigned integral types.
// In the Shift-Left Bitwise operation, in case of negative signed integral values,
// binary digit 1 is padded to the Most Significant Bit,
// in case of unsigned integral values, binary digit 0 is padded to the 
// Most Significant Binary Digit.
void test_shift_left_operation()
{
    char c = -3;
    unsigned char u = c;

    stream << "\nsigned" << "\t\t\t" << "unsigned" << endl;

    stream << (short)c << ": " << to_string(c) << "\t\t"
           << (short)u << ": " << to_string(u) << endl;

    c >>=1; u >>=1 ; // shift-left bitwise 1 bit.

    stream << (short)c << ": " << to_string(c) << "\t\t"
           << (short)u << ": " << to_string(u) << endl;
}

////////////////////////////////////////////////////////
int identity(int p)
{
    unsigned u = p;
    // int u = p;
    int b = 0; // 0 is additive identity
    int a = 1;

    while(u) // u != 0
    {
        if( u&1 )
        {
            b += a;
        }

        u >>= 1; // shift-left 1 bit

        a += a; 
    }

    return b;
}

void test_identity()
{
    int p = -3;

    stream << p << " = " << identity(p) << endl;
}

/////////////////////////////////////////////////
// return a x p
int fast_multiplication(int a, int p)
{
    unsigned u = p;
    // int u = p;
    int b = 0; // 0 is additive identity
    
    while(u) // u != 0
    {
        if( u&1 )
        {
            b += a;
        }

        u >>= 1; // shift-left 1 bit

        a += a; 
    }

    return b;
}

void test_fast_multiplication()
{
    int a = 5;
    int p = 3;

    stream << a <<" x " << p <<" = " << fast_multiplication(a, p) << endl;
}

//////////////////////////////////////
// 024 - Must-Know C++20 Function, std::is_constant_evaluated()
// https://www.youtube.com/watch?v=tTSoIsJaaSM&list=PL1_C6uWTeBDH6i4Rr3E2ZYLUq6_Rdq3Dr&index=25&t=239
// return a ^ p = a x a x ... x a 
int fast_power(int a, int p)
{
    unsigned u = p;
    // int u = p;
    int b = 1; // 1 is multiplicative identity
    
    while(u) // u != 0
    {
        if( u&1 )
        {
            b *= a;
        }

        u >>= 1; // shift-left 1 bit

        a *= a; 
    }

    return b;
}

void test_fast_power()
{
    int a = 5;
    int p = 3;

    stream << a <<" ^ " << p <<" = " << fast_power(a, p) << endl;
}

///////////////////////////////////////////////
// Fast Modular Powering (Exponentiation) Algorithm using Fermat's and Euler's Theorems
// https://www.youtube.com/watch?v=dV9Um1lEmbM&list=PL1_C6uWTeBDHQOcP8wpGh4Ez7pBRjSqsL&index=9&t=1325s
// returns a ^ p (mod n)
int fast_modulo_exponentiation(int a, int p, int n)
{
    unsigned u = p;
    // int u = p;
    int b = 1; // 1 is multiplicative identity
    
    while(u) // u != 0
    {
        if( u&1 )
        {
            b *= a; b %= n;
        }

        u >>= 1; // shift-left 1 bit

        a *= a; a %= n;
    }

    return b;
}

void test_fast_modulo_exponentiation()
{
    int a = 3;
    int p = 2;
    int n = 7;

    stream << a <<" ^ " << p <<" (mod "<< n <<") = " 
        << fast_modulo_exponentiation(a, p, n) << endl;
}


int main()
{
    // test_shift_left_operation();

    // test_identity();

    // test_fast_multiplication();

    // test_fast_power();

    test_fast_modulo_exponentiation();
}