﻿#include <tpf_output.hpp>

tpf::sstream stream;
auto endl = tpf::endL;

// count bits in the mask
// mask ( 7)      : 0000 0111,  should return 3
// mask (-1)      : 1111 1111,  should return 8
// mask (0x80)    : 1000 0000,  should return 1
// mask (0)       : 0000 0000,  should return 0
// mask (1)       : 0000 0001,  should return 1

template<typename T>
using enable_if_integral = std::enable_if_t<std::is_integral<T>::value>;

template<typename T, typename = enable_if_integral<T>>
using unsigned_t = std::make_unsigned_t<T>;

template<typename T>
constexpr int bits_count = sizeof(T) * 8;

template<typename T>
constexpr unsigned_t<T> high_bit_mask 
	= unsigned_t<T>(1) << (bits_count<T>-1);

template<typename T, typename = enable_if_integral<T>>
int CountSetBits(T bits)
{
	unsigned_t<T> mask = bits;

	int count = 0;

	for (; mask; mask >>= 1)
		count += (int)(mask & 1);

	return count;
}

template<typename T, typename = enable_if_integral<T>>
std::string to_string(T bits)
{
	unsigned_t<T> mask = bits;
	
	int count = 0; std::string str;

	for (int pos = bits_count<T>; pos; mask <<= 1, --pos)
	{
		if (!str.empty() && (pos % 4 == 0))
			str.push_back(' ');

		str.push_back((mask & high_bit_mask<T>) ? '1' : '0');
	}

	return str;
}

// When it comes to shift-left bitwise operation,
// there is a huge difference between signed and unsigned integral types.
// In the Shift-Left Bitwise operation, in case of negative signed integral values,
// binary digit 1 is padded to the Most Significant Bit,
// in case of unsigned integral values, binary digit 0 is padded to the 
// Most Significant Binary Digit.
void test_shift_left_operation()
{
    char c = -3;
    unsigned char u = c;

    stream << "\nsigned" << "\t\t\t" << "unsigned" << endl;

    stream << (short)c << ": " << to_string(c) << "\t\t"
           << (short)u << ": " << to_string(u) << endl;

    c >>=1; u >>=1 ; // shift-left bitwise 1 bit.

    stream << (short)c << ": " << to_string(c) << "\t\t"
           << (short)u << ": " << to_string(u) << endl;
}

////////////////////////////////////////////////////////
int identity(int p)
{
    unsigned u = p;
    // int u = p;
    int b = 0; // 0 is additive identity
    int a = 1;

    stream << "a = {";

    while(u) // u != 0
    {
        if( u&1 )
        {
            b += a;

            stream << a << " ";
        }

        u >>= 1; // shift-left 1 bit

        a += a; 
    }

    stream << "} "<< endl; // if you don't flush to console with endl, you cannot see anything.

    return b;
}

void test_identity()
{
    int p = 7;

    // stream << p << " = " << 
    identity(p) ;
    
    // << endl;
}


int main()
{
    test_identity();
}