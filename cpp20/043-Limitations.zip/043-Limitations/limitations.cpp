﻿#include <tpf_output.hpp>

namespace types = tpf::types;

tpf::sstream stream;
auto endl = tpf::endl;

void test_type_list_functions()
{
    using list_t = types::type_list_t<int, long long, double>;

    stream <<"Types in the list_t: " << list_t{} << endl;

    stream <<"Is short in the list ? " << types::is_type_in_list_v<short, list_t> << endl;
    stream <<"Is int in the list ? " << types::is_type_in_list_v<int, list_t> << endl;

    using first_t = types::first_type_t<list_t>;

    stream <<"First type: " << Tpf_GetTypeName(first_t) << endl;

    using second_t = types::select_nth_type_t<1, list_t>;

    stream <<"Second type: " << Tpf_GetTypeName(second_t) << endl;

    using last_t = types::last_type_t<list_t>;

    stream << "Last type: " << Tpf_GetTypeName(last_t) << endl;

    using types_t = types::type_list_t<short, int, unsigned short, short, double, int, float>;

    stream <<"Types are : " << types_t{} << endl;

    using unique_types_t = types::unique_types_t<types_t>;

    stream <<"Unique types are " << unique_types_t{} << endl;

}

// suppose we want to interrogate if a certain member is supported by a class

template<typename ClassName>
concept has_ma = requires (ClassName obj)
{
    obj.ma; // this is simple requirement
};

class ClassA
{
    public:
        int ma;
};

class ClassB
{
    public:
        int mb;
};

#define Tpf_HasMember(membername) template<typename ClassName> \
concept has_##membername = requires(ClassName obj) { obj.membername; }

// this method does not expand well!!
Tpf_HasMember(mb);

void test_reflection_missing()
{
    stream << "Does ClassA have member ma ?" << has_ma<ClassA> << endl;
    stream << "Does ClassB have member ma ?" << has_ma<ClassB> << endl;

    stream << "Does ClassA have member mb ? " << has_mb<ClassA> << endl;
    stream << "Does ClassB have member mb ? " << has_mb<ClassB> << endl;

}

int main()
{
    // test_type_list_functions();

    test_reflection_missing();
}