﻿#include <iostream>
#include <cmath>
#include <type_traits>

auto& stream = std::cout;
auto endl = std::endl<char, std::char_traits<char>>;

/*
    constexpr together with std::is_constant_evaluated() will be 
    a huge game changer in C++20 programming.

    COMPILER EXPLORER
    https://godbolt.org/

    x86-64 clang++ version 10.0.0 or above
    -std=c++2a switch

    constexpr (C++)
    https://docs.microsoft.com/en-us/cpp/cpp/constexpr-cpp?view=vs-2019

    std::is_constant_evaluated()
    http://www.open-std.org/jtc1/sc22/wg21/docs/papers/2018/p0595r2.html

*/

namespace test
{
    template<typename BaseType, typename ExpType>
    constexpr auto pow(BaseType base, ExpType exp)
    {
        if(std::is_constant_evaluated() && // if base and exp are literal values,
                                           // then std::is_constant_evaluated() returns true
            std::is_integral_v<ExpType> && exp >= 0)
        {
            // 1. the function should be specified with keyword constexpr
            // 2. the function should be called with literals, in this case,
            //    base and exp should be literal at the function call-site.
            // 3. in the compile-time code section, we cannot call or access
            //    run-time code or constructs.

            BaseType r = BaseType{1};
            BaseType p = base;

            unsigned u = (unsigned)exp;

            // I will not explain this part of the code
            // it requires understanding bitwise operation.
            while( u != 0)
            {
                if(u & 1) r *= p; // that is, the last bit of exp is 1,
                                  // then multiply with p (or base)
                
                u >>=1; // is equivalent to u = u / 2

                // p = std::pow(3.0, 1.0);

                p *= p;
            }

            return r;
        }
        else
        {
            // at run-time, we can access both compile-time constructs and runtime constructs.
            return (BaseType)std::pow((double)base, (double)exp);
        }
    }
} // end of namespace test

void test_constexpr_compile_time()
{
    constexpr auto p0 = test::pow(2.0, 0);
    constexpr auto p1 = test::pow(2.0, 1);
    constexpr auto p2 = test::pow(2.0, 2);
    constexpr auto p3 = test::pow(2.0, 3);

    stream << "p0 = " << p0 << endl;
    stream << "p1 = " << p1 << endl;
    stream << "p2 = " << p2 << endl;
    stream << "p3 = " << p3 << endl;

    int e1 = 1; // e1 is run-time code

    constexpr int c1 = 1; // c1 is compile-time expression

    auto p4 = test::pow(2.0, e1); // both p4 and e1 are run-time constructs
    constexpr auto p5 = test::pow(2.0, c1); // both p5 and c1 are compile-time constructs

    auto p6 = test::pow(2.0, c1); // p6 is runtime code, c1 is compile-time construct

    /*
        We can access compile-time constructs at runtime.
        But we cannot access run-time constructs at compile-time

    */

}

int main()
{
    test_constexpr_compile_time();
}