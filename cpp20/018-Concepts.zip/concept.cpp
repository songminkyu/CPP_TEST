﻿#include <tpf_output.hpp>
/*
    clang++ -std=c++2a concept.cpp -ltbb -o c.exe
*/

tpf::sstream stream;
auto endl = tpf::endl;

// C++ 98 syntax
template<typename T, typename S>
auto simple_modulo_without_constaints(T p, S q)
{
    // return the remainder of p/q
    // modulo operator % is defined over integral types, such as short, int, unsigned int, long, unsigned long long
    // but we cannot use % over floating point types, such as float or double
    return p % q;
}

void test_simple_modulo_without_constraints()
{
    int p{5};
    // double p{5};
    int q{3};

    auto r = simple_modulo_without_constaints(p, q);

    stream <<"Remainder r of " << p <<"/" << q <<" = " << r << endl;

}

////////////////////////////////////////////////////

template<typename T, typename S,
    typename = std::enable_if_t<std::is_integral_v<T> && std::is_integral_v<S>>>
auto module_conventional_method_with_constraints_over_parameter_types(T p, S q)
{
    return p % q;
}

void test_module_conventional_method_with_constraints_over_parameter_types()
{
    int p{5};
    // double p{5};
    int q{3};

    auto r = module_conventional_method_with_constraints_over_parameter_types(p, q);

    stream <<"Remainder r of " << p <<"/" << q <<" = " << r << endl;

}

//////////////////////////////////////////////////////////////////////
template<typename T>
concept IntegralType = std::is_integral_v<T>;

template< IntegralType T, IntegralType S>
auto modulo_with_concept_constraints(T p, S q)
{
    return p % q;
}

void test_modulo_with_concept_constraints()
{
    // int p{5};
    double p{5};
    int q{3};

    auto r = modulo_with_concept_constraints(p, q);

    stream <<"Remainder r of " << p <<"/" << q <<" = " << r << endl;

}

int main()
{
    // test_simple_modulo_without_constraints();

    // test_module_conventional_method_with_constraints_over_parameter_types();

    test_modulo_with_concept_constraints();
}