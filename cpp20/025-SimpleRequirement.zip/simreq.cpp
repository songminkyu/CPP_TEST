﻿#include <tpf_output.hpp>

tpf::sstream stream;
auto endl = tpf::endl;

namespace test
{
    template<typename Type1, typename Type2>
    struct st_is_same_template
    {
        static constexpr bool value = false;
    };

    template< template<typename, typename...> class ContainerType,
        typename Type1, typename... Types1,
        typename Type2, typename... Types2>
    struct st_is_same_template< ContainerType<Type1, Types1...>, ContainerType<Type2, Types2...> >
    {
        static constexpr bool value = true;
    };

    template<typename Type1, typename Type2>
    concept is_same_template_helper = st_is_same_template< std::remove_cvref_t<Type1>, 
        std::remove_cvref_t<Type2> >::value;

} // end of namespace test

template<typename Type1, typename Type2>
concept is_same_template_c =  test::is_same_template_helper<Type1, Type2> 
        && test::is_same_template_helper<Type2, Type1>; 

template<typename ContainerType>
concept is_pop_front_supported_c = requires (ContainerType container)
    {
        container.pop_front(); // this is simple-requirement
                                // simple-requirement asserts the validity of the expression
    };

template<typename ContainerType>
concept is_reverse_supported_c = requires (ContainerType container)
    {
        container.reserve(size_t{1}); // simple-requirement asserts the validity of the expression
    };

void test_if_template_same()
{
    using vector_t_1 = std::vector<int>;
    using vector_t_2 = std::vector<double>;
    using deque_t = std::deque<int>;

    stream << "vector_t_1 == vector_t_2 ? "
        << std::is_same_v<vector_t_1, vector_t_2> << endl;

    stream << "vector_t_1 == vector_t_2 ? "
        << is_same_template_c<vector_t_1, vector_t_2> << endl;

    stream << "vector_t_1 == deque_t ? "
        << is_same_template_c<vector_t_1, deque_t> << endl;

    stream <<"does vector_t_1 support pop_front(): " 
        << is_pop_front_supported_c<vector_t_1> << endl;

    stream <<"does vector_t_2 support pop_front(): " 
        << is_pop_front_supported_c<vector_t_2> << endl;

    stream <<"does deque_t support pop_front(): " 
        << is_pop_front_supported_c<deque_t> << endl;

    stream <<"does vector_t_1 support reserve(): " 
        << is_reverse_supported_c<vector_t_1> << endl;

    stream <<"does vector_t_2 support reserve(): " 
        << is_reverse_supported_c<vector_t_2> << endl;

    stream <<"does deque_t support reserve(): " 
        << is_reverse_supported_c<deque_t> << endl;
}

template<typename ContainerType>
void pop_front(ContainerType& container)
{
    if constexpr(is_pop_front_supported_c<ContainerType>)
    {
        container.pop_front();
    }
    else if constexpr(is_same_template_c<std::vector<int>, ContainerType>)
    {
        container.erase(container.begin());
    }
}

template<typename ContainerType, typename SizeType>
void reserve(ContainerType& container, SizeType size)
{
    if constexpr(is_reverse_supported_c<ContainerType>)
    {
        container.reserve((size_t)size);
    }
}

void test_how_to_use_simple_requirements()
{
    using vector_t_1 = std::vector<int>;
    using vector_t_2 = std::vector<double>;
    using deque_t = std::deque<int>;

    vector_t_1 v{1, 2, 3, 4};
    deque_t d{1, 2, 3};

    stream <<"Before pop_front:" << endl;
    stream << "v = " << v << endl;
    stream << "d = " << d << endl;

    pop_front(v); pop_front(d);

    stream <<"After pop_front:" << endl;
    stream << "v = " << v << endl;
    stream << "d = " << d << endl;

    vector_t_2 v2;
    deque_t d2;

    stream << "Capacity of v2 before reserve: " << v2.capacity() << endl;

    reserve(v2, 10);
    reserve(d2, 10);

    stream << "Capacity of v2 after reserve: " << v2.capacity() << endl;
    
}

int main()
{
    // test_if_template_same();

    test_how_to_use_simple_requirements();
}