﻿
#include <tpf_output.hpp>

tpf::sstream stream;
auto endl = tpf::endl;

namespace types = tpf::types;

// types::type_list_t is defined
// template<typename... Types> 
// struct type_list_t { };

template<typename... Types>
using Unprocessed = types::type_list_t<Types...>;

template<typename... Types>
using Processed = types::type_list_t<Types...>;

void test_type_list()
{
    using types_1 = Unprocessed<int, short, float>;
    using types_2 = Processed<float, double>;

    stream <<"types_1: " <<  types_1{} << endl;
    stream <<"types_2: " <<  types_2{} << endl;
}

///////////////////////////////////////
// We will use a function without function body

namespace tpf::types
{
    template<typename... Ts_1, typename... Ts_2>
    constexpr types::type_list_t<Ts_1..., Ts_2...> // return type
    operator + ( types::type_list_t<Ts_1...>, types::type_list_t<Ts_2...> );

    // this funcion does not have function body
    template<typename... Types>
    constexpr auto add_types() -> decltype( (Types{} + ...) );
}

void test_add_types()
{
    using t1 = types::type_list_t<short, int>;
    using t2 = types::type_list_t<char, wchar_t>;
    using t3 = types::type_list_t<float, double, long double>;

    using added_types = decltype(types::add_types<t1, t2, t3>());

    stream <<"added_types: " << added_types{} << endl;
}

////////////////////////////////////////////////////////////

namespace tpf::types
{
    // primary template determines the count of template arguments
    template<typename... Types> struct st_subtract_type;

    template<typename... Ps, typename S, typename... Us>
    struct st_subtract_type<S, Processed<Ps...>, Unprocessed<S, Us...>>
    {
        using type = typename st_subtract_type<S, Processed<Ps...>, Unprocessed<Us...>>::type;
    }; 

    template<typename S, typename... Ps, typename H, typename... Us>
    struct st_subtract_type<S, Processed<Ps...>, Unprocessed<H, Us...>>
    {
        using type = typename st_subtract_type<S, Processed<Ps..., H>, Unprocessed<Us...>>::type;
    };

    template<typename S, typename... Ps>
    struct st_subtract_type<S, Processed<Ps...>, Unprocessed<>>
    {
        using type = Processed<Ps...>;
    };

    template<typename S, typename TypeList> // TypeList == Unprocessed type list
    using subtract_type = typename st_subtract_type<S, Processed<>, TypeList>::type;

    #ifdef __clang_major__
        // we save warning
        #pragma clang diagnostic push
        #pragma clang diagnostic ignored "-Wundefined-inline"
    #endif

    template<typename TypeList, typename S>
    constexpr subtract_type<S, TypeList> // return type
    operator - (TypeList, S); // does not have function body

    #ifdef __clang_major__
        // restore warning
        #pragma clang diagnostic pop
    #endif
    
    template<typename TypeList, typename... Ss>
    constexpr auto subtract_types_fn() // empty function parameters
    {
        // fold expression(since C++17)
	    // https://en.cppreference.com/w/cpp/language/fold
        // ( init op ... op pack )	(4)
        return (TypeList{} - ... - Ss{});
    }

    template<typename TypeList, typename... Ss>
    using subtract_types_t = decltype(subtract_types_fn<TypeList, Ss...>());

} // end of namespace tpf::types;

void test_subtract_type()
{
    using t1 = Unprocessed<char, int, float, int, double>;
    using t2 = types::subtract_type<int, t1>; // subtract int from <char, int, float, double>

    stream <<"t1: " << t1{} << endl;
    stream <<"t2: " << t2{} << endl;

    // using t3 = decltype(types::subtract_types_fn<t1, int, float>());

    using t3 = types::subtract_types_t<t1, int, float>;

    stream <<"t3: " << t3{} << endl;

}

int main()
{
    // test_type_list();

    // test_add_types();

    test_subtract_type();
}