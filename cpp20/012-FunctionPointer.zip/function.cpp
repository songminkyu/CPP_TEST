#include "tpf/types.hpp"

/*

    clang++ -std=c++2a function.cpp -ltbb -ltbbmalloc_proxy -o c.exe
    g++ -std=c++2a function.cpp -ltbb -ltbbmalloc_proxy -o g.exe

    cl /EHsc /std:c++latest function.cpp /Fe: m.exe
*/
#include <iostream>

auto& cout = std::cout;
auto endl = std::endl<char, std::char_traits<char>>;

// 011 - Function Type, Function Pointer, Function Reference, Function Instance, Function Type Decay
// https://www.youtube.com/watch?v=jE99raMC-qI&list=PL1_C6uWTeBDH6i4Rr3E2ZYLUq6_Rdq3Dr&index=13


// sum is the name of an instance of type int(int, int)
int sum(int a, int b)
{
    return a + b;
}

// pro is the name of an instance of type int(int, int)
int pro(int a, int b)
{
    return a * b;
}

/*

    we declared or defined an instance dbl_t of type double         we declared an instance fnc_t of type int(double, int)
    double dbl_t;                                                   int fnc_t(double, int);


    now dbl_t is a type alias for double                            fnc_t is a type alias for int(double, int)
    typedef double dbl_t;                                           typedef int fnc_t(double, int);
*/

int sum_indirect( int (&fnc_t)(int, int) )
{
    int s = fnc_t(2, 3);

    return s;
}


void test_function_call_indirect()
{
    auto s = sum_indirect(sum);

    cout << "sum(2, 3) = " << s << endl;

    auto p = sum_indirect(pro);

    cout << "pro(2, 3) = " << p << endl;
}

using fnc_t = int(int, int);         // typedef int fnc_t(int, int);
using funcr_t = int(&)(int, int);   // typedef int (&funcr_t)(int, int);
using fptr_t = int(*)(int, int);    // typedef int (*fptr_t)(int, int);

// int call_indirect(fnc_t& f, int a, int b)

int call_indirect(funcr_t f, int a, int b)
{
    auto rlt = f(a, b); // call function f indirectly

    return rlt;
}

void test_indirect_call()
{
    auto s = call_indirect(sum, 4, 5);

    cout << "sum(4, 5) = " << s << endl;

    auto p = call_indirect(pro, 3, 4);

    cout <<"pro(3, 4) = " << p << endl;
}

///////////////////////

int call_indirect_with_pointer(fptr_t fptr, int a, int b)
{
    auto rlt = fptr(a, b); // call function f indirectly

    return rlt;
}

void test_indirect_call_with_pointer()
{
    auto s = call_indirect_with_pointer(sum, 4, 5); // the type of sum is int(int, int)
                                                    // but the type of int(*)(int, int)

    // int(int, int) -> int(__cdecl *)(int, int), we can ignore __cdecl for the time being
    // int(int, int) -> int(*)(int, int), this conversion is called function-to-function-pointer conversion,
    // or simply function decay, or just decay
    auto fs = sum; // the type of sum is decayed to pointer type automatically

    cout <<"the type of fs : " << Tpf_GetTypeCategory(fs) << endl;
    cout <<"the type of sum : " << Tpf_GetTypeCategory(sum) << endl;

    cout << "sum(4, 5) = " << s << endl;

    auto p = call_indirect_with_pointer(pro, 3, 4); // the type of pro is int(int, int)
                                                    // the type of fptr is int(*)(int, int)
    cout <<"pro(3, 4) = " << p << endl;
}


int main()
{
    // test_function_call_indirect();

    // test_indirect_call();

    test_indirect_call_with_pointer();
}