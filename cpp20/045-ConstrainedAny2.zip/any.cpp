﻿#include <tpf_output.hpp>

#include "tpf_any.hpp"

tpf::sstream stream;
auto endl = tpf::endl;

void _1_test_element_types()
{
    tpf::types::any<int, short, double, int, short> a;

    stream <<"Allowed Element Types: " 
        << decltype(a)::element_types_t{} << endl;

    stream <<"Helper Pointer Types: " 
        << decltype(a)::pointer_types_t{} << endl;

    stream <<"Element and Pointer Types: " 
        << decltype(a)::element_pointer_types_t{} << endl;
}

void _2_test_constructors()
{
    // allowed types: int and double
    using any_t = tpf::types::any<int, double, float>;

    // it works, because 3 is of type int
    any_t a = 3;

    any_t d = 3.4;

    any_t f = 3.5f;

    // f = 'c';

    // a = 5ll;

}

void _3_test_get()
{
    // allowed types: int and double
    using any_t = tpf::types::any<int, double>;

    any_t a{5}, b{3.4};

    auto aa = a.get<int>();
    auto ptr = a.get<int*>();

    stream << "aa = " << aa << endl;
    stream << "ptr = " << *ptr << endl;
}

void _4_test_output()
{

     // allowed types: int and double
    using any_t = tpf::types::any<int, double>;

    any_t a{5}, b{3.4};

    stream <<"a = " << a << endl;

    stream <<"b = " << b << endl;

    auto aa = a;
    auto bb = b;

    stream <<"aa = " << aa << endl;
    stream <<"bb = " << bb << endl;

    aa += 7;
    bb += 0.6;

    stream <<"aa = " << aa << endl;
    stream <<"bb = " << bb << endl;

    stream << "current type of aa: "
        << tpf::types::current_type(aa) << endl;

    stream << "current type of bb: "
        << tpf::types::current_type(bb) << endl;

    aa = 3.4;
    bb = 21;

    stream <<"aa = " << aa << endl;
    stream <<"bb = " << bb << endl;

    stream << "current type of aa: "
        << tpf::types::current_type(aa) << endl;

    stream << "current type of bb: "
        << tpf::types::current_type(bb) << endl;

    stream << "allowed types of aa: "
        << aa.allowed_types() << endl;

    stream << "allowed types of bb: "
        << bb.allowed_types() << endl;
}

void _5_test_constrained_any()
{
    using age_t = int;
    using weight_t = double;
    using name_t = std::string;
    using price_t = float;

    // any_t can hold objects of type age_t, weight_t, name_t, price_t
    using any_t = tpf::types::any<age_t, weight_t, name_t, price_t>;

    using container_t = std::vector<any_t>;

    container_t my_bag;

    my_bag.emplace_back(30); // 30 is of type int, age_t
    my_bag.emplace_back(45.6); // 45.6 is of type double, weight_t
    my_bag.emplace_back(std::string("Thomas Kim")); // std::string is name_t
    my_bag.emplace_back(13.4f); // 13.4f is of type float, price_t
    my_bag.emplace_back(std::string("My Dear Audience")); // std::string is name_t

    stream <<"There are " << my_bag << " in my bag!" << endl;

}


void _6_test_visit_individual_elements()
{
    using age_t = int;
    using weight_t = double;
    using name_t = std::string;
    using price_t = float;

    // any_t can hold objects of type age_t, weight_t, name_t, price_t
    using any_t = tpf::types::any<age_t, weight_t, name_t, price_t>;

    using container_t = std::vector<any_t>;

    container_t my_bag;

    my_bag.emplace_back(30); // 30 is of type int, age_t
    my_bag.emplace_back(45.6); // 45.6 is of type double, weight_t
    my_bag.emplace_back(std::string("Thomas Kim")); // std::string is name_t
    my_bag.emplace_back(13.4f); // 13.4f is of type float, price_t
    my_bag.emplace_back(std::string("My Dear Audience")); // std::string is name_t

    stream <<"There are " << my_bag << " in my bag!" << endl;

    auto handle_age = [](age_t value)
    {
        stream <<"My age is " << value << endl;
    };

    auto handle_weight = [](weight_t value)
    {
        stream << "My weight is " << value << endl;
    };

    auto handle_name = [](name_t value)
    {
        stream << "My name is " << value << endl;
    };

    auto handle_ignore = [](auto&& value)
    {
        stream << value << " is ignored " <<endl;
    };

    tpf::types::any_visitors visitors{handle_age, handle_weight, handle_ignore };

    stream << "Visit each elements of container, elements of type any_t" << endl;

    for(auto&& any: my_bag)
    {
        tpf::types::visit_any(visitors, any);
    }  

}


void _7_test_modify_specific_types()
{
    using age_t = int;
    using weight_t = double;
    using name_t = std::string;
    using price_t = float;

    // any_t can hold objects of type age_t, weight_t, name_t, price_t
    using any_t = tpf::types::any<age_t, weight_t, name_t, price_t>;

    using container_t = std::vector<any_t>;

    container_t my_bag;

    my_bag.emplace_back(30); // 30 is of type int, age_t
    my_bag.emplace_back(45.6); // 45.6 is of type double, weight_t
    my_bag.emplace_back(std::string("Thomas Kim")); // std::string is name_t
    my_bag.emplace_back(13.4f); // 13.4f is of type float, price_t
    my_bag.emplace_back(std::string("My Dear Audience")); // std::string is name_t

    stream <<"Before Modification: " << my_bag << endl;

    auto handle_age = [](age_t& value)
    {
        value *= 2;
    };

    auto handle_name = [](name_t& value)
    {
        value += " is my love!";    
    };

    auto handle_ignore = [](auto&& value) { };

    tpf::types::any_visitors visitors{handle_age, handle_name, handle_ignore };

    for(auto&& any: my_bag)
    {
        tpf::types::visit_any(visitors, any);
    }  

    stream <<"After Modification: " << my_bag << endl;
}


int main()
{
    // _5_test_constrained_any();

    // _6_test_visit_individual_elements();

    _7_test_modify_specific_types();
}