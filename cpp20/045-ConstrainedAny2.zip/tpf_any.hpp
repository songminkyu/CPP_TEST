﻿/**
 * @file tpf_any.hpp
 * @author Thomas Kim (ThomasKim@TalkPlayFun.com)
 * @brief Stream output operators << are implemented.
 * @version 0.1
 * @date 2020-07-24
 * 
 * @copyright Copyright (c) 2020
 * 
 */

#ifndef _TPF_ANY_HPP
#define _TPF_ANY_HPP

#ifdef _MSVC_LANG  
	#if _MSVC_LANG < 201703L
		#error This libary requires C++17 Standard (Visual Studio 2017).
	#endif
#else

	#if __cplusplus < 201703
		#error This library requires C++17 Standard (GNU g++ version 8.0 or clang++ version 8.0 above)
	#endif // end of __cplusplus 

#endif // end of _MSVC_LANG

#include <tpf_types.hpp>

#ifdef max
#define _TPF_ANY_MAX_DEFINED
#pragma push_macro("max")
#undef max
#endif 

#ifdef min
#define _TPF_ANY_MIN_DEFINED
#pragma push_macro("min")
#undef min
#endif 

namespace tpf::types
{
    template<typename... ElementTypes>
    class any
    {
		public:
			using element_types_t = unique_types_t<ElementTypes...>;
			
			using pointer_types_t = 
				unique_types_t< std::add_pointer_t<ElementTypes>... >;
			
			using element_pointer_types_t = 
				union_type_t<element_types_t, pointer_types_t>;

		protected:
			std::any m_any;

		public:

			any(): m_any{} { }

			std::any& std() noexcept { return m_any; }
			const std::any& std() const noexcept { return m_any; }

			constexpr auto allowed_types() const noexcept
				{ return element_types_t{}; }

			// if Type is not in the list, element_types_t,
			// this constructor is disabled
			template<typename Type,
				typename = enable_if_in_list_t<remove_cv_ref_t<Type>, element_types_t>>
			any(Type&& arg): m_any{ std::forward<Type>(arg) } { }

			any(const any&) = default;
			any(any&&) = default;

			any& operator=(const any&) = default;
			any& operator=(any&&) = default;

			// value assignment operator
			template<typename Type,
			typename = enable_if_in_list_t<remove_cv_ref_t<Type>, element_types_t>>
			any& operator=(Type&& arg)
			{
				this->m_any = std::forward<Type>(arg);
				return *this;
			}

			template<typename Type,
				typename = enable_if_in_list_t<remove_cv_ref_t<Type>, element_pointer_types_t>>
			Type get()
			{
				// https://en.cppreference.com/w/cpp/utility/any/any_cast
				if constexpr( std::is_pointer_v< remove_cv_ref_t<Type>>)
					return std::any_cast<std::remove_pointer_t<Type>>(&this->m_any);
				else
					return std::any_cast<Type>(this->m_any);
			}

			///////////////////////////////////////////
			template<typename Type,
			typename = enable_if_in_list_t<remove_cv_ref_t<Type>, element_types_t>>
			any& operator+=(Type&& arg)
			{
				using type = remove_cv_ref_t<Type>;
				this->get<type&>() += std::forward<Type>(arg);
				return *this;
			}


    }; // end of class any

	template<typename... CallbackTypes>
	struct any_visitors: public CallbackTypes...
	{
		using CallbackTypes::operator()...;
	};

	template<typename... CallbackTypes>
	any_visitors(CallbackTypes...)->any_visitors<CallbackTypes...>;

	template<typename Type, typename... Types>
	struct st_print_any
	{
		template<typename AnyType>
		static void print_any(std::ostream& os, AnyType&& a)
		{
			if(auto ptr = std::any_cast<Type>(&a.std()))
				os << *ptr;
			else
			{
				if constexpr(sizeof...(Types) != 0)
					st_print_any<Types...>::print_any(os, a);
			}
		}

		template<typename AnyType>
		static std::string current_type(AnyType&& a)
		{
			if(auto ptr = std::any_cast<Type>(&a.std()))
				return Tpf_GetTypeName(Type);
			else
			{
				if constexpr(sizeof...(Types) != 0)
					return st_print_any<Types...>::current_type(a);
				else // this part never really executed
					return "To suppress syntax error";
			}
		}
	};

	template<typename Type, typename... Types>
	struct st_print_any<type_list_t<Type, Types...>>
	{
		template<typename AnyType, typename Visitors>
		static void visit_any(Visitors&& visitors, AnyType&& a)
		{
			if(auto ptr = std::any_cast<Type>(&a.std()))
				visitors(*ptr);
			else
			{
				if constexpr(sizeof...(Types) != 0)
					st_print_any<type_list_t<Types...>>::
						visit_any(visitors, std::forward<AnyType>(a));
			}
		}
	};

	template<typename... ElementTypes>
	std::ostream& operator<<(std::ostream& os, 
		const any<ElementTypes...>& a)
		{
			st_print_any<ElementTypes...>::print_any(os, a);
			return os;
		}

	template<typename... ElementTypes>
	std::string current_type(const any<ElementTypes...>& a)
		{
			return st_print_any<ElementTypes...>::current_type(a);
		}

	template<typename Visitors, typename AnyType>
	void visit_any(Visitors&& visitors, AnyType&& a)
		{
			using any_t = remove_cv_ref_t<AnyType>;
			
			st_print_any<typename any_t::element_types_t>::
				visit_any(visitors, std::forward<AnyType>(a));
		}

} // end of namespace tpf::types


#ifdef _TPF_ANY_MIN_DEFINED
#pragma pop_macro("min")
#undef _TPF_ANY_MIN_DEFINED
#endif 

#ifdef _TPF_ANY_MAX_DEFINED
#pragma pop_macro("max")
#undef _TPF_ANY_MAX_DEFINED
#endif 

#endif // end of file _TPF_ANY_HPP