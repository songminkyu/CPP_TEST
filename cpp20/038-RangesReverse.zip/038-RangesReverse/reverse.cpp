﻿#include <tpf_output.hpp>
#include <ranges>

// g++ -std=c++20 reverse.cpp -ltbb -o r.exe
// As of Today, June 25, 2020, only g++ version 10.1 supports Ranges library
// MSVC, LLVM/clang++ do not yet support ranges library
//

tpf::sstream stream;
auto endl = tpf::endl;

void test_reverse_adaptor()
{
    std::vector v{1, 2, 3 ,4, 5, 6, 7, 8, 9, 10};

    for(auto&& e: std::views::all(v))
    {
        stream << e << ", ";
    }

    stream << endl; // don't forget to flush out to console, otherwise, you may not see anything.

    for(auto&& e: std::views::reverse(v))
    {
        stream << e << ", ";
    }

    stream << endl; 
}

void test_take_adaptor()
{
    std::vector v{1, 2, 3 ,4, 5, 6, 7, 8, 9, 10};

    for(auto&& e: std::views::all(v) | std::views::take(5))
    {
        stream << e << ", ";
    }

    stream << endl; // don't forget to flush out to console, otherwise, you may not see anything.

    for(auto&& e: std::views::reverse(v) | std::views::take(5))
    {
        stream << e << ", ";
    }

    stream << endl; 
}

// the order of the adaptors does matter!!!
void test_custom_adaptor()
{
    std::vector v{1, 2, 3 ,4, 5, 6, 7, 8, 9, 10};

    auto even = [](auto&& e)
    {
        return !(e % 2); // if e is even, return true
    };

    for(auto&& e: std::views::all(v) | std::views::filter(even) | std::views::take(5))
    {
        stream << e <<", ";
    }

    stream << endl; // don't foget to flush out to console

    for(auto&& e: std::views::all(v) | std::views::take(5) | std::views::filter(even))
    {
        stream << e <<", ";
    }

    stream << endl; // don't foget to flush out to console
}

void test_custom_adaptor_pretty()
{
    std::vector v{1, 2, 3 ,4, 5, 6, 7, 8, 9, 10};

    auto odd_filter = std::views::filter([](auto&& e)
    {
        return e % 2;  // returns true if e is odd
    });

    for(auto&& e: std::views::all(v) | odd_filter | std::views::take(5))
    {
        stream << e <<", ";
    }

    stream << endl; // don't foget to flush out to console

    for(auto&& e: std::views::all(v) | std::views::take(5) | odd_filter)
    {
        stream << e <<", ";
    }

    stream << endl; // don't foget to flush out to console
}

int main()
{
    // test_reverse_adaptor();

    // test_take_adaptor();

    // test_custom_adaptor();

    test_custom_adaptor_pretty();
}