#include "tpf/types.hpp"

#include <iostream>

/*
    keyword auto always creates a new instance either using copy-constructor or move constructor,
        and drops off const.

    keyword auto& always ends up lvalue reference, either const lvalue reference or non-const lvalue reference.

    keyword auto&& ends up either lvalue reference or rvalue reference.

    C++ committee needed decltype(auto) that can be non-reference types as auto,
        and reference types as auto& or auto&&.
*/

auto& cout = std::cout;
auto endl = std::endl<char, std::char_traits<char>>;

double sum(int a, int b)
{
    return double(a + b);
}

void learn_decltype()
{
    int a = 5;

    using type_a = decltype(a); // returns the declared type of an object

    using type_a_p = decltype( (a) ); // returns the value category of an object

    cout <<"type of type_a : " << Tpf_GetTypeName(type_a) << endl;
    cout <<"type of type_a_p : " << Tpf_GetTypeName(type_a_p) << endl;

    using sum_t = decltype(sum); // returns the type of function sum

    using return_t = decltype(sum(1, 2)); // returns the return type of the function sum

    cout <<"type of sum_t: " << Tpf_GetTypeName(sum_t) << endl;
    cout <<"type of return_t: " << Tpf_GetTypeName(return_t) << endl;

}

void test_auto_and_decltype_auto()
{
    int a = 5;
    const int c = 5;

    auto b = a;
    cout <<"type of b: " << Tpf_GetTypeCategory(b) << endl;

    auto d = c;
    cout << "type of d: " << Tpf_GetTypeCategory(d) << endl;

    decltype(auto) d_ac = c;
    cout << "type of d_ac: " << Tpf_GetTypeCategory(d_ac) << endl;

    // so, auto maps to int and const int, and ends up int.
    // auto is copy-semantic, a new instance is created using copy-constructor

    auto& a_l = a;
    cout <<"type of a_l: " << Tpf_GetTypeCategory(a_l) << endl;

    auto&& a_r_l = a_l; // it does not work. a_r_l will end up as int&.
    cout <<"the type of a_r_l: " << Tpf_GetTypeCategory(a_r_l) << endl;

    cout << "the address of a_l  : " << (&a_l) << endl;
    cout << "the address of a_r_l: " << (&a_r_l) << endl;

    auto&& a_rr_l = (int)a_l; 
    cout <<"the type of a_rr_l: " << Tpf_GetTypeCategory(a_rr_l) << endl;

    cout << "the address of a_l   : " << (&a_l) << endl;
    cout << "the address of a_rr_l: " << (&a_rr_l) << endl;

    auto& c_l = c;
    cout << "type of c_l: " << Tpf_GetTypeCategory(c_l) << endl;

    auto&& a_r = a; // a is lvalue, 
    cout <<"type of a_r: " << Tpf_GetTypeCategory(a_r) << endl;

    auto&& c_r = c;
    cout <<"type of c_r: " << Tpf_GetTypeCategory(c_r) << endl;

    auto&& r_r = 5; // "rvalue reference" references to a memory location.
                    // r_r itself is lvalue, or its value category is lvalue

    cout << "type of r_r: " << Tpf_GetTypeCategory(r_r) << endl;
    using value_category_of_r = decltype( (r_r) );
    cout << "the value category of r_r: " << Tpf_GetTypeName(value_category_of_r) << endl;
    cout << "the value category of r_r: " << Tpf_GetTypeCategory( (r_r) ) << endl;
    /*
      the type of r_r is int&& (rvalue reference)
      r_r is lvalue, do not get confused lvalue with lvalue reference
      rvalue with rvalue reference.

      Both lvalue reference and rvalue reference are LVALUE, because "reference" means "address of memory."

      lvalue always has its memory, but rvalue may or may not.
    */

   auto& r_r_l = r_r; // we assign int&& (r_r) to int& (r_r_l), because r_r has memory address, because int&&.

    cout << "type of r_r_l: " << Tpf_GetTypeCategory(r_r_l) << endl;
    cout <<"the address of r_r  : " << (&r_r) << endl;
    cout <<"the address of r_r_l: " << (&r_r_l) << endl;


    decltype(auto) r_da = 5;
    cout << "type of r_da: " << Tpf_GetTypeCategory(r_da) << endl;

    decltype(auto) d_a = a;
    cout <<"type of d_a: " << Tpf_GetTypeCategory(d_a) << endl;

    decltype(auto) d_a_p = (a); // (expression) is primary expression
    cout <<"type of d_a_p (a): " << Tpf_GetTypeCategory(d_a_p) << endl;

    decltype(auto) d_a_l = (int&)a;
    cout <<"type of d_a_l (int&): " << Tpf_GetTypeCategory(d_a_l) << endl;

    decltype(auto) d_ar = std::move(a);
    cout <<"type of d_ar: " << Tpf_GetTypeCategory(d_ar) << endl;


}

int main()
{
    // learn_decltype();

    test_auto_and_decltype_auto();
}