#include "tpf/template.hpp"

/*
    In case of g++ and clang++

    g++ -std=c++2a hello.cpp -ltbb -ltbbmalloc_proxy -o g.exe
    clang++ -std=c++2a hello.cpp -ltbb -ltbbmalloc_proxy -o g.exe

    In case of MSVC
    cl /EHsc /std:c++latest hello.cpp /Fe: m.exe
*/
#include <iostream>

int main()
{
    #ifdef _MSVC_LANG

        std::cout << "_MSVC_LANG: " <<
            _MSVC_LANG << std::endl;
    #else

        std::cout <<"__cplusplus: " <<
            __cplusplus << std::endl;
    #endif

}