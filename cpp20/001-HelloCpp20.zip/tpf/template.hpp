#ifndef TPF_TEMPLATE_HPP
#define TPF_TEMPLATE_HPP

#ifndef CPP_STD_20_VER
/* Update CPP_STD_20_VER to 202002L in future */
#define CPP_STD_20_VER 201705L 
#endif

// we are using Microsoft C++ compiler
#ifdef _MSVC_LANG

#ifndef NOMINMAX
#undef NOMINMAX
#endif

#if _MSVC_LANG < CPP_STD_20_VER
    #error Requires C++20 Standard compatible compiler
#else
    
    #ifndef TBB_SUPPRESS_DEPRECATED_MESSAGES
    #define TBB_SUPPRESS_DEPRECATED_MESSAGES 1
    #endif

    #include <tbb/tbbmalloc_proxy.h>
#endif 

// we are using GNU g++ or clang++ compiler
#else
    #ifndef __cplusplus
        #error Requires C++20 Standard compatible compiler
    #else
        #if __cplusplus < CPP_STD_20_VER
            #error Requires C++20 Standard compatible compiler
        #else
            // put GNU g++ or clang++ specific header files in this block

        #endif 

    #endif // end of __cplusplus

#endif // end of _MSVC_LANG




#endif // end of file