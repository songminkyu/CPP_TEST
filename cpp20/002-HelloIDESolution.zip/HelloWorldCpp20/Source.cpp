#include "tpf/template.hpp"

int main()
{
	std::cout << "Hello World, C++20!!" << std::endl;
}