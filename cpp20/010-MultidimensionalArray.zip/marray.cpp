/*
    Modern C++ Type System is very complex. If you keep watching my videos, you will completely understand
    C++ type system. Once you have crystal clear understanding of C++ type system,
    C++ language is at least manageable. Please don't skip my videos even if the title of the video
    may not seem appealing to you.
*/

#include "tpf/types.hpp"

#include <iterator> // we need iterator for array, such as std::begin(), std::end() for array access
#include <iostream>

namespace types = tpf::types;

auto& cout = std::cout;
auto endl = std::endl<char, std::char_traits<char>>;

void test_type_of_std_cout()
{
    cout <<"type of std::cout - "
        << Tpf_GetTypeCategory(std::cout) << endl;

    /*
        Whenever your C++ compiler complains of type mismatch, interrogate C++ type system
        using 
        
        Tpf_GetTypeCategory(instance of a type) or

        Tpf_GetTypeName(type)
    */

   // use decltype(an instance) to extract the type of the instance or object
   using cout_t = decltype(std::cout);

    cout << "The type of cout_t: " << Tpf_GetTypeName(cout_t) << endl;

}
void _1_access_1_dimensional_array()
{
    const int a[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int b[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    // 1. ranged-for access
    for(auto& e: a)
    {
        cout << e << ", ";

        cout <<"type of e: " << types::type_to_string<decltype(e)>() << endl;
    }

    cout << endl;

    for(auto& e: b)
    {
        cout << e << ", ";

        cout <<"type of e: " << types::type_to_string<decltype(e)>() << endl;
    }

    cout << endl;

    /*
        auto& can map to const type& and type&, where a type is a C++ type.
        Please keep this point in mind.
    */

   // std::begin(array type) returns pointer
   // pointer itself should be a value, not reference
   // auto& p = std::begin(array type) does not work
   // it should auto p = std::begin(array type)
   for(auto itr = std::begin(a);  itr != std::end(a);  ++itr)
   {
       cout << *itr << ", ";
   }

   cout << endl;

    // whenever we use iterator, use keyword auto, not auto&
   for(auto itr = std::rbegin(b); itr != std::rend(b); ++itr)
   {
       cout << *itr <<", ";
   }

   cout << endl; 
}

template<typename ArrayType>
void get_array(ArrayType array) // don't do this
{
    cout << "The type of array: " << Tpf_GetTypeCategory(array) << endl;
}

template<typename ArrayType>
void get_array_better(ArrayType& array)
{
    cout << "The type of array: " << Tpf_GetTypeCategory(array) << endl;

    const auto array_size = types::array_size(array);

    for(size_t i{}; i < array_size; ++i)
    {
        cout << array[i] << ", ";
    }

    cout << endl;
}

// ArrayType: type template parameter
// ArrayCount: non-type template parameter
template<typename ArrayType, size_t ArrayCount>
void get_array_in_cpp_way(  ArrayType (& array) [ArrayCount]  )
{
    for(size_t i{}; i < ArrayCount; ++i)
    {
        cout << array[i] << ", ";
    }

    cout << endl;
}

void _2_pass_array_to_function()
{
    int a[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    // get_array(a);

    // get_array_better(a);

    get_array_in_cpp_way(a);

}

// template<typename T, size_t N, size_t M>: template-head
// template-head:
// template <template-parameter-list> requires-clause-opt
// T: type template parameter
// N, M: non-type template parameter
// In C++, we can use placeholder auto in template-parameter-list
// We can use auto in place of non-type template parameter
template<typename T, auto N, auto M>
void get_2_dimensional_array( T (& a) [N][M] )
{

    for(size_t i{}; i < N; ++i)
    {
        for(size_t j{}; j < M; ++j)
        {
            cout << a[i][j] << ", ";
        }

        cout << endl;
    }

    cout << endl;
}

void _3_pass_multidimensional_array()
{
    int m[][3] {  {1, 2, 3}, 
                  {4, 5, 6}, 
                  {7, 8, 9}, 
                  {10, 11, 12}  }; // 4 x 3 array

    
    get_2_dimensional_array(m);
}

int main()
{
    // _1_access_1_dimensional_array();

    // test_type_of_std_cout();

    // _2_pass_array_to_function();

    _3_pass_multidimensional_array();
}