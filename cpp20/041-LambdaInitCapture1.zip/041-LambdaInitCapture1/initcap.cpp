﻿#include <tpf_output.hpp>

tpf::sstream stream;
auto endl = tpf::endl;

// we defined a concept called "paraname"
template<typename>
concept paraname = true;

struct Output
{
    friend Output& operator<<(Output& out, paraname auto&& param)
    {
        stream << param <<" ";
        return out;
    }

    ~Output()
    {
        stream << endl;
    }
};

// this syntax was introduced to C++20 Standard,
// and it turns out to be very powerful for modern C++ programming.

// template<typename... Type>
// void print_out_parameters(Type&& ... args)
void print_out_parameters(paraname auto&& ... args)
{
    Output out;

    (out << ... << args);
}

using allowed_types = tpf::types::type_list_t<int, long long, float, double>;

// we allow only int and long long
template<typename Type>
concept Real = tpf::types::is_type_in_list_v< std::remove_cvref_t<Type>, allowed_types>;

// Having solid understanding of the types of the function-call arguments
// is crucial for successful modern C++ programming.
//
// How can we figure out the types of args... ?
auto sum(Real auto&&... args)
{
    return (args + ...);
}

void test_paraname()
{
    int a = 5;
    double b = 3.14;

    print_out_parameters(a, b, 3, 3.4f);
}

void test_fold_expression_with_concept()
{
    auto rlt = sum(1.2, 2, 3, 4, 5, 6, 7, 8, 9, 10.8);

    stream << "1+...+10 = " << rlt << endl;
}

void test_minor_defects()
{
    Output out;

    int a = 5;

    out << "a is " << a << endl;

    out << "literal 5 = " << 5;
}

auto pack_to_types(paraname auto&&... args)-> tpf::types::type_list_t<decltype(args)...>;
#define Tpf_PackToTypes(args) decltype(pack_to_types(std::forward<decltype(args)>(args)...))

auto summation(Real auto&& ... args)
{
    using args_types_t = Tpf_PackToTypes(args);

    stream <<"Types of args: " << args_types_t{} << endl;

    using first_t = tpf::types::first_type_t<args_types_t>;
    using last_t = tpf::types::last_type_t<args_types_t>;

    using second_t = tpf::types::select_nth_type_t<1, args_types_t>;

    stream <<"First type: " << Tpf_GetTypeName(first_t) << endl;
    stream <<"Last type: " << Tpf_GetTypeName(last_t) << endl;
    stream <<"Second type: " << Tpf_GetTypeName(second_t) << endl;

    return (args + ...);
}

void test_pack_to_types()
{
    int i = 5;
    const int c = 3;
    double d = 3.14;

    summation(i, c, d, 4.5f, 4ll);
}

int main()
{
    // test_paraname();

    // test_fold_expression_with_concept();

    // test_minor_defects();

    test_pack_to_types();
}