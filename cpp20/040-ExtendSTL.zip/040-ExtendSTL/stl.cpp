﻿#include <tpf_output.hpp>
#include <ranges>

tpf::sstream stream;
auto endl = tpf::endl;

void test_new_syntax()
{
    for(std::vector<double> v{0, 1.1, 2, 3.1, 4, 5, 6, 7, 8, 9.9} ; // init-statements for range-based for
                                                        // this syntax is introduced to C++20 Standard
        auto&& i: std::views::iota(size_t{}, v.size()))
        {
            //039 - C++20 Ranges Library Tutorial 3 - Concepts in Ranges, itoa & transform
	        // https://www.youtube.com/watch?v=tq0pg2FVNN8&list=PL1_C6uWTeBDH6i4Rr3E2ZYLUq6_Rdq3Dr&index=40

            stream << v[i] << ", ";
        }

    stream << endl;
}

namespace trl // TutoRiaL
{
     // 039 - C++20 Ranges Library Tutorial 3 - Concepts in Ranges, itoa & transform
     // https://www.youtube.com/watch?v=tq0pg2FVNN8&list=PL1_C6uWTeBDH6i4Rr3E2ZYLUq6_Rdq3Dr&index=40

    template<typename ContainerType>
    concept RandomAccessContainer = std::ranges::random_access_range<ContainerType>;

    template<typename ContainerType>
    concept SizeSupported = requires (ContainerType container)
    {
        container.size(); // we are testing if container has member function size()
                            // this is called SIMPLE requirement.
    };

    template<typename ContainerType>
    concept StlRandomAccessContainer = SizeSupported<ContainerType> && RandomAccessContainer<ContainerType>;

    auto size(StlRandomAccessContainer auto&& container)
    {
        return container.size();
    }

    // returns array's element count
    template<typename T, size_t N>
    inline constexpr auto size(const T(&)[N]) { return N; }

    // this syntax is introduced to C++20 Standard
    auto iota(RandomAccessContainer auto&& container)
    {
        return std::views::iota(size_t{}, std::size(container));
    }
}

void test_extend_stl()
{
    std::vector<double> v{0, 1.1, 2, 3.1, 4, 5, 6, 7, 8, 9.9} ; 
    // std::deque<double> v{0, 1.1, 2, 3.1, 4, 5, 6, 7, 8, 9.9} ; 
    // double v[]{0, 1.1, 2, 3.1, 4, 5, 6, 7, 8, 9.9} ; 

    for(auto&& i: trl::iota(v) )
    {
        stream << v[i] << ", ";
    }

    stream << endl;
}

int main()
{
    // test_new_syntax();

    test_extend_stl();
}