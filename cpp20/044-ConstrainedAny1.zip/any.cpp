﻿#include <tpf_output.hpp>

#include "tpf_any.hpp"

tpf::sstream stream;
auto endl = tpf::endl;

void _1_test_element_types()
{
    tpf::types::any<int, short, double, int, short> a;

    stream <<"Allowed Element Types: " 
        << decltype(a)::element_types_t{} << endl;

    stream <<"Helper Pointer Types: " 
        << decltype(a)::pointer_types_t{} << endl;

    stream <<"Element and Pointer Types: " 
        << decltype(a)::element_pointer_types_t{} << endl;
}

void _2_test_constructors()
{
    // allowed types: int and double
    using any_t = tpf::types::any<int, double, float>;

    // it works, because 3 is of type int
    any_t a = 3;

    any_t d = 3.4;

    any_t f = 3.5f;

    // f = 'c';

    // a = 5ll;

}

void _3_test_get()
{
    // allowed types: int and double
    using any_t = tpf::types::any<int, double>;

    any_t a{5}, b{3.4};

    auto aa = a.get<int>();
    auto ptr = a.get<int*>();

    stream << "aa = " << aa << endl;
    stream << "ptr = " << *ptr << endl;
}

void _4_test_output()
{

     // allowed types: int and double
    using any_t = tpf::types::any<int, double>;

    any_t a{5}, b{3.4};

    stream <<"a = " << a << endl;

    stream <<"b = " << b << endl;

    auto aa = a;
    auto bb = b;

    stream <<"aa = " << aa << endl;
    stream <<"bb = " << bb << endl;

    aa += 7;
    bb += 0.6;

    stream <<"aa = " << aa << endl;
    stream <<"bb = " << bb << endl;

    stream << "current type of aa: "
        << tpf::types::current_type(aa) << endl;

    stream << "current type of bb: "
        << tpf::types::current_type(bb) << endl;

    aa = 3.4;
    bb = 21;


    stream <<"aa = " << aa << endl;
    stream <<"bb = " << bb << endl;

    stream << "current type of aa: "
        << tpf::types::current_type(aa) << endl;

    stream << "current type of bb: "
        << tpf::types::current_type(bb) << endl;

    stream << "allowed types of aa: "
        << aa.allowed_types() << endl;

    stream << "allowed types of bb: "
        << bb.allowed_types() << endl;


}

int main()
{
    // _1_test_element_types();

    // _2_test_constructors();

    // _3_test_get();

    _4_test_output();
}