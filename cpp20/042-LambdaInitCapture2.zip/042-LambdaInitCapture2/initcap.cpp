﻿#include <tpf_output.hpp>

tpf::sstream stream;
auto endl = tpf::endl;

// we defined a concept called "paraname"
template<typename>
concept paraname = true;

struct Output
{
    friend Output& operator<<(Output& out, paraname auto&& param)
    {
        stream << param <<" ";
        return out;
    }

    ~Output()
    {
        stream << endl;
    }
};

// this syntax was introduced to C++20 Standard,
// and it turns out to be very powerful for modern C++ programming.

// template<typename... Type>
// void print_out_parameters(Type&& ... args)
void print_out_parameters(paraname auto&& ... args)
{
    Output out;

    (out << ... << args);
}

using allowed_types = tpf::types::type_list_t<int, long long, float, double>;

// we allow only int and long long
template<typename Type>
concept Real = tpf::types::is_type_in_list_v< std::remove_cvref_t<Type>, allowed_types>;

// Having solid understanding of the types of the function-call arguments
// is crucial for successful modern C++ programming.
//
// How can we figure out the types of args... ?
auto sum(Real auto&&... args)
{
    return (args + ...);
}

void test_paraname()
{
    int a = 5;
    double b = 3.14;

    print_out_parameters(a, b, 3, 3.4f);
}

void test_fold_expression_with_concept()
{
    auto rlt = sum(1.2, 2, 3, 4, 5, 6, 7, 8, 9, 10.8);

    stream << "1+...+10 = " << rlt << endl;
}

void test_minor_defects()
{
    Output out;

    int a = 5;

    out << "a is " << a << endl;

    out << "literal 5 = " << 5;
}

// 041 - New C++20 Syntax - Pack Expansion in Lambda Init-Capature 1/2
// https://www.youtube.com/watch?v=GQTT31R7pfg&list=PL1_C6uWTeBDH6i4Rr3E2ZYLUq6_Rdq3Dr&index=42
auto pack_to_types(paraname auto&&... args)-> tpf::types::type_list_t<decltype(args)...>;
#define Tpf_PackToTypes(args) decltype(pack_to_types(std::forward<decltype(args)>(args)...))

auto summation(Real auto&& ... args)
{
    using args_types_t = Tpf_PackToTypes(args);

    stream <<"Types of args: " << args_types_t{} << endl;

    using first_t = tpf::types::first_type_t<args_types_t>;
    using last_t = tpf::types::last_type_t<args_types_t>;

    using second_t = tpf::types::select_nth_type_t<1, args_types_t>;

    stream <<"First type: " << Tpf_GetTypeName(first_t) << endl;
    stream <<"Last type: " << Tpf_GetTypeName(last_t) << endl;
    stream <<"Second type: " << Tpf_GetTypeName(second_t) << endl;

    return (args + ...);
}

void test_pack_to_types()
{
    int i = 5;
    const int c = 3;
    double d = 3.14;

    summation(i, c, d, 4.5f, 4ll);
}


void test_type_category_value_category()
{
    int a = 5;
    double d = 3.14;

    // What is the type category of "a" ?
    // What is the value category of "d" ?

    using a_type_category_t = decltype(a);
    using a_value_category_t = decltype( (a) ); 

    stream << "The type category of a is " << Tpf_GetTypeName(a_type_category_t) << endl;
    stream << "The value category of a is " << Tpf_GetTypeName(a_value_category_t) << endl;

}

auto forward_function_template1(paraname auto&& callable, Real auto&& ... args)
{
    stream <<"Type of callable: " << Tpf_GetTypeCategory(callable) << endl;
    using args_types_t = Tpf_PackToTypes(args);

    stream << "Types of args: " << args_types_t{} << endl;

  return callable( std::forward<decltype(args)>(args)... );
}

// this method is awfully bad!!!
void test_forward_function_template()
{
    int a = 5;
    double d = 3.14;

    // auto sum_specialization = sum<decltype(a), decltype(d)>;

    // // error: cannot bind rvalue reference of type 'int&&' to lvalue of type 'int' ?
    // forward_function_template1(sum_specialization, std::move(a), std::move(d));

    ////////////////////////////////
    auto sum_specialization = sum<decltype(a)&, decltype(d)&>;

    // error: cannot bind rvalue reference of type 'int&&' to lvalue of type 'int' ?
    forward_function_template1(sum_specialization, a, d);
}

void test_the_better_way_to_forward_function_template()
{
    int a = 5;
    double d = 3.14;
    
    auto sum_specialization = [](auto&&... args)
    {
        return sum(std::forward<decltype(args)>(args)...);
    };

    forward_function_template1(sum_specialization, a, d);
}

auto set_values(paraname auto&& ... values)
{
    auto my_share = [ &... values = values ](auto&& count)
    {
        return (values + ...) / count;
    };

    return my_share;
}

void test_my_share()
{
    auto get_my_share = set_values(1, 2, 3, 4);

    stream <<"My share is " << get_my_share(4.0) << endl;
}

int main()
{
    // test_paraname();

    // test_fold_expression_with_concept();

    // test_minor_defects();

    // test_pack_to_types();

    // test_type_category_value_category();

    // test_forward_function_template();

    // test_the_better_way_to_forward_function_template();

    test_my_share();
}