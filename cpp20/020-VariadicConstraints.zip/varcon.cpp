﻿// fold expression(since C++17)
// https://en.cppreference.com/w/cpp/language/fold

#include <tpf_output.hpp>

tpf::sstream stream;
auto endl = tpf::endl;

namespace types = tpf::types;

template<typename... Types>
auto sum(Types... args)
{
    return (args + ...); // (1... +(7+(8+(9 + 10)))...)
}

template<typename... Types>
auto sum2(Types... args)
{
    return (... + args); // ( (((1+2)+3)+4 ... + 10)
}

template<typename Type>
auto man(Type a, Type b = Type{0})
{
    return a + b;
}

template<typename... Types>
auto sum3(Types... args)
{
    return ( man(args, 1) + ...); 

    /*
        man(10, 1)
        man(9, 1)

        (man(1, 1)...+(man(7, 1) + (man(8, 1) + (man(9, 1) + man(10, 1))))))
    */
}

template<typename... Types>
auto sum4(Types... args)
{
    return ( man(args) + ...); 
}

void test_fold_expression()
{
    stream << "sum(1, 2, 3, 4, 5, 6, 7, 8, 9, 10): "
        << sum(1, 2, 3, 4, 5, 6, 7, 8, 9, 10) << endl;

    stream << "sum2(1, 2, 3, 4, 5, 6, 7, 8, 9, 10): "
        << sum2(1, 2, 3, 4, 5, 6, 7, 8, 9, 10) << endl;

    stream << "sum3(1, 2, 3, 4, 5, 6, 7, 8, 9, 10): "
        << sum3(1, 2, 3, 4, 5, 6, 7, 8, 9, 10) << endl;

    stream << "sum4(1, 2, 3, 4, 5, 6, 7, 8, 9, 10): "
        << sum4(1, 2, 3, 4, 5, 6, 7, 8, 9, 10) << endl;
}

int main()
{
    test_fold_expression();
}
