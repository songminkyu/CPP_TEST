﻿#include <tpf_output.hpp>

tpf::sstream stream;
auto endl = tpf::endl;

namespace types = tpf::types;

/*
    Pay attention to these terms;

    prototype parameter,

    constraint,

    type-constraint,

    requires-clause
*/

// the first type template parameter is T.
// T is the prototype parameter of same_as.
// when the first template parameter of a concept, same_as, is
// a type template paramter, the concept can be used as type-constraint
template<typename T, typename S>
concept same_as = std::is_same_v<T, S> && std::is_same_v<S, T>;

// associated constraints
// the associated constraint of function sum
// is same_as<T, S>
template<typename T, typename S> // template-head
    requires same_as<T, S> // requires constraint-expression, here same_as<T, S> is a contraint
auto sum(T a, S b)
{
    return a + b;
}

void test_constraint()
{
    stream << "sum(1, 2): " << sum(1, 2) << endl;

    // stream << "sum(1, 2.5): " << sum(1, 2.5) << endl;
}

// template<typename T, typename S>
//   requires same_as<S, T>
// NOT requires same_as<T, S> X
// the first template parameter of the concept same_as
// is type, so the concept same_as is type concept.
// same_as<T> is used to constraint both type T and S,
// such use of concept in template parameter list
// is called type-constraint.
template<typename T, same_as<T> S> // same_as<S, T>, NOT same_as<T, S>
auto pro(T a, S b)
{
    return a * b;
}

void test_constraint_type_constraint()
{
    stream <<"pro(2, 3) : " << pro(2, 3) << endl;
}

int main()
{
    // test_constraint();

    test_constraint_type_constraint();
}
