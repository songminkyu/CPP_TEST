﻿#include <tpf_output.hpp>

tpf::sstream stream;
auto endl = tpf::endl;

namespace types = tpf::types;

template<typename T, typename S>
concept same_as = std::is_same_v<T, S> && std::is_same_v<S, T>;

template<typename T, typename... Types>
    requires (same_as<Types, T> && ...)
auto sum1(T a, Types... args)
{
    // fold expression(since C++17)
    // https://en.cppreference.com/w/cpp/language/fold
    
    // return (a + ... + args);
    return ( args + ... + a);
}

// same_as<T> is used to constrain both T and Types...
// such use of same_as<T>...Types is called Variadic Template Type-Constraints.
template<typename T, same_as<T>... Types>
auto sum2(T a, Types... args)
{
    return ( args + ... + a);
}

void test_constraints()
{
    stream << "sum1(1, 2, 3, 4) : " 
        << sum1(1, 2, 3, 4) << endl;

    // stream << "sum1(1, 2, 3, 4) : " 
    //     << sum1(1, 2, 3.3, 4) << endl;

    stream << "sum2(1, 2, 3, 4) : " 
        << sum2(1, 2, 3, 4) << endl;

    // stream << "sum2(1, 2, 3.3, 4) : " 
    //     << sum2(1, 2, 3.3, 4) << endl;
}

int main()
{
    test_constraints();
}