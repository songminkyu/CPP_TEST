﻿#include <tpf_output.hpp>
#include <any>

tpf::sstream stream;
auto endl = tpf::endl;

void test_any_basic()
{
    auto a = std::make_any<int>(1);

    std::any b; // uninitialized any

    if(a.has_value())
    {
        stream <<"a has value" << endl;
    }
    else
    {
        stream <<"a does not have value yet."<<endl;
    }

    if(b.has_value())
    {
        stream <<"b has value" << endl;
    }
    else
    {
        stream <<"b does not have value yet."<<endl;
    }
}

void test_retrieve_value_from_any()
{
    std::any a{1};

    if(a.has_value())
    {
        int b = std::any_cast<int>(a);

        stream <<"the value of any a is " << b << endl;

    }
    else
    {
        stream <<"a does not have value yet."<<endl;
    }

    // if std::any is not initialized or does not have value yet,
    std::any b;

    // it will fail throwing an exception
    // https://en.cppreference.com/w/cpp/utility/any/any_cast

    try
    {
        // and accessed or retrieved the value of an instance of any,
        int c = std::any_cast<int>(b);

        stream <<"This message will not be displayed" << endl;
    }
        // it throws std::bad_any_cast exception
    catch(const std::bad_any_cast& e)
    {
        std::cerr << e.what() << '\n';
    }
  
}

void test_retrieve_pointer_to_internal_object()
{
    std::any a{3.14};

    try
    {
        double *ptr = std::any_cast<double>( &a );

        stream <<"The value of a is " << *ptr << endl;
        
    }
    catch(const std::bad_any_cast& e)
    {
        std::cerr << e.what() << '\n';
    }
}

void test_more_example_for_any_cast()
{
    std::any a;

    a = 3.14;
    stream <<"The value of a: " << std::any_cast<double>(a) << endl;

    a = "Thomas Kim";
    stream <<"The value of a: " << std::any_cast<const char*>(a) << endl;

    a = 10;
    stream <<"The value of a: " << std::any_cast<int>(a) << endl;

}

namespace tpf
{
    class any: public std::any
    {
        public:

            // using declaration -
            // it means we are going to access constructors of std::any
            using std::any::any;

        // this is a conversion operator that converts
        // from tpf::any to TargetType
        // this conversion operator is NOT yet perfect.
        // I will further fine-tune this conversion operator in the future episode
        template<typename TargetType>
        operator TargetType() const
        {
            return std::any_cast<TargetType>( *this );
        }

    };
}


void test_tpf_any()
{
    tpf::any a;

    a = 3.14;
    stream <<"The value of a: " << (double)a << endl;

    a = "Thomas Kim";
    stream <<"The value of a: " << (const char*)a << endl;

    a = 10;
    stream <<"The value of a: " << (int)a << endl;
}

void test_tpf_any_further()
{
    tpf::any a;

    a = 3.14;
    double d = a;

    stream <<"The value of a: " << d << endl;

    a = "Thomas Kim";
    const char* c = a;

    stream <<"The value of a: " << c << endl;

    a = 10;
    int n = a;

    stream <<"The value of a: " << n << endl;
}

void test_std_any_further()
{
    std::any a;

    a = 3.14;
    double d = std::any_cast<double>(a);

    stream <<"The value of a: " << d << endl;

    a = "Thomas Kim";
    const char* c = std::any_cast<const char*>(a);

    stream <<"The value of a: " << c << endl;

    a = 10;
    int n = std::any_cast<int>(a);

    stream <<"The value of a: " << n << endl;
}



int main()
{
    // test_any_basic();

    // test_retrieve_value_from_any();

     // test_retrieve_pointer_to_internal_object();

    // test_more_example_for_any_cast();

    // test_tpf_any();

    // test_tpf_any_further();

    test_std_any_further();
}