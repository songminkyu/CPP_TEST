April 19, 2020 - The Programming Language C++20 Standard
	By Thomas Kim

022 - The C++ 20 Concepts Tutorial 5, Keyword requires, requires-expression, requires-clause

As per Working Draft, Standard for Programming Language C++
A concept is a template that defines constraints over its template arguments.

A constraint is a sequence of logical operations and operands that specify
requirements over the template arguments of the constrained entity.
The operands in the sequence of the logical operations are constraints.

A requirement is one that can be checked by name lookup and by
checking properties of types and expressions.

template<typename T, typename S>
concept concept_name = constraint_expression;
					 = requires (T p, S q)_opt
						{
							// this is simple-requirement
							// in case of simple-requirement
							// the operands p and q are unevaluated operands
							// the expression is not evaluated.
							// the C++ compiler checks the validity
							// of the expression.
							// if both p and q are of integral types,
							// and p % q is a valid operation
							
							p % q ; // p and q are unevaluated operation
						}
						
template<typename T, typename S>
	requires requires 
			{
				// in case of nested-requirement,
				// the constant-expression is evaluated at compile-time
				requires std::is_integral_v<T> && std::is_integral_v<S>;
			}
class rational
{
};

template<typename T, typename S>
	requires concept_name<T, S> // concept-id is one of the id-expressions
auto sum(T a, T b)
{
	return a + b;
}

template<typename T, typename S>
auto pro(T a, S b) noexcept -> decltype(a + b) 
	requires requires { a + b; }
{
	return a + b;
}

constraint-logical-or-expression:
	constraint-logical-and-expression
	constraint-logical-or-expression || constraint-logical-and-expression
	
constraint-logical-and-expression:
	primary-expression
	constraint-logical-and-expression && primary-expression
	
primary-expression:
	literal
	this
	(expression)
	lambda_expression
	fold_expression
	id_expression // id_expression is a template name followed by template argument
					// concept_name<T> -- id_expression, concept-id
	requires-expression
	
requires-expression: 
	requires (parameter_list)_opt
	{
		requirement-seq
	}
	
requirement-seq:
	requirement
	requirement-seq requirement
	
requirement:
	simple_requirement ; // performs semantic validity checking
	type_requirement ;
	compound_requirement ;
	nested_requirement ; // evaluate the constant-expression
	
nested_requirement: 
	requires constant-expression (or compile-time expression)
	
Contact Thomas Kim:	
	http://www.TalkPlayFun.com/Contacts

Current ISO C++ status
	https://isocpp.org/std/status
	
Useful resources
	https://en.cppreference.com/w/cpp/links
	
Download Source Code:
	http://www.talkplayfun.com/download/cpp_concepts/
	
C++20 Concepts #00: How to Install Visual Studio 2019 version 16.3.0 Preview 3
	https://www.youtube.com/watch?v=FLbUfkIDTbE&list=PL1_C6uWTeBDFuuwSvNm4VI-1eWyMxsB7b

Prerequisites:

	021 - The C++ 21 Concepts Tutorial 4, Variadic Templates / Fold Expressions / Concepts / Constraints
	https://www.youtube.com/watch?v=8gGeZbr0e7Q&list=PL1_C6uWTeBDH6i4Rr3E2ZYLUq6_Rdq3Dr&index=22

	020 - The C++ 20 Concepts Tutorial 3, Variadic Template Type-Constraint, Fold Expression
	https://www.youtube.com/watch?v=WQpEYrtu9yA&list=PL1_C6uWTeBDH6i4Rr3E2ZYLUq6_Rdq3Dr&index=21
	
	019 - The C++ 20 Concepts Tutorial 2, How to Use Modern C++ Language 100%
	https://www.youtube.com/watch?v=FTtaeYGWpac&list=PL1_C6uWTeBDH6i4Rr3E2ZYLUq6_Rdq3Dr&index=20

	018 - The C++ 20 Concepts Tutorial 1, What are Concepts in C++?
	https://www.youtube.com/watch?v=_m8lXscN2zs&list=PL1_C6uWTeBDH6i4Rr3E2ZYLUq6_Rdq3Dr&index=19

	000 - (SETUP) Install Microsoft Visual Studio, GNU g++, clang++, Intel TBB
	https://www.youtube.com/watch?v=a1-cMrgUZLs&list=PL1_C6uWTeBDH6i4Rr3E2ZYLUq6_Rdq3Dr&index=1

Download Source Code:
	
	http://sourcecode.talkplayfun.com/
	
	Episode 022
	http://sourcecode.talkplayfun.com/cpp20standard/022-KeywordRequires.zip
	
	Episode 021
	http://sourcecode.talkplayfun.com/cpp20standard/021-AllowedType.zip
		
	Episode 020
	http://sourcecode.talkplayfun.com/cpp20standard/020-VariadicConstraints.zip
		
	Episode 019
	http://sourcecode.talkplayfun.com/cpp20standard/019-PrototypeParameter.zip
	
	Episode 018
	http://sourcecode.talkplayfun.com/cpp20standard/018-Concepts.zip
	