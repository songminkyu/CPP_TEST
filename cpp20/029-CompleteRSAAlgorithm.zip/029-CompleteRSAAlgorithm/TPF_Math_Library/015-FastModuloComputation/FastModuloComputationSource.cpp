#include <iostream>

#include "tpf_gcd_lcm.h"

int main()
{

	std::cout << tpf::fast_modulo_euler(97, 121, 11, 13) << std::endl;
	std::cout << tpf::fast_modulo_chinese(97, 121, 11, 13) << std::endl;
	
	return 0;
}