#include <iostream>

#include "tpf_gcd_lcm.h"
#include "tpf_prime_numbers.h"
#include "tpf_stop_watch.h"
#include "tpf_random.h"
#include "tpf_smart_output.h"

typedef long long integer;

int main()
{
	//using namespace tpf;
	using namespace tpf::io;

	// STEP 0. We need to cache prime numbers
	tpf::CPrimes<integer> primes;

	// cache or build prime numbers
	primes.BuildPrimes(1'999'999);

	// display prime numbers
	// std::cout << primes.GetPrimes() << std::endl;
	// std::cout << primes.Report() << std::endl;

	// to display thousand delimiter
	std::cout.imbue(std::locale(""));

	// STEP 1. Get two random primes between 1'000 and 9'999
	// pq.first is the less of the two primes
	// pq.second is the greater of the two primes
	std::pair<integer, integer> pq = primes.GetTwoPrimes(1'000, 9'999);

	// display two random numbers we chose
	// std::cout << pq << std::endl;

	// this N is part of public key
	integer N = pq.first * pq.second;
	
	// Euler's Totient phi
	integer phi = (pq.first - 1) * (pq.second-1);
	
	// STEP 2. Get a random prime between 257 and 999,
	// that is coprime with phi (Euler's Totient)
	// the reason I choose 257 as lower bound is that
	// a character (8 bit) is less than 256.
	// this e is another part of public key
	integer e = primes.GetCoPrime(257, 999, phi);

	// STEP 3. Get a private key
	integer p = primes.GetPrivateKey(e, phi);

	integer private_key = p, public_key = e;

	if (private_key > public_key)
		std::swap(private_key, public_key);

	// publish (N, public_key)
	// keep secret (pq.first, pq.second, private_key)
	
	////////////////// We are all ready to do the business /////////////

	std::string flat_text;
	std::string decrypt_text;

	std::vector<integer> encrypted_message;

again:
	flat_text = "";
	decrypt_text = "";

	encrypted_message.clear();
	
	std::cout << "Input text to encrypt: "; 
	std::getline(std::cin, flat_text);

	if (flat_text.empty()) return 0;
		
	encrypted_message.reserve(flat_text.size());
	
	// STEP 4. Encryption
	for (auto m : flat_text)
	{
		integer c = tpf::hide::_fast_modulo_(integer(m), public_key, N);
		encrypted_message.push_back(c);
	}

	// Transmit encrypted message
	std::cout << std::endl;
	std::cout << "Encrypted: " << encrypted_message << std::endl;

	// STEP 5. Decryption
	for (auto c : encrypted_message)
	{
		//integer m = tpf::fast_modulo_chinese(integer(c), private_key, pq.first, pq.second);
		integer m = tpf::fast_modulo_euler(integer(c), private_key, pq.first, pq.second);

		decrypt_text.push_back((char)m);
	}

	std::cout << std::endl;
	std::cout << "Decrypted: " << decrypt_text << std::endl;
	
	goto again;

	return 0;

}