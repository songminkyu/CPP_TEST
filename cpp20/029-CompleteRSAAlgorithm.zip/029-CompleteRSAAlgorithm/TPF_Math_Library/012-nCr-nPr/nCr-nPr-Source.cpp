#include "tpf_ncr_npr.h"

#include <utility>

using namespace std;
using namespace tpf;

//
//void power_n(uintmax_t& m, uintmax_t n, uintmax_t k)
//{
//	uintmax_t s = m;
//
//	for (uintmax_t i = 1; i < k; ++i)
//	{
//		m *= s; if (m > n) m %= n;
//	}
//}
//
//// pollard's p-1 factorization
//std::pair<uintmax_t, uintmax_t> factor(uintmax_t n)
//{
//	uintmax_t n2 = 4, k = 2, d;
//
//	while ((d = tpf::gcd<uintmax_t>(n2 - 1, n)) == 1)
//	{
//		power_n(n2, n, ++k);
//	}
//
//	return make_pair(d, n / d);
//}

// miller-rabin test
// std::pair<uintmax_t, uintmax_t> 
#include <cstdint>

int main()
{
	intmax_t n, r;

	Permu<intmax_t> c;

again:

	std::cout << "n="; std::cin >> n;
	std::cout << "r="; std::cin >> r;

	if (n <0 || r<0) return 0;
	c(n, r); std::cout << c << std::endl;

	goto again;

	return 0;
}