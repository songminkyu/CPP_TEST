#include "tpf_detect_leak.h"

int main()
{
	{
		MemLeakCheck(here);

		int *ptr = new int;

	}



	return 0;
}