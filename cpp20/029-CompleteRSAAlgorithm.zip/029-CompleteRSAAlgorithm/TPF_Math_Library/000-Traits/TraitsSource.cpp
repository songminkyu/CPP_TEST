#include "tpf_smart_output.h"

#include <iostream>


int main()
{
	using namespace tpf;
	using namespace tpf::io;

	std::vector<int> v{1, 2, 3, 4, 5};
	
	std::cout << 1<<std::endl;

	std::cout << v << std::endl;


	
	return 0;
}