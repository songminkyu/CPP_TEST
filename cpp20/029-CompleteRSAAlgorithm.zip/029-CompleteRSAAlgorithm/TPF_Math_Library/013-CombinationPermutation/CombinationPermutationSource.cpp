#include <algorithm>
#include <iomanip>
#include <limits>

#include "tpf_smart_output.h"
#include "tpf_enum_combi.h"
#include "tpf_enum_permu.h"

using namespace std;
using namespace tpf;
using namespace tpf::io;

int main()
{
	// v is a set we want to build subsets
	std::vector<std::string> v = { "1-apple", "2-banana", "3-cherry", "4-dango", "5-echo" };

	// combi computes nCr or (n, r)
	// the number of combinations
	int cnt = tpf::combi(int(v.size()), 3);

	for (int mth = 0; mth < cnt; ++mth)
	{
		// enum_combination(v, r, mth)
		// returns mth subset of v with r elements
		RefVctr<std::string> rlt = tpf::enum_combination(v, 3, mth);

		std::cout << rlt << std::endl;
	}
		
	return 0;
}