#include "tpf_prime_numbers.h"
#include "tpf_detect_leak.h"

int main(int argc, char *argv[])
{
	using namespace tpf;
	using namespace tpf::io;

	/*if (argc < 2)
	{
		std::cout << "Usage: PrimeNumbers.exe primality number prime_filename" << std::endl;
		std::cout << "\tTest number if prime" << std::endl;

		std::cout << "Usage: PrimeNumbers.exe factorize number prime_filename" << std::endl;
		std::cout << "\tFactorize number" << std::endl;
		
		std::cout << "Usage: PrimeNumbers.exe divisors number prime_filename" << std::endl;
		std::cout << "\tGives divisors of number" << std::endl;

		std::cout << "Usage: PrimeNumbers.exe t|b prime_limit filename" << std::endl;
		std::cout << "\tsave prime number as text (t or txt) or as binary (b or bin)" << std::endl;
		std::cout << "\tprime_limit - upper limit of the generated prime number" << std::endl;
		std::cout << "\tfilename - save the generated prime number with this file name" << std::endl;
	}*/


	//if (argc != 4)
	//{
	//	std::cout << "Usage: PrimeNumbers.exe t|b prime_limit filename" << std::endl;
	//	std::cout << "\tsave prime number as text (t or txt) or as binary (b or bin)" << std::endl;
	//	std::cout << "\tprime_limit - upper limit of the generated prime number" << std::endl;
	//	std::cout << "\tfilename - save the generated prime number with this file name" << std::endl;
	//}
	//else
	//{
	//	std::string fmode(argv[1]);
	//	std::string filename(argv[3]);
	//	
	//	std::stringstream ss;
	//	ss << argv[2];

	//	intmax_t prime_limit; ss >> prime_limit;

	//	//std::cout << fmode << ", " << filename << ", " << prime_limit << std::endl;

	//	if (!(fmode == "b" || fmode == "bin" || fmode == "t" || fmode == "txt"))
	//	{
	//		std::cout << "t or b should be the first argument: t for text, b for binary" << std::endl;
	//		return 0;
	//	}
	//	if (prime_limit > 99'999'999)
	//	{
	//		std::cout << "prime_limit is too big, it can take long.\nAre you sure? [y for yes, or press any key] ";
	//		char c = std::cin.get();
	//		
	//		if(c != 'y') return 0;
	//	}
	//	
	//	std::cout << "Generating Primes..." << std::endl;

	//	std::cout.imbue(std::locale(""));

	//	tpf::CPrimes<intmax_t> PrimeCntr;

	//	{
	//		stop_watch sw("MultiThread Elpased Time: ");

	//		PrimeCntr.BuildPrimes(prime_limit);
	//	}

	//	if (fmode == "t" || fmode == "txt")
	//		PrimeCntr.Save(true, filename);
	//	else
	//		PrimeCntr.Save(false, filename);
	//	
	//	size_t prime_count = PrimeCntr.m_primes.size();

	//	std::cout << "Prime Count: " << prime_count << std::endl;

	//	//std::cout << PrimeCntr.m_primes << std::endl << std::endl;

	//	uintmax_t cache_max_prime = PrimeCntr.m_primes.back();

	//	uintmax_t test_max_prime = cache_max_prime * cache_max_prime;

	//	std::cout << "Cached prime number range:\t [2 ~ " << cache_max_prime << "]\n";

	//	std::cout << "Testable prime number range:\t [2 ~ " << test_max_prime << ")\n";
	//}
	//
	
	tpf::CPrimes<intmax_t> PrimeCntr;

	PrimeCntr.Load("primes_7");
	
	uintmax_t cache_max_prime = PrimeCntr.m_primes.back();

	uintmax_t test_max_prime = cache_max_prime * cache_max_prime;

	std::cout << "Cached prime number range:\t [2 ~ " << cache_max_prime << "]\n";

	std::cout << "Testable prime number range:\t [2 ~ " << test_max_prime << ")\n";

	TermVctr<intmax_t> tv;
	PrimeCntr.factorize(11 * 3 * 5*5, tv);
	
	std::cout<<"Divisors: "<<PrimeCntr.get_divisors(11 * 3 * 5)<<std::endl;

	std::cout << tv << std::endl;

	

	return 0;
}