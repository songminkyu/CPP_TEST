#include "tpf_gcd_lcm.h"
#include "tpf_enum_combi.h"
#include "tpf_traits.h"
#include "tpf_smart_output.h"


int main()
{
	using namespace tpf;
	using namespace tpf::io;

	std::cout << tpf::chinese_remainder<unsigned>({ 1, 5, 2, 6 }) << std::endl;
	std::cout << tpf::chinese_remainder<unsigned>(1, 5, 2, 6 ) << std::endl;

	std::cout << tpf::chinese_remainder(solve_linear_congruence(3, 7, 8), 8,
		solve_linear_congruence(3, 2, 5), 5) << std::endl;

	unsigned a = 2494;
	unsigned b = 2987;
	unsigned p = 37;
	unsigned q = 89;
			
	std::cout << tpf::fast_modulo_chinese(a, b, p, q) << std::endl;



	return 0;
}