#include "tpf_smart_output.h"
#include "tpf_set_operation.h"
#include "tpf_prime_factorization.h"

using namespace tpf;
using namespace tpf::io;

int main()
{
	CPrimes<int> Primes;

	Primes.BuildPrimes(1'000'000);

	while (true) // operation using set
	{
		Set<int> primes(Primes.GetPrimes().cbegin(), Primes.GetPrimes().cend());
		
		int a = 3 * 7 * 11 * 13;
		int b = 2 * 5 * 11 * 3 * 19;

		Set<int> afs = get_divisors(a, primes);
		Set<int> bfs = get_divisors(b, primes);

		Set<int> abu = set_intersection(afs, bfs);

		std::cout << "afx: " << afs << std::endl;
		std::cout << "bfs: " << bfs << std::endl;
		std::cout << "abu: " << abu << std::endl;

		TermSet<int> aset; factorize(a, aset, primes);
		Set<int> abset = get_bases(aset);
		std::cout << "abset: " << abset << std::endl;

		TermSet<int> bset; factorize(b, bset, primes);
		Set<int> bbset = get_bases(bset);
		std::cout << "bbset: " << bbset << std::endl;

		Set<int> un = set_union(abset, bbset);

		std::cout << "Union: " << un << std::endl;

		Set<int> it = set_intersection(abset, bbset);
		std::cout << "Inst: " << it << std::endl;

		Set<int> a_b_dif = set_difference(abset, bbset);
		std::cout << "a-b: " << a_b_dif << std::endl;

		Set<int> b_a_dif = set_difference(bbset, abset);
		std::cout << "b-a: " << b_a_dif << std::endl;

		break;
	}

	std::cout << "================================" << std::endl;

	
	while (true) // operation using vctr
	{
		Vctr<int>& primes = Primes.GetPrimes();

		int a = 3 * 7 * 11 * 13;
		int b = 2 * 5 * 11 * 3 * 19;

		Vctr<int> afs = get_divisors(a, primes);
		Vctr<int> bfs = get_divisors(b, primes);

		Vctr<int> abu = set_intersection(afs, bfs);

		std::cout << "afs: " << afs << std::endl;
		std::cout << "bfs: " << bfs << std::endl;

		std::cout << "abu: " << abu << std::endl;

		TermVctr<int> aset; factorize(a, aset, primes);
		Vctr<int> abset = get_bases(aset);
		std::cout << "abset: " << abset << std::endl;

		TermVctr<int> bset; factorize(b, bset, primes);
		Vctr<int> bbset = get_bases(bset);
		std::cout << "bbset: " << bbset << std::endl;

		Vctr<int> un = set_union(abset, bbset);

		std::cout << "Union: " << un << std::endl;

		Vctr<int> it = set_intersection(abset, bbset);
		std::cout << "Inst: " << it << std::endl;

		Vctr<int> ti = set_intersection(bbset, abset);
		std::cout << "Inst: " << ti << std::endl;

		Vctr<int> a_b_dif = set_difference(abset, bbset);
		std::cout << "a-b: " << a_b_dif << std::endl;

		Vctr<int> b_a_dif = set_difference(bbset, abset);
		std::cout << "b-a: " << b_a_dif << std::endl;


		break;
	}

	return 0;
}