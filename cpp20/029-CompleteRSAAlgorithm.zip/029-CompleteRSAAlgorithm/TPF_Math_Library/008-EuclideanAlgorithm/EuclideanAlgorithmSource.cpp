#include "tpf_gcd_lcm.h"
#include "tpf_stop_watch.h"
#include "tpf_random.h"
#include "tpf_prime_numbers.h"
#include "tpf_smart_output.h"

#include <iostream>

int main()
{
	using namespace tpf::io;

	std::cout << tpf::gcd(2 * 5, 2 * 3, 2 * 7) << std::endl;
	std::cout << tpf::lcm(2 * 5, 2 * 3, 2 * 7) <<" - " <<2*5*3*7<<std::endl;

		
	return 0;
}