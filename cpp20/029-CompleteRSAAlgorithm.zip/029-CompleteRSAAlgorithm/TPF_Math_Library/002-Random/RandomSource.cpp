#include "tpf_random.h"

int main()
{
	tpf::random_signed_t rst(1, 10);

	for (tpf::signed_t i = 0; i < 10; ++i)
	{
		std::cout << rst() << std::endl;
	}


	return 0;

	
}