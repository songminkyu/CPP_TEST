#include "tpf_prime_factorization.h"
#include "tpf_stop_watch.h"
#include "tpf_smart_output.h"

#include <iostream>

using namespace tpf;
using namespace tpf::io;

template<typename T> T totient(T n, const tpf::Vctr<T>& primes)
{
	tpf::TermVctr<T> terms;
	tpf::factorize(n, terms, primes);

	T rlt = 1;
	for (auto& e : terms)
	{
		rlt *= (e.base() - 1);
	}

	return rlt;
}

int main()
{
	CPrimes<index_t> primes;

	primes.BuildPrimes(1'000);

	index_t num = 2*2*3;

	std::cout << "num =" << num << std::endl;

	std::cout << "Last: " << primes.GetPrimes().back() << std::endl;

	TermVctr<index_t> v_terms;

	{
		stop_watch sw("\nvector operation");
		factorize<index_t>(num, v_terms, primes.GetPrimes());
	}

	//std::cout << "\nTerms: " << v_terms << std::endl;

	//Vctr<index_t> vds;
	//{
	//	stop_watch sw("\nvector operaton");
	//	get_divisors<index_t>(vds, v_terms);
	//}
	//std::cout << "\nDivisors: " << vds << std::endl;


	//Vctr<index_t> vdivisor;
	//{
	//	stop_watch sw("\nvector operatiorn");
	//	vdivisor = get_divisors<index_t>(num, primes.GetPrimes());
	//}
	//std::cout << "Divisors: " << vdivisor << std::endl;

	std::cout << "Totient: " << totient<index_t>(7 * 11, primes.GetPrimes()) << std::endl;
		
	return 0;
}