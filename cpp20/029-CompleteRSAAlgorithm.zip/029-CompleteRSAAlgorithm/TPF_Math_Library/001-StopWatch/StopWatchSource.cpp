
#include "tpf_stop_watch.h"

int main()
{
	{ 
		tpf::stop_watch sw("Elapsed: ");
				
		tpf::signed_t sum = 0;
		for (tpf::signed_t i = 1; i < 11; ++i)
			sum += i;
	}

	std::cout << std::endl;

}