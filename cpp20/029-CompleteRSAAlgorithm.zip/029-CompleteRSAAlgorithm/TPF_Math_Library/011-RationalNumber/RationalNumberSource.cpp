#include "tpf_rational_number.h"

int main()
{
	using namespace tpf;

	Rational<int> r1(10, 3*2), r2(5, 3*2), r3;
	UnsignedRational<unsigned> u1(3, 4);
	

	std::cout << r3 << std::endl;


}