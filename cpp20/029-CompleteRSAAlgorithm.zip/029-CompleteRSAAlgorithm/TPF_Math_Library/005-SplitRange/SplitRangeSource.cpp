#include "tpf_split_range.h"

int main()
{
	size_t cpu_count = tpf::get_cpu_thread_count();

	tpf::range_vctr_t rngvctr = SPLIT_RANGE_COUNT(cpu_count, 1, 101);

	std::cout << tpf::DisplayRanges(rngvctr) << std::endl;

	return 0;
}
