#include <iostream>

#include "tpf_gcd_lcm.h"
#include "tpf_prime_numbers.h"
#include "tpf_smart_output.h"

/*

How to Implement Extended Euclidean Algorithm in C++
	https://www.youtube.com/watch?v=ItZhKLM0gLs&list=PL1_C6uWTeBDHQOcP8wpGh4Ez7pBRjSqsL&index=4

RSA encryption (By Jeff Suzuki)
	https://www.youtube.com/watch?v=sQxXOxAJMrc&list=PLKXdxQAT3tCssgaWOy5vKXAR4WTPpRVYK&index=47

Complete RSA Algorithm in C++
	https://www.youtube.com/watch?v=FU15UL3gB1w&list=PL1_C6uWTeBDHQOcP8wpGh4Ez7pBRjSqsL

How to Implement Extended Euclidean Algorithm in C++
	https://www.youtube.com/watch?v=ItZhKLM0gLs&list=PL1_C6uWTeBDHQOcP8wpGh4Ez7pBRjSqsL&index=4

Fast Powering Algorithm(By Jeff Suzuki)
	https://www.youtube.com/watch?v=rBVU8wq_NLM&list=PLKXdxQAT3tCssgaWOy5vKXAR4WTPpRVYK&index=46

028 - The RSA Algorithm 1 - Bitwise Operations, Fast Modular Exponentiation (Shift-Right Operation)
	https://www.youtube.com/watch?v=tySo6zXfZv8&list=PL1_C6uWTeBDH6i4Rr3E2ZYLUq6_Rdq3Dr&index=29


	If subscribe my YouTube channel, you can use all source code
	included in this package free of any charge or royality,
	as long as you give proper attributions.

	You can freely use, but I preserve the copy right of all the codes
	in this package.

	Also, I do not gaurantee any merchantibility or commercialibity...
	implied or expressed..., but not limited...
	I do not gaurantee any thing and I do not take any liability.

	This library is NOT commercial grade.
	This algorithm can be easily brokabble.

	Do NOT use this library for commericial use or application.

*/
typedef long long integer;

int main()
{
	// using namespace tpf;
	using namespace tpf::io;

	// STEP 0. We need to cache prime numbers
	tpf::CPrimes<integer> primes;

	// cache or build prime numbers
	// less than 1'999'999
	primes.BuildPrimes(1'999'999);

	// to display thousand delimiter
	std::cout.imbue(std::locale(""));

	// std::cout << primes.GetPrimes() << std::endl;
	// std::cout << primes.Report() << std::endl;

	// STEP 1. Get two random prime numbers between 1'000 and 9'999
	// pq.first is the less of the two primes
	// pq.second is the greater of the two primes
	std::pair<integer, integer> pq = primes.GetTwoPrimes(1'000, 9'999);

	// display two random primes
	// std::cout << pq << std::endl;

	// this N is part of the public key
	integer N = pq.first * pq.second;
	
	// Euler's Totient of two primes
	integer phi = (pq.first - 1) * (pq.second - 1);

	// STEP 2. Get a random number between 2 and phi-1
	// that is co-prime with phi.
	integer e = primes.GetCoPrimeStronger(2, phi-1, phi);

	// STEP 3. Get a private key
	integer p = primes.GetPrivateKey(e, phi);

	integer public_key = e, private_key = p;

	if (private_key > public_key) 
		std::swap(private_key, public_key);

	// we publish (N, publick_key) to the general public
	// and we keep (N, pq.first, pq.second, private_key)
	// N = pq.first * pq.second

	// will hold text to be encrypted
	std::string flat_text;

	// will hold text decrypted
	std::string decrypt_text;

	// will hold encrypted text or data
	// to be transmitted through public channel
	std::vector<integer> encrypted_data;

again:
	
	std::cout << "Input text to encrypt: "; 
	std::getline(std::cin, flat_text);

	decrypt_text = "";
	encrypted_data.clear();

	if (flat_text.empty()) return 0;

	encrypted_data.reserve(flat_text.size());

	// STEP 4. Encryption
	for (auto m : flat_text)
	{
		integer c = tpf::hide::_fast_modulo_(integer(m), public_key, N);
		
		encrypted_data.emplace_back(c);
	}

	// Transmit encrypted data to the me
	std::cout << std::endl;
	std::cout << encrypted_data << std::endl;

	// STEP 5. Decryption
	for (auto c : encrypted_data)
	{
		// integer m = tpf::fast_modulo_chinese(c, private_key, pq.first, pq.second);
		// integer m = tpf::fast_modulo_fermat(c, private_key, N);

		integer m = tpf::fast_modulo_euler(c, private_key, pq.first, pq.second);

		decrypt_text.push_back((char)m);
	}

	std::cout << std::endl;
	std::cout << "Decrypted: " << decrypt_text << std::endl;
	
	goto again;
	
	return 0;
}