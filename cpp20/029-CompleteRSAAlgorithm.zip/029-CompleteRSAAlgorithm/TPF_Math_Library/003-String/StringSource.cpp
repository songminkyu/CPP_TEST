#include "tpf_string.h"

#include <iostream>

int main()
{
	std::string msg = "  [I love it]  ";

	std::cout << tpf::rtrim(tpf::ltrim(msg)) << std::endl;

	return 0;

}