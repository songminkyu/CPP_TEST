#include "tpf_types.h"

#include "tpf_smart_output.h"

int main()
{
	using namespace tpf::io;

	std::vector<int> vctr{ 1, 2, 3, 4 };
	std::set<int> iset{ 1, 2, 3, 4, 5, 6 };

	std::cout << vctr << std::endl;

	int big = 12'345;
	std::cout << big << std::endl;

	std::ostringstream ost;
	ost << vctr;

	std::cout << ost.str() << std::endl;

	return 0;
}
