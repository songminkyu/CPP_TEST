#include "tpf/types.hpp"

#include <iostream>

// types is called namespace alias
namespace types = tpf::types;

auto& cout = std::cout;
auto endl = "\n";

template<typename ArgType>
ArgType summation_one(ArgType a, ArgType b)
{
    ArgType sum{};

    for(auto i = a; i < b; ++i)
        sum += i;

    return sum;
}

void test_summation_one()
{
    int a = 1;
    int b = 11;

    cout <<"sum from " << a<<" to " << (b-1) 
        <<" is " << summation_one(a, b) << endl;

}

// The contraint of this function is that
// the first parameter a is less than the second parameter b,
// or a < b
template<typename ArgType1, typename ArgType2>
auto summation_one(ArgType1 a, ArgType2 b)
{
    ArgType1 sum{};

    for(auto i = a; i < b; ++i)
        sum += i;

    return sum;
}

void test_summation_one_again()
{
    unsigned short a = 1;
    short b = 11;

    cout <<"sum from " << a<<" to " << (b-1) 
        <<" is " << summation_one(a, b) << endl;

}

template<typename ArgType1, typename ArgType2>
auto summation_two(ArgType1 aa, ArgType2 bb)
{
    using common_t = std::common_type_t<ArgType1, ArgType2>;

    cout <<"Type of common_t: " << Tpf_GetTypeName(common_t) << endl;
   
    auto a = aa < bb ? aa : bb;
    auto b = aa < bb ? bb : aa;

    cout <<"Type of a: " << Tpf_GetTypeCategory(a) << endl;
    cout <<"Type of b: " << Tpf_GetTypeCategory(b) << endl;

    common_t sum{};

    for(auto i = a; i < b; ++i)
        sum += i;

    return sum;
}

void test_summation_two()
{
    int a = 11;
    unsigned b = 1;

    auto sum = summation_two(a, b);

    cout <<"sum: " << sum << endl;
}

void test_summation_two_again()
{
    int a = -10;
    unsigned b = 0; // -10 ... -1

    auto sum = summation_two(a, b);

    cout <<"sum: " << sum << endl;
}

//////////////////////////////////////////
template<typename ArgType1, typename ArgType2>
auto summation_two_partially_fixed(ArgType1 aa, ArgType2 bb)
{
    using common_t = std::common_type_t<ArgType1, ArgType2>;

    // std::make_signed_t works only for integral types such as int, short, unsigned, etc.
    // we can overcome the problem related with std::make_signed_t<> using
    // either type tag dispatch or if constexpr
    using type_t = std::make_signed_t<common_t>;

    /* this does not work
    auto a =(type_t) (aa < bb ? aa : bb);
    auto b =(type_t) (aa < bb ? bb : aa);
    */

    auto a = (type_t)aa < (type_t)bb ? (type_t)aa : (type_t)bb;
    auto b = (type_t)aa < (type_t)bb ? (type_t)bb : (type_t)aa;

    type_t sum{};

    for(auto i = a; i < b; ++i)
        sum += i;

    return sum;
}

void test_summation_two_partially_fixed()
{
    int a = -10;
    unsigned b = 0; // -10 ... -1

    auto sum = summation_two_partially_fixed(a, b);

    cout <<"sum: " << sum << endl;
}

// void test_summation_two_partially_fixed_failed()
// {
//     int a = -10;
//     float b = 0; // -10 ... -1

//     auto sum = summation_two_partially_fixed(a, b);

//     cout <<"sum: " << sum << endl;
// }

int main()
{
    // test_summation_one();

    // test_summation_one_again();

    // test_summation_two();

    // test_summation_two_again();

    test_summation_two_partially_fixed();

    // test_summation_two_partially_fixed_failed();
}