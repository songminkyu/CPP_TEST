﻿#include <tpf_output.hpp>

tpf::sstream stream;

auto endl = tpf::endl; // single carriage return
auto endL = tpf::endL; // two carriage returns

void test_variant_container()
{
    using age_t = int;
    using weight_t = double;
    using name_t = const char*;

    // please remember the order of element types
    // age_t, weight_t, name_t - the order does matter in this example
    using item_t = std::variant<age_t, weight_t, name_t>;

    using container_t = std::vector<item_t>;

    container_t bag{ 10, 400.5, "Thomas Kim", 
                     40, 300.5, "Sophie Turner", 
                     30, 200.5, "Jame Lee", 
                     20, 100.5, "Alice Song", 50, 506.6, "Translator Kim", "Programmer Park" };

    stream <<"My bag contains: " << endl;
    stream << bag << endL;
}

template<std::size_t Is>
struct st_index_vector
{
    using type = std::vector<size_t>;
};

// primary class template - it determines the count of template parameters
// st_tuple_of_vectors takes one template parameter
template<typename Type> struct st_tuple_of_vectors;

template<std::size_t... Is>
struct st_tuple_of_vectors< std::index_sequence<Is...> >
{
    using type = std::tuple<typename st_index_vector<Is>::type...>;
};

// primary template determines the count of the template parameters
// st_make_index_vectors takes one template parameter
template<typename Type> struct st_make_index_vectors;

template< template<typename... > class ClassType, typename... Types>
struct st_make_index_vectors< ClassType<Types...> >
{
    using type = typename st_tuple_of_vectors< std::make_index_sequence<sizeof...(Types)> >::type;
};

template<typename Type>
using make_index_vectors_t = typename st_make_index_vectors< tpf::remove_cv_ref_t<Type> >::type;

void test_create_container_type_on_the_fly()
{
    using age_t = int;
    using weight_t = double;
    using name_t = const char*;

    // please remember the order of element types
    // age_t, weight_t, name_t - the order does matter in this example
    using item_t = std::variant<age_t, weight_t, name_t>;

    using index_vectors_t = make_index_vectors_t<item_t>;

    using container_t = std::vector<item_t>;

    container_t bag{ 10, 400.5, "Thomas Kim", 
                     40, 300.5, "Sophie Turner", 
                     30, 200.5, "Jame Lee", 
                     20, 100.5, "Alice Song", 50, 506.6, "Translator Kim", "Programmer Park" };

    stream <<"My bag contains: " << endl;
    stream << bag << endL;

    stream <<"Type of index_vector_t: " << Tpf_GetTypeName(index_vectors_t) << endl;
}

///////////////////////////////////////////
void test_how_to_use_index_vector_t()
{
    using age_t = int;
    using weight_t = double;
    using name_t = const char*;

    // please remember the order of element types
    // age_t, weight_t, name_t - the order does matter in this example
    using item_t = std::variant<age_t, weight_t, name_t>;

    using index_vectors_t = make_index_vectors_t<item_t>;

    using container_t = std::vector<item_t>;

    container_t bag{ 10, 400.5, "Thomas Kim", 
                     40, 300.5, "Sophie Turner", 
                     30, 200.5, "Jame Lee", 
                     20, 100.5, "Alice Song", 50, 506.6, "Translator Kim", "Programmer Park" };

    stream <<"My bag contains: " << endl;
    stream << bag << endL;

    // stream <<"Type of index_vector_t: " << Tpf_GetTypeName(index_vectors_t) << endl;

    // step 0. create an instance of index_vector_t

    index_vectors_t indices;

    // step 1. extract index vectors
    auto& [age_indices, weight_indices, name_indices] = indices;

    // step 2. create indices extractors

    auto extract_age_indices = [&indices = age_indices](auto&& index, auto&& value)
    {
        indices.emplace_back(index);
    };

    auto extract_weight_indices = [&indices = weight_indices](auto&& index, auto&& value)
    {
        indices.emplace_back(index);
    };

    auto extract_name_indices = [&indices = name_indices](auto&& index, auto&& value)
    {
        indices.emplace_back(index);
    };

    tpf::types::variant_visitors extract_indices{extract_age_indices, extract_weight_indices, extract_name_indices};

    extract_indices.for_each_index(bag);

    stream <<"Age indices: " << age_indices << endl;
    stream <<"Weight indices: " << weight_indices << endl;
    stream <<"Name indices: " << name_indices << endl;
}

///////////////////////////////////////////
void test_how_to_use_indices()
{
    using age_t = int;
    using weight_t = double;
    using name_t = const char*;

    // please remember the order of element types
    // age_t, weight_t, name_t - the order does matter in this example
    using item_t = std::variant<age_t, weight_t, name_t>;

    using index_vectors_t = make_index_vectors_t<item_t>;

    using container_t = std::vector<item_t>;

    container_t bag{ 10, 400.5, "Thomas Kim", 
                     40, 300.5, "Sophie Turner", 
                     30, 200.5, "Jame Lee", 
                     20, 100.5, "Alice Song", 50, 506.6, "Translator Kim", "Programmer Park" };

    stream <<"My bag contains: " << endl;
    stream << bag << endL;

    // stream <<"Type of index_vector_t: " << Tpf_GetTypeName(index_vectors_t) << endl;

    // step 0. create an instance of index_vector_t

    index_vectors_t indices;

    // step 1. extract index vectors
    auto& [age_indices, weight_indices, name_indices] = indices;

    // step 2. create indices extractors

    auto extract_age_indices = [&indices = age_indices](auto&& index, auto&& value)
    {
        indices.emplace_back(index);
    };

    auto extract_weight_indices = [&indices = weight_indices](auto&& index, auto&& value)
    {
        indices.emplace_back(index);
    };

    auto extract_name_indices = [&indices = name_indices](auto&& index, auto&& value)
    {
        indices.emplace_back(index);
    };

    tpf::types::variant_visitors extract_indices{extract_age_indices, extract_weight_indices, extract_name_indices};

    extract_indices.for_each_index(bag);

    stream <<"Age indices: " << age_indices << endl;
    stream <<"Weight indices: " << weight_indices << endl;
    stream <<"Name indices: " << name_indices << endl;

    stream <<"All ages: " << endL;
    for(auto&& index: age_indices)
    {
        stream << bag[index] << endl;
    }

    stream <<"\nAll weights: " << endL;
    for(auto&& index: weight_indices)
    {
        stream << bag[index] << endl;
    }

    stream <<"\nAll names: " << endL;
    for(auto&& index: name_indices)
    {
        stream << bag[index] << endl;
    }

    auto sort_age = [&bag](auto index1, auto index2)
        { return bag[index1] < bag[index2]; };

    // sort ages in ascending order
    std::sort(std::execution::par_unseq, age_indices.begin(), age_indices.end(), sort_age);

    auto sort_weight = [&bag](auto index1, auto index2)
        { return bag[index1] < bag[index2]; };

    // sort weight in ascending order
    std::sort(std::execution::par_unseq, weight_indices.begin(), weight_indices.end(), sort_weight);

    // name_t is const char*
    // for those who are performance freaks,
    auto sort_name = [&bag](auto index1, auto index2)
        { 
            // auto name1 = std::string( std::get<name_t>(bag[index1]) );
            // auto name2 = std::string( std::get<name_t>(bag[index2]) );

            auto name1 = std::get<name_t>(bag[index1]);
            auto name2 = std::get<name_t>(bag[index2]);

            return std::strcmp(name1, name2) < 1; 
        };

    // sort names in ascending order
    std::sort(std::execution::par_unseq, name_indices.begin(), name_indices.end(), sort_name);

    /////////////////////////////////

    stream <<"\n\nAfter sorting ..." << endL;

    stream <<"Age indices: " << age_indices << endl;
    stream <<"Weight indices: " << weight_indices << endl;
    stream <<"Name indices: " << name_indices << endL;

    stream <<"Bag: " << bag <<endL;

    stream <<"All ages: " << endL;
    for(auto&& index: age_indices)
    {
        stream << bag[index] << endl;
    }

    stream <<"\nAll weights: " << endL;
    for(auto&& index: weight_indices)
    {
        stream << bag[index] << endl;
    }

    stream <<"\nAll names: " << endL;
    for(auto&& index: name_indices)
    {
        stream << bag[index] << endl;
    }

}

int main()
{
    // test_variant_container();

    // test_create_container_type_on_the_fly();

    // test_how_to_use_index_vector_t();

    test_how_to_use_indices();
}

