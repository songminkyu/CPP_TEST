﻿#include <tpf_output.hpp>

// cl /EHsc /std:c++latest protoparam.cpp /Fe: m.exe
// clang++ -std=c++2a protoparam.cpp -ltbb -o c.exe

// as of today, 2020, April, 17,
// clang++ does not implement header file <concepts>

#if !defined(__clang_major__)
    
    #include <concepts> // C++20 Standard concepts header file

#else

namespace std
{
    namespace detail
    {
        // T and S are type template parameters
        // the first type template parameter is T.
        // the first type template parameter is called "Prototype Parameter."
        // So, T is the prototype parameter of SameHelper concept.
        //
        // The concept whose first template parameter is type parameter
        // is called type concept.
        template<typename T, typename S>
        concept SameHelper = std::is_same_v<T, S>;
    }

    template<typename T, typename S>
    concept same_as = detail::SameHelper<T, S> && detail::SameHelper<S, T>;
}
#endif


namespace std
{
    namespace detail
    {
        // this is primary template.
        // the primary template determins the count of template parameters (or arguments)
        // this template can take 1 or more template arguments
        template<typename T, typename... Types>
        struct st_same
        {
            static constexpr bool value = false;
        };

        // Types: variadic type concept - same_as<T>
        template<typename T, same_as<T>... Types>
        struct st_same<T, Types...> // because we provided template arguments <T, Types...>
        {                           // this is specialization
            static constexpr bool value = true;
        };

        template<typename T>
        struct st_same<T> // this is specialization because we provided template argument <T>
        {
            static constexpr bool value = true;
        };
    }

    // this is variable template
    template<typename T, typename... Types>
    constexpr bool all_same_v = detail::st_same<T, Types...>::value;

    template<typename T, typename... Types>
    concept all_same_as = all_same_v<T, Types...>;
}

tpf::sstream stream;
auto endl = tpf::endl;

namespace types = tpf::types;

void test_concept_basic()
{
    // std::same_as
    // https://en.cppreference.com/w/cpp/concepts/same_as
    stream << "same_as<int, int>: " << std::same_as<int, int> << endl;

    stream <<"all_same_as<int>: " << std::all_same_as<int> << endl;
    stream <<"all_same_as<int, int, int>: " << std::all_same_as<int, int, int> << endl;
    stream <<"all_same_as<int, int, double>: " << std::all_same_as<int, int, double> << endl;
}

template<typename T, std::same_as<T>... Types>
auto summation(T a, Types... args)
{
    return ( a + ... + args );
}

void test_all_same_as()
{
    // auto s1 = summation(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

    auto s1 = summation(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
    stream << "1 + ... + 10 = " << s1 << endl;

    auto s2 = summation(1);
    stream << "1 = " << s2 << endl;
}

int main()
{
    // test_concept_basic();

    test_all_same_as();
}