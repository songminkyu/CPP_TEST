#include "tpf/types.hpp"

#include <iostream>

auto& cout = std::cout;
auto endl = "\n";

namespace types = tpf::types;

size_t GetBananaCount()
{
    return 10;
}

// with the keyword constexpr,
// GetBananaCountFixed() is not constant-expression
// or compile-time expression
constexpr size_t GetBananaCountFixed()
{
    return 10;
}

constexpr size_t GetPeachCount()
{
    return 0;
}

constexpr size_t GetPeachCountFixed()
{
    return 6;
}

// C++ compiler "interprets" this function
// at compile-time, when a literal value is passed
// to this function through the parameter stock_count.
// however, if non-literal value is passed
// to this function through the parameter stock_count,
// C++ compiler cannot acces to the value of stock_count
// at compile-time, that is, this function becomes a run-time construct.
constexpr size_t GetCherryCount(size_t stock_count)
{
    return stock_count + 10;
}

void _1_how_to_declare_static_array()
{
    /*
        Please pay special attention to "constant-expression or compile-time expression."
    */

   // we declared an instance of int[5], a
   // the type of a is int[5]
   int a[5]; 

    // we declared an instance of type double[3],
    // d is an instance of type d[3],
    // and initialized the elements of the array d with 1, 2, 3
   double d[]{1, 2, 3};

   size_t int_count{5};

    // it does not work.
    // int_count is a run-time construct, not compile-time construct
    // or int_count is not a constant-expression
   // int n[int_count];

    // don't get confused with square bracket [] with curly brace {}
    // we initialized an instance of size_t, apple_count with the value 6
    // constexpr means apple_count is a constant-expression
   constexpr size_t apple_count{6};

    // since apple_count is a constant-expression,
    // the following is perfectly legal in C++
   int n[apple_count];

    // this is more conventional C/C++ syntax
    // peach_count is also a constant-expression
   const size_t peach_count = 7;

   int peaches[peach_count];

    // banana_count is not constant-expression
    // or compile-time expression
   const size_t banana_count = GetBananaCount();

    // int bananas[banana_count];

    int bananas[ GetBananaCountFixed() ];

    // double dd[GetPeachCount()];

    // In C/C++, the element count of a static array
    // cannot be zero

    // it does not work
    // double dd[0];

    double peach[ GetPeachCountFixed() ];


    // it perfectly works
    short cherry [ GetCherryCount(5) ];

    // size_t cherry_count = 10;

    // // it does not work, why?
    // short cherries [ GetCherryCount(cherry_count)];

    /*
        In case of static array, the memory of the array
        should be RESERVED at compile-time.

        short cherry [ GetCherryCount(5) ];,

        short cherries [ GetCherryCount(cherry_count)];

    */

   constexpr size_t cherry_count = 10;

    // Now it works because cherry_count is now a constant-expression (or compile-time expression)
    // and GetCherryCount() is marked with constexpr, so
    // the C++ compiler call GetCherryCount(cherry_count) at compile-time, not at run-time
    // that is, C++ compiler can reserve memory for the array cherries
    short cherries [ GetCherryCount(cherry_count)];

    // Now the difference between const and constexpr

    size_t count = 10;

    // this is perfectly legal
    // my_peach_count is not a compile-time or constant-expression
    // my_peach_count is constant, but is initialized at run-time
    const size_t my_peach_count = GetCherryCount(count);

    // this is illegal in C++
    // When keyword constexpr is used to define a name as below,
    // constexpr means the name is a compile-time or constant expression.
    // In the line below, since count is not a compile-time expression,
    // The C++ compiler cannot evaluate GetCherryCount(count) at compile-time,
    // so it fails.
    // constexpr size_t my_pear_count = GetCherryCount(count);

    // For your information, fields of an enum (or enumeration) are constant-expression
    // or compile-time expression. "Fields of an enum" are called "enumerators."

    enum { AppleCount = 5, PeachCount = 6};

    // AppleCount and PeachCount are enumerators or fields of an enum.
    // These are constant-expression or compile-time expression.
    // So, the following lines of codes are PERFECTLY LEGAL

    int my_apples[AppleCount];
    size_t my_peaches[PeachCount];
}

int main()
{
    _1_how_to_declare_static_array();
}