#include "tpf/types.hpp"

#include <iostream>

auto& cout = std::cout;
auto endl = std::endl<char, std::char_traits<char>>;

namespace tpf::types
{
    // primary template determines the count of template arguments
    template<typename T1, typename T2> // primary template
    struct st_is_same // does not have template argument
    {
        static constexpr bool value = false;
    };

    template<typename T>   // specialization
    struct st_is_same<T, T> // <T, T> template argument
    {
        static constexpr bool value = true;
    };

    template<typename T1, typename T2>
    constexpr bool is_same_v = st_is_same<T1, T2>::value;

    template<typename T1, typename T2, typename T3>
    constexpr bool is_same3_v = is_same_v<T1, T2> && is_same_v<T1, T3>;

} // end of namespace 

namespace types = tpf::types;

void test_is_same_v()
{
    cout<< std::boolalpha;

    cout << "is int same as int ? " << types::is_same_v<int, int> << endl;
    cout << "is int same as short ? " <<types::is_same_v<int, short> << endl;

    cout << "are int, int, int all the same ? " << types::is_same3_v<int, int, int> << endl;
    cout << "are int, short, int all the same ? " << types::is_same3_v<int, short, int> << endl;
    


}

int main()
{
    test_is_same_v();
}