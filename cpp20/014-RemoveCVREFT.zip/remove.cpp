#include "tpf/types.hpp"

#include <iostream>

// in C++, stream object is not copyable,
// std::cout is a global instance of a std::basic_ostream<char ...> object
auto& cout = std::cout;
auto endl = std::endl<char, std::char_traits<char>>;

namespace tpf::types
{
    // Please commit this into your memory.
    // C++ favors the specialization over the primary template

    // any expression enclosed with angle bracket <> is constant-expression or compile-time expression

    // primary template determins the count of template arguments
    // N: non-type template parameter
    template<int N>
    struct st_is_even // this is primary template
    {
        static constexpr bool value = st_is_even< N%2 >::value;
    };

    template<>
    struct st_is_even<0> // this is a specialization
    {
        static constexpr bool value = true;
    };

    template<>
    struct st_is_even<1>
    {
        static constexpr bool value = false;
    };

    template<int N>
    constexpr bool is_even_v = st_is_even<N>::value;

    template<int N>
    constexpr bool is_odd_v = N%2 == 0 ? false : true;

} // end of namespace tpf::types

namespace types = tpf::types;

void test_even_odd()
{
    cout << std::boolalpha;

    cout <<"Is 5 even ? " << types::is_even_v<5> << endl;
    cout <<"Is 6 even ? " << types::is_even_v<6> << endl;

    cout <<"Is 5 odd ? " << types::is_odd_v<5> << endl;
    cout <<"Is 6 odd ? " << types::is_odd_v<6> << endl;

    int n = 7;

    // telling the difference between compile-time expression and runtime expression
    // is crucial for successful C++ programming
    // cout << "Is n=7 odd ? " << types::is_odd_v<n> << endl;

    // we use constexpr to instruct C++ compiler that 
    // the following is compile-time construct or constant-expression
    constexpr int m = 7;

    cout << "Is m=7 odd ? " << types::is_odd_v<m> << endl;

}

namespace tpf::types
{
    template<typename T>
    struct st_remove_const_volatile // this is primary template
    {
        using type = T;
    };

    template<typename T>
    struct st_remove_const_volatile<const T> // this is partial specialization
    {                               // I will discuss more about "partial specialization" in some future episode
        using type = T;
    };

    template<typename T>
    struct st_remove_const_volatile<volatile T>
    {
        using type = T;
    };

    template<typename T>
    struct st_remove_const_volatile<const volatile T>
    {
        using type = T;
    };

    template<typename T>
    using remove_const_volatile_t = typename st_remove_const_volatile<T>::type;

    template<typename T>
    struct st_remove_reference
    {
        using type = T;
    };

    template<typename T>
    struct st_remove_reference<T&>
    {
        using type = T;
    };

    template<typename T>
    struct st_remove_reference<T&&>
    {
        using type = T;
    };

    template<typename T>
    using remove_reference_t = typename st_remove_reference<T>::type;

    // we removed const, then reference
    // it does not work
    template<typename T>
    using remove_const_volatile_reference_t = 
        remove_reference_t< remove_const_volatile_t<T> >; 

    // we removed reference, then we removed const or volatile
    // it works correctly
    template<typename T>
    using remove_cvref_t = 
        remove_const_volatile_t< remove_reference_t<T> >;

} // end of namespace tpf::types

void test_remove_const_reference()
{
    using c_int = const int;
    using c_removed = types::remove_const_volatile_t<c_int>;

    cout << "From [" << Tpf_GetTypeName(c_int) <<"], we remove const, then we have ["
        << Tpf_GetTypeName(c_removed) <<"] " << endl;

    using r_int = int&;
    using r_removed = types::remove_reference_t<r_int>;

    cout << "From [" << Tpf_GetTypeName(r_int) << "], we remove reference &, then we have ["
        << Tpf_GetTypeName(r_removed) << "] " << endl;

    using rr_int = int&&;
    using rr_removed = types::remove_reference_t<rr_int>;

    cout << "From [" << Tpf_GetTypeName(rr_int) << "], we remove reference &&, then we have ["
        << Tpf_GetTypeName(rr_removed) << "] " << endl;


    using const_ref_int = const int&;

    // failure
    using try_remove_cont_ref = types::remove_const_volatile_reference_t<const_ref_int>;

    // success
    using cvref_t = types::remove_cvref_t<const_ref_int>;

    cout <<"Fail -   From [" << Tpf_GetTypeName(const_ref_int) <<"], we remove const &, then we have ["
        << Tpf_GetTypeName(try_remove_cont_ref) <<"] " << endl;

    cout <<"Success - From [" << Tpf_GetTypeName(const_ref_int) <<"], we remove const &, then we have ["
        << Tpf_GetTypeName(cvref_t) <<"] " << endl;

    // it succeeds.
    using remove_reference_first = std::remove_const_t<std::remove_reference_t<const_ref_int>>;

    // it fails
    using remove_constant_first = std::remove_reference_t<std::remove_const_t<const_ref_int>>;

    cout <<"Remove reference first: " << Tpf_GetTypeName(remove_reference_first) << endl;
    cout <<"Remove constant first: " << Tpf_GetTypeName(remove_constant_first) << endl;

}

int main()
{
    // test_even_odd();
    
    test_remove_const_reference();
}
