#ifndef TPF_TYPES_HPP
#define TPF_TYPES_HPP

#ifndef CPP_STD_20_VER
/* Update CPP_STD_20_VER to 202002L in future */
#define CPP_STD_20_VER 201705L 
#endif

// we are using Microsoft C++ compiler
#ifdef _MSVC_LANG

#ifndef NOMINMAX
#define NOMINMAX
#endif

#if _MSVC_LANG < CPP_STD_20_VER
    #error Requires C++20 Standard compatible compiler
#else
    
    #ifndef TBB_SUPPRESS_DEPRECATED_MESSAGES
    #define TBB_SUPPRESS_DEPRECATED_MESSAGES 1
    #endif

    #include <tbb/tbbmalloc_proxy.h>
#endif 

// we are using GNU g++ or clang++ compiler
#else
    #ifndef __cplusplus
        #error Requires C++20 Standard compatible compiler
    #else
        #if __cplusplus < CPP_STD_20_VER
            #error Requires C++20 Standard compatible compiler
        #else
            // put GNU g++ or clang++ specific header files in this block

        #endif 

    #endif // end of __cplusplus

#endif // end of _MSVC_LANG

// put C++20 Standard header files here
#include <type_traits>
#include <string>
#include <cstring>

namespace tpf
{
    namespace types
    {
        template<typename Type>
        std::string type_to_string()
        {
            #ifdef __FUNCSIG__
            std::string fname(__FUNCSIG__);

            const char* to_str = "to_string<";
            size_t len = strlen(to_str);
            auto pos = fname.find(to_str);
            fname = fname.substr(pos+len);
            return fname.substr(0, fname.find_last_of('>'));

            #else

                // In case of GNU g++, clang++, Intel icl c++ compiler
                // macro __PRETTY_FUNCTION__
                std::string fname(__PRETTY_FUNCTION__);
                
                #ifdef __clang_major__
                    const char* ftext = "[Type = ";
                    auto pos = fname.find(ftext) + strlen(ftext);
                    fname = fname.substr(pos);
                    fname.pop_back();
                    return fname;

                #elif defined(__ICL)
                    const char* ftext = "type_to_string<";
                    auto pos = fname.find(ftext) + strlen(ftext);
                    fname = fname.substr(pos);
                    pos = fname.find_last_of('>');
                    return fname.substr(0, pos);
                #else
                    const char* ftext = "[with Type = ";
                    auto pos = fname.find(ftext) + strlen(ftext);
                    fname = fname.substr(pos);
                    pos = fname.find_first_of(';');
                    return fname.substr(0, pos);
                 #endif

            #endif
        }

    } // end of namespace types

} // end of namespace tpf

#define Tpf_GetTypeName(type_arg) tpf::types::type_to_string<type_arg>()
#define Tpf_GetTypeCategory(instance_arg) Tpf_GetTypeName(decltype(instance_arg))

namespace tpf
{
    namespace types
    {
        template<typename ElementType, size_t ElementCount>
        constexpr auto array_size(ElementType(&)[ElementCount] ) noexcept // noexcept improves performance
        {
            return ElementCount;
        }

    } // end of namespace types

} // end of namespace tpf

#endif // end of file