#include "tpf/types.hpp"

/*

    clang++ -std=c++2a function.cpp -ltbb -ltbbmalloc_proxy -o c.exe
    g++ -std=c++2a function.cpp -ltbb -ltbbmalloc_proxy -o g.exe

    cl /EHsc /std:c++latest function.cpp /Fe: m.exe
*/
#include <iostream>

auto& cout = std::cout;
auto endl = std::endl<char, std::char_traits<char>>;

// sum is an instance of type int(int, int)
// what is the reference type of int(int, int)?
// int(&)(int, int) - if we do not use (&), then int&(int, int) == int& (int, int), that is, a function that return int&
// what is the pointer type of int(int, int)?
// int(*)(int, int), if we do not use (*), int*(int, int) == int* (int, int), that is, a function that returns int*
int sum(int a, int b)
{
    return a + b;
}

// what's this function's type
// sum is an instance of double&(double, double)
// what is the reference type of double&(double, double)?
// double&(&)(double, double)
// double& sum(double a, double b)
// {
//     double* ptr = new double;

//     return *ptr;
// }

// pro is an instance of double*(int, double)
// what is the pointer type of double*(int, double) ?
// double* (*)(int, double)
// double* pro(int a, double b)
// {
//     double* ptr = new double;

//     return ptr;
// }

int pro(int a, int b)
{
    return a * b;
}

void test_function_instance_and_type()
{
    int a = 5;

    // what is the type of a ?

    cout << "The type of a : " << Tpf_GetTypeCategory(a) << endl;

    // what is the type of sum

    cout << "The type of sum: " << Tpf_GetTypeCategory(sum) << endl;

    // what is the type of pro

    cout << "The type of pro: " << Tpf_GetTypeCategory(pro) << endl;

    /*
        a : an instance of type int
        sum: an instance of type int(int, int)
        pro: an instance of type int(int, int)

        a, sum, pro are names of instances of type int, int(int, int), int(int, int) respectively
    */

   auto f1_t = sum; // the type of sum is int(int, int)
                    // function cannot be copied,
                    // if an instance of type int(int, int), sum
                    // is assigned to f1_t using auto placeholder,
                    // the type of sum int(int, int) is decayed to int(*)(int, int)

   auto f2_t = pro;

   // what is the type of f1_t ?
   cout << "the type of f1_t: " << Tpf_GetTypeCategory(f1_t) << endl;
   cout << "the type of f2_t: " << Tpf_GetTypeCategory(f2_t) << endl;

   auto& fr1_t = sum; // the instance sum of type int(int, int) is assigned to auto& fr1_t,
                    // int(int, int) is converted to reference int(&)(int, int)
   auto& fr2_t = pro;

   // what is the type of fr1_t  and fr2_t ?

   cout << "the type of fr1_t: " << Tpf_GetTypeCategory(fr1_t) << endl;
   cout << "the type of fr2_t: " << Tpf_GetTypeCategory(fr2_t) << endl;
}

template<typename FTYPE>
void pass_function_as_parameter(FTYPE f)
{
    cout << "Without Reference, The type of f: " << Tpf_GetTypeCategory(f) << endl;

    cout <<"sum(2, 3) = " << f(2, 3) << endl;
}

template<typename FTYPE>
void pass_function_as_reference_parameter(FTYPE& f)
{
    cout << "With Reference, The type of f: " << Tpf_GetTypeCategory(f) << endl;

    
    cout <<"sum(4, 5) = " << f(4, 5) << endl;
}

void test_function_types()
{
    pass_function_as_parameter(sum);

    cout << endl;

    pass_function_as_reference_parameter(sum);
}

int main()
{
    // test_function_instance_and_type();

    test_function_types();
}