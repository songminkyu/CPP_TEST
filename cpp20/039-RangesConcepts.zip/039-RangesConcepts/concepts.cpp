﻿#include <tpf_output.hpp>
#include <ranges>

#include <vector>
#include <list>
#include <set>

// g++ -std=c++20 concepts.cpp -ltbb -o c.exe

// Ranges library (C++20)
// https://en.cppreference.com/w/cpp/ranges

tpf::sstream stream;
auto endl = tpf::endl;

void test_iota_reverse()
{
    auto zero_to_nine = std::views::iota(0, 10); // (0, 10]
    auto nine_to_zero = std::views::reverse(zero_to_nine);

    // for(auto& i: zero_to_nine) - it does not work
    for(auto&& i: zero_to_nine)
    {
        stream << i <<", ";
    }

    stream << endl;

    for(auto&& i: nine_to_zero)
    {
        stream << i <<", ";
    }

    stream << endl;

    auto to_even = std::views::transform([](auto&& e){ return 2 * e; } );
    auto to_odd = std::views::transform([](auto&& e){ return 2 * e + 1; });

    for(auto&& i: zero_to_nine | to_even)
    {
        stream << i <<", ";
    }
    stream << endl;

    for(auto&& i: nine_to_zero | to_odd)
    {
        stream << i <<", ";
    }
    stream << endl;


}

void test_range_concepts()
{
    using vector_t = std::vector<int>;
    using list_t = std::list<int>;
    using set_t = std::set<int>;

    stream <<"is vector_t a range? " << std::ranges::range<vector_t> << endl;
    stream <<"is list_t a range? " << std::ranges::range<list_t> << endl;
    stream <<"is set_t a range? " << std::ranges::range<set_t> << endl;

    // an array without element count is an incomplete type
    stream <<"is int[] a range? " << std::ranges::range<int[]> << endl;

    stream <<"is int[10] a range? " << std::ranges::range<int[10]> << endl;

    stream << "is vector_t a random_access_range? " 
        << std::ranges::random_access_range<vector_t> << endl;

    stream << "is list_t a random_access_range? " 
        << std::ranges::random_access_range<list_t> << endl;

    stream << "is set_t a random_access_range? " 
        << std::ranges::random_access_range<set_t> << endl;

    stream << "is vector_t a contiguous_range? " 
        << std::ranges::contiguous_range<vector_t> << endl;

    stream << "is list_t a contiguous_range? " 
        << std::ranges::contiguous_range<list_t> << endl;

    stream << "is set_t a contiguous_range? " 
        << std::ranges::contiguous_range<set_t> << endl;

}

int main()
{
    // test_iota_reverse();

    test_range_concepts();
}