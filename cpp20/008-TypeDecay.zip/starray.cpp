#include "tpf/types.hpp"

#include <iostream>

auto& cout = std::cout;
auto endl = "\n";

namespace types = tpf::types;

size_t GetBananaCount()
{
    return 10;
}

// with the keyword constexpr,
// GetBananaCountFixed() is not constant-expression
// or compile-time expression
constexpr size_t GetBananaCountFixed()
{
    return 10;
}

constexpr size_t GetPeachCount()
{
    return 0;
}

constexpr size_t GetPeachCountFixed()
{
    return 6;
}

// C++ compiler "interprets" this function
// at compile-time, when a literal value is passed
// to this function through the parameter stock_count.
// however, if non-literal value is passed
// to this function through the parameter stock_count,
// C++ compiler cannot acces to the value of stock_count
// at compile-time, that is, this function becomes a run-time construct.
constexpr size_t GetCherryCount(size_t stock_count)
{
    return stock_count + 10;
}

void _1_how_to_declare_static_array()
{
    /*
        Please pay special attention to "constant-expression or compile-time expression."
    */

   // we declared an instance of int[5], a
   // the type of a is int[5]
   int a[5]; 

    // we declared an instance of type double[3],
    // d is an instance of type d[3],
    // and initialized the elements of the array d with 1, 2, 3
   double d[]{1, 2, 3};

   size_t int_count{5};

    // it does not work.
    // int_count is a run-time construct, not compile-time construct
    // or int_count is not a constant-expression
   // int n[int_count];

    // don't get confused with square bracket [] with curly brace {}
    // we initialized an instance of size_t, apple_count with the value 6
    // constexpr means apple_count is a constant-expression
   constexpr size_t apple_count{6};

    // since apple_count is a constant-expression,
    // the following is perfectly legal in C++
   int n[apple_count];

    // this is more conventional C/C++ syntax
    // peach_count is also a constant-expression
   const size_t peach_count = 7;

   int peaches[peach_count];

    // banana_count is not constant-expression
    // or compile-time expression
   const size_t banana_count = GetBananaCount();

    // int bananas[banana_count];

    int bananas[ GetBananaCountFixed() ];

    // double dd[GetPeachCount()];

    // In C/C++, the element count of a static array
    // cannot be zero

    // it does not work
    // double dd[0];

    double peach[ GetPeachCountFixed() ];


    // it perfectly works
    short cherry [ GetCherryCount(5) ];

    // size_t cherry_count = 10;

    // // it does not work, why?
    // short cherries [ GetCherryCount(cherry_count)];

    /*
        In case of static array, the memory of the array
        should be RESERVED at compile-time.

        short cherry [ GetCherryCount(5) ];,

        short cherries [ GetCherryCount(cherry_count)];

    */

   constexpr size_t cherry_count = 10;

    // Now it works because cherry_count is now a constant-expression (or compile-time expression)
    // and GetCherryCount() is marked with constexpr, so
    // the C++ compiler call GetCherryCount(cherry_count) at compile-time, not at run-time
    // that is, C++ compiler can reserve memory for the array cherries
    short cherries [ GetCherryCount(cherry_count)];

    // Now the difference between const and constexpr

    size_t count = 10;

    // this is perfectly legal
    // my_peach_count is not a compile-time or constant-expression
    // my_peach_count is constant, but is initialized at run-time
    const size_t my_peach_count = GetCherryCount(count);

    // this is illegal in C++
    // When keyword constexpr is used to define a name as below,
    // constexpr means the name is a compile-time or constant expression.
    // In the line below, since count is not a compile-time expression,
    // The C++ compiler cannot evaluate GetCherryCount(count) at compile-time,
    // so it fails.
    // constexpr size_t my_pear_count = GetCherryCount(count);

    // For your information, fields of an enum (or enumeration) are constant-expression
    // or compile-time expression. "Fields of an enum" are called "enumerators."

    enum { AppleCount = 5, PeachCount = 6};

    // AppleCount and PeachCount are enumerators or fields of an enum.
    // These are constant-expression or compile-time expression.
    // So, the following lines of codes are PERFECTLY LEGAL

    int my_apples[AppleCount];
    size_t my_peaches[PeachCount];
}

/*
    1. static arrays are NOT copiable!!

    2. Type decay occurs when a static array is passed to a function by-value,
        but does not occur when passed by-reference.

    "type decay of a static array" means that the type of an array 
        int[3] is converted to int*
    
    Type decay occurs when a static array is passed to a function
    by-value, but not by-reference.
*/

void _2_how_to_know_array_type()
{
    int a[]{1, 2, 3}; // the type of a is int[3]

    // 1. What is the type of a ?

    cout << "The type of a: " << Tpf_GetTypeCategory(a) << endl;
 
    auto b = a; // the type of b is int*

    // 2. What is the type of b ?

    cout << "The type of b: " << Tpf_GetTypeCategory(b) << endl;

    auto& c = a; // the type of c is int(&)[3]

    // 3. What is the type of c?

    cout << "The type of c: " << Tpf_GetTypeCategory(c) << endl;

}

template<typename T>
void pass_as_by_value(T a)
{
    cout <<"The type of a passed by-value: " 
        << Tpf_GetTypeCategory(a) << endl;
}

template<typename T>
void pass_as_by_reference(T& b)
{
    cout <<"The type of b passed by-reference: " 
        << Tpf_GetTypeCategory(b) << endl;
}

void _3_understanding_type_decay_of_static_array()
{
     int a[]{1, 2, 3}; // the type of a is int[3]

     pass_as_by_value(a);

     cout << endl;

     pass_as_by_reference(a);

     cout << endl;
}

void _4_static_array_with_c_string()
{

    auto msg = "C style string";

    // What is the type of msg ?
    cout <<"The type of msg: " 
        << Tpf_GetTypeCategory(msg) << endl;

    pass_as_by_value("What's its type?");

    cout << endl;

    pass_as_by_reference("What's its type?");

}

template<typename ArrayType, size_t ArraySize>
auto get_array_by_reference( ArrayType(&a)[ArraySize]  )
{
    ArrayType s{};

    for(size_t i=0; i < ArraySize; ++i)
        s += a[i];

    cout <<"The element count of a: " << ArraySize << endl;
    
    cout <<"The type of ArrayType: "
        << Tpf_GetTypeName(ArrayType) << endl;

    cout << "The type of a: " << Tpf_GetTypeCategory(a) << endl;

    return s;
}

void _5_element_count_of_static_array()
{
    int a[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    auto s = get_array_by_reference(a);

    cout << "s = " << s << endl;
}

void _6_element_count_and_decay()
{
     int a[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

     auto count = types::array_size(a);

     cout << "Element count of a: "
        << count << endl;
}

int main()
{
    // _1_how_to_declare_static_array();

    // _2_how_to_know_array_type();

    // _3_understanding_type_decay_of_static_array();

    // _4_static_array_with_c_string();

    // _5_element_count_of_static_array();

    _6_element_count_and_decay();
}