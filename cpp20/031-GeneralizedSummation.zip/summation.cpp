// this macro is important if you are using Microsoft C++ compiler
#define NOMINMAX

// cl /EHsc /std:c++latest /await /O2 summation.cpp /Fe: m.exe 

#include <tpf_output.hpp>
#include <tpf_chrono_random.hpp>

#include <gmp_util.h>
#include "resumable.hpp"

namespace chr = tpf::chrono_random;

tpf::sstream stream;
auto endl = tpf::endl;

template<typename Type>
mpz_class fast_power(mpz_class a, Type p)
{
    unsigned u = p;
    mpz_class b = 1; // 1 is multiplicative identity
    
    while(u) // u != 0
    {
        if( u&1 )
        {
            b *= a;
        }

        u >>= 1; // shift-left 1 bit

        a *= a; 
    }

    return b;
}

void test_fast_power()
{
    mpz_class m = fast_power(2, 3);

    stream << "2^3 = " << m << endl;
}


template<typename Type>
resumable_type<mpz_class> ncr_coroutine(Type n, Type rr = 0)
{
    Type r = 0;
    mpz_class n_c_r = 1;

    while(r < rr)
    {
        n_c_r = (n-r) * n_c_r / (r + 1); 
              // (n-r) / (r + 1) * n_c_r is wrong
        ++r; // k = k + 1, prepare for next iteration of nCr, or nCr+1
    }

    // the value n_c_r is returned
    // when this coroutine is retrieved or called 
    // using either get() or next() member function
    co_yield n_c_r;

    while(true)
    {
        if(r < n)
        {
            n_c_r = (n-r) * n_c_r / (r + 1); 
            ++r; // k = k + 1, prepare for next iteration of nCr, or nCr+1
        }
        else // rewind r and n_c_r
        {
            r = 0;
            n_c_r = 1;
        }

        co_yield n_c_r;
    }

    co_return n_c_r; 
}

void test_ncr_coroutine()
{
    long long n = 5;
    long long r = 2;

            // ncr_coroutine(5, 2)
    auto ncr = ncr_coroutine(n, r);

    for(auto i = r; i <= n; ++i)
    {
                // the first returned n_c_r = 5C2
        stream << ncr.next() << ", ";
    }

    stream << endl;
}

template<typename Type>
mpz_class draft_summation(Type n, Type r, std::vector<mpz_class>& stashed_k_r)
{
    if( (r-1) < stashed_k_r.size())
        return stashed_k_r[r-1];
    else
    {
        mpz_class n_1 = n + 1;
        mpz_class head = n_1 * ( fast_power(n_1, r) - 1 );

        auto bin_coeff = ncr_coroutine(r+1, (Type)2); // 2 is for 1 + i, where i = 1

        mpz_class tail = 0;
        
        Type r_1 = r-1;

        for(Type i = 1; i <= r_1; ++i)
            tail += bin_coeff.next() * draft_summation(n, r-i, stashed_k_r);

        stashed_k_r.emplace_back( (head - tail)/ ( r+1 ) );

        return stashed_k_r.back(); // == stashed_k_r[r-1]
    }
}

template<typename Type>
mpz_class draft_summation(Type n, Type r)
{
    std::vector<mpz_class> stashed_k_r;
    stashed_k_r.reserve((size_t)r); // for optimization

    return draft_summation(n, r, stashed_k_r);
}

void test_draft_summation()
{
    long long n;
    long long r;

    do
    {
        std::cout << "n = "; std::cin >> n;
        std::cout << "r = "; std::cin >> r;

        auto sum = draft_summation(n, r);

        stream << "sum("<<n<<", "<<r<<"): " << sum << endl;

    } while (n !=0 && r != 0);    
}

//////////////////////////////////////////////////
template<typename Type>
mpz_class summation_internal(Type n, Type r, 
    std::vector<mpz_class>& stashed_k_r,
    const mpz_class& n_1, mpz_class& n_1_r)
{
    if( (r-1) < stashed_k_r.size())
        return stashed_k_r[r-1];
    else
    {
        // mpz_class n_1 = n + 1;

        // mpz_class head = n_1 * ( fast_power(n_1, r) - 1 );

        auto bin_coeff = ncr_coroutine(r+1, (Type)2); // 2 is for 1 + i, where i = 1

        mpz_class tail = 0;
        
        Type r_1 = r-1;

        for(Type i = 1; i <= r_1; ++i)
            tail += bin_coeff.next() * summation_internal(n, r-i, stashed_k_r, n_1, n_1_r);

        n_1_r *= n_1; // (n+1)^r

        mpz_class head = n_1 * ( n_1_r - 1 );

        stashed_k_r.emplace_back( (head - tail)/ ( r+1 ) );

        return stashed_k_r.back(); // == stashed_k_r[r-1]
    }
}

template<typename Type>
mpz_class summation(Type n, Type r)
{
    std::vector<mpz_class> stashed_k_r;
    stashed_k_r.reserve((size_t)r); // for optimization

    const mpz_class n_1 = n + 1;
    mpz_class n_1_r = 1; // the multiplicative identity

    return summation_internal(n, r, stashed_k_r, n_1, n_1_r);
}

void test_summation()
{
    long long n;
    long long r;

    chr::stop_watch sw;

    do
    {
        std::cout << "n = "; std::cin >> n;
        std::cout << "r = "; std::cin >> r;

        sw.reset();

        auto sum = summation(n, r);

        stream <<endl << "Elapsed: " << sw.elapsed_time<chr::micro_t>()<< endl; 

        stream << "sum("<<n<<", "<<r<<"): " << sum << endl;

    } while (n !=0 && r != 0);    
}

int main()
{
    stream.std().imbue(std::locale(""));

    // test_fast_power();

    // test_ncr_coroutine();

    // test_draft_summation();

    test_summation();
}
