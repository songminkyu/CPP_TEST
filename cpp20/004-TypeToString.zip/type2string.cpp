#include "tpf/types.hpp"
#include <iostream>

namespace types = tpf::types;

void test_type_to_string()
{
    int a = 5;

    std::cout << types::type_to_string<int>() << std::endl;

    std::cout << "The type of a: "
        << types::type_to_string< decltype(a) >() << std::endl;

}

template<typename Type>
void my_fun(Type&& arg)
{
    std::cout <<"Type of Type: "
        << Tpf_GetTypeName(Type) << std::endl;

    std::cout <<"Type of arg: " 
        << Tpf_GetTypeCategory(arg) << std::endl;
}

void test_tpf_get_type_name_macros()
{
    int a = 5;

    std::cout <<"With a : " << std::endl;

    my_fun(a);

    std::cout << std::endl;

    std::cout <<"With literal 5 : " << std::endl;
    my_fun(5);
}


int main()
{
    // test_type_to_string();

    test_tpf_get_type_name_macros();
}