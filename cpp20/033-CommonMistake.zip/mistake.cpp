﻿#include <tpf_output.hpp>

tpf::sstream stream;
auto endl = tpf::endl;

void what_is_wrong()
{
    int a = 10;
    int b = 15;
    int d = 3;

    stream <<"a = " << a <<" b = "<<b <<" d = "<<d << endl;

    // this is wrong, a = 10, d = 3
    // 10 / 3 = 3, 10 is not evenly divisible by 3
    // 3 * 15 (b) = 45
    stream <<" a / d * b = " << (a / d * b) << endl;

    // this is correct, but not perfect,
    // a = 10, b = 15, a * b = 150
    // 150 / 3 = 50, this is correct
    //   10 * 15      10 * 5
    //  -------- = ----------- - 50
    //      3          1
    stream <<" a * b / d = " << (a * b / d) << endl; // a / d * b == a * b / d mathematically
    // why a * b / d is not perfect ?
 }

 template<typename T>
 auto reduce(T& a, T& b)
 {
     // this std::gcd() is implemented using Euclidean Algorithm,
     // which is far from free. It has its computation cost.
     
     auto g = std::gcd(a, b); // std::gcd() was introduced to C++17, #include <numeric>
                              // this function returns the GCD or Greatest Common Divisor

    a /= g; b /= g;

    return g;
 }

// dummy function to expand variadic template parameters
 template<typename... Types>
 void process(Types&&...) { }
 
 void perfect_integer_division()
 {
     int a = -256;
     int b = 50;
     int d = 25;

    stream <<"a = " << a <<" b = "<<b <<" d = "<<d << endl;

    stream << "Before Reduction" << endl;
    stream <<" a / d * b = " << (a / d * b) << endl;
    stream <<" a * b / d = " << (a * b / d) << endl; 

    reduce(a, d); reduce(b, d);

    stream << "\nAfter Reduction" << endl;
    stream <<" a / d * b = " << (a / d * b) << endl;
    stream <<" a * b / d = " << (a * b / d) << endl; 
 }

 void perfect_unsigned_integer_division()
 {
     unsigned a = 4'294'967'040;
     unsigned b = 50;
     unsigned d = 25;

    stream <<"a = " << a <<" b = "<<b <<" d = "<<d << endl;

    stream << "Before Reduction" << endl;

    // a = 4'294'967'040 is NOT divisible by d = 25
    stream <<" a / d * b = " << (a / d * b) << endl;

    // a = 4'294'967'040 x b = 50 gives OVERFLOW
    stream <<" a * b / d = " << (a * b / d) << endl; 

    // BUT THIS reduce() function has its cost.
    reduce(a, d); reduce(b, d);

    stream << "\nAfter Reduction" << endl;
    stream <<" a / d * b = " << (a / d * b) << endl;
    stream <<" a * b / d = " << (a * b / d) << endl; 
 }

 /*
    a x b x c x ...
    ---------------
        divisor
 */

template<typename DivisorType, typename... DividendTypes>
auto divide(DivisorType&& divisor, DividendTypes&&... dividends)
{
    process(reduce(dividends, divisor)...);

    return ( dividends * ... ) / divisor;
}

void generic_perfect_integer_division()
 {
     unsigned a = 4'294'967'040;
     unsigned b = 50;
     unsigned d = 25;

    stream <<"a = " << a <<" b = "<<b <<" d = "<<d << endl;

    stream << "Before Reduction" << endl;

    // a = 4'294'967'040 is NOT divisible by d = 25
    stream <<" a / d * b = " << (a / d * b) << endl;

    // a = 4'294'967'040 x b = 50 gives OVERFLOW
    stream <<" a * b / d = " << (a * b / d) << endl; 

    // BUT THIS reduce() function has its cost.
    reduce(a, d); reduce(b, d);

    stream << "\nGeneralized Integer Division" << endl;
    stream <<" a * b / d = " << divide(d, a, b) << endl; 

    /*
                2 x 3 x 5 x 7 x 11      2 x 5
        ? =  ---------------------- = --------- = 10
                     3 x 7 x 11           1
    */

   stream <<" 2 x 3 x 5 x 7 x 11 / ( 3 x 7 x 11) = " 
    << divide( 3 * 7 * 11, 2, 3, 5, 7, 11) << endl;
 }

int main()
{
    // what_is_wrong();

    // perfect_integer_division();

    // perfect_unsigned_integer_division();

    generic_perfect_integer_division();
   
}