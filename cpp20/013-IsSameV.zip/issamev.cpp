#include "tpf/types.hpp"

#include <iostream>

auto& cout = std::cout;
auto endl = std::endl<char, std::char_traits<char>>;

namespace tpf::types
{
    template<typename T1, typename T2, typename... Types>
    struct st_is_same
    {
        static constexpr bool value = st_is_same<T1, T2>::value && st_is_same<T1, Types...>::value;
    };

    template<typename T1, typename T2> 
    struct st_is_same<T1, T2> // now st_is_same<T1, T2> is specialization
    {
        static constexpr bool value = false;
    };

    template<typename T>   // specialization
    struct st_is_same<T, T> // <T, T> template argument
    {
        static constexpr bool value = true;
    };

    template<typename T1, typename T2, typename... Types>
    constexpr bool is_same_v = st_is_same<T1, T2, Types...>::value;
    
} // end of namespace 

namespace types = tpf::types;

void test_is_same_v()
{
    cout<< std::boolalpha;

    cout <<"is <int, int> same? " << types::is_same_v<int, int> << endl;
    cout <<"is <int, float> same? " << types::is_same_v<int, float> << endl;

    cout <<"is <int, int, int> same? " << types::is_same_v<int, int, int> << endl;
    cout <<"is <int, float, int> same? " << types::is_same_v<int, float, int> << endl;

    cout <<"is <int, int, int, int> same? " << types::is_same_v<int, int, int, int> << endl;
    cout <<"is <int, int, int, float> same? " << types::is_same_v<int, int, int, float> << endl;

}

int main()
{
    test_is_same_v();
}