﻿#include <tpf_output.hpp>

/*

	020 - The C++ 20 Concepts Tutorial 3, Variadic Template Type-Constraint, Fold Expression
	https://www.youtube.com/watch?v=WQpEYrtu9yA&list=PL1_C6uWTeBDH6i4Rr3E2ZYLUq6_Rdq3Dr&index=21
	
	019 - The C++ 20 Concepts Tutorial 2, How to Use Modern C++ Language 100%
	https://www.youtube.com/watch?v=FTtaeYGWpac&list=PL1_C6uWTeBDH6i4Rr3E2ZYLUq6_Rdq3Dr&index=20

	018 - The C++ 20 Concepts Tutorial 1, What are Concepts in C++?
	https://www.youtube.com/watch?v=_m8lXscN2zs&list=PL1_C6uWTeBDH6i4Rr3E2ZYLUq6_Rdq3Dr&index=19

*/
tpf::sstream stream;
auto endl = tpf::endl;

namespace test
{
    namespace detail
    {
        template<typename T, typename S>
        concept SameHelper = std::is_same_v<T, S>;

    } // end of namespace detail

    template<typename T, typename S>
    concept same_as = detail::SameHelper<T, S> && detail::SameHelper<S, T>;

    namespace detail
    {
        template<typename T, typename... Types>
        concept is_in_the_list = (same_as<Types, T> || ...);

    } // end of namespace detail

    template<typename T, typename... Types>
    concept type_in_list = detail::is_in_the_list<T, Types...>;

} // end of namespace test

void test_is_in_the_list()
{
    stream << "Is <int> in <short, float, double> ? "
        << test::detail::is_in_the_list<int, short, float, double> << endl;

    stream << "Is <int> in <short, float, int, double> ? "
       << test::detail::is_in_the_list<int, short, float, int, double> << endl;
}

template<typename T>
concept AllowedType = test::type_in_list<T, int, long, long long>;

template<AllowedType T = int>
class rational
{
    protected:
        T m_p; // numerator
        T m_q; // denominator

    public:
        rational(T p = T{}, T q = T{1}): m_p {p}, m_q{q}
        {
            stream <<"rational<"<< Tpf_GetTypeName(T) << "> is created" << endl;
        }
};

void test_rational()
{
    rational r1{}; // we use template argument deduction introduced in C++17 standard

    rational r2{ 3ll, 5ll};

    // rational r3{5.4, 6.7};

}

int main()
{
    // test_is_in_the_list();

    test_rational();
}