#include "tpf/types.hpp"

#include <iostream>
#include <utility> // for std::integer_sequence

auto& cout = std::cout;
auto endl = std::endl<char, std::char_traits<char>>;
auto nl = "\n";

namespace tpf::types
{
    // T : type template parameter
    // Ints... : non-type variadic template parameter or non-type parameter pack
    // integer_sequence can take one type argument and 0 or more of non-type arguments
    template<typename T, T... Ints>
    struct integer_sequence
    {
        static constexpr std::size_t size()
        {
            return sizeof...(Ints);
        }
    };

    template<std::size_t N>
    using index_sequence = integer_sequence<std::size_t, N>;

    namespace hidden
    {
        // we have to match the count of template arguments 
        // between the primary template and its explicit specialization
        // this is primary template
        // primary template determines the number of template arguments
        // we can initialize template parameters in the primary template
        // primary template does not need to have its definition body
        // this class template can take 1 or more of template arguments
        // T : type template parameter
        // Ts... : type variadic template parameter or type parameter pack 
        template<typename T, typename ... Ts> struct st_add_sequence;

        // T : type template parameter
        // Ints1... : non-type template parameter
        // Ints2... : non-type template parameter
        // this is an explicit specialization
        template<typename T, T ... Ints1, T ... Ints2>
        struct st_add_sequence< integer_sequence<T, Ints1...>, integer_sequence<T, Ints2...> >
        {                       // integer_sequence<T, Ints1...> - 1 template argument
                                // integer_sequence<T, Ints2...> - 1 template argument

            using type = integer_sequence<T, Ints1..., Ints2...>;
        };

        // T : type template parameter
        // Ints ... : non-type template parameter
        // this is an explicit specialization
        template<typename T, T ... Ints>
        struct st_add_sequence< integer_sequence<T, Ints...> >
        {
            using type = integer_sequence<T, Ints...>;
        };

        // alias template or using template
        template<typename SeqType1, typename SeqType2>
        using add_sequence_t = typename st_add_sequence<SeqType1, SeqType2>::type;

        // primary template
        // primary template determines the number of template arguments
        template<typename T, T N, T S>
        struct st_make_sequence
        {
            using type = add_sequence_t<integer_sequence<T, S>, typename st_make_sequence<T, N, S+1>::type>;
        };

        // specialization
        template<typename T, T N>
        struct st_make_sequence<T, N, N> // N == S (=N)
        {
            using type = integer_sequence<T, N>;
        };

        template<typename T, T N>
        using make_integer_sequence = typename st_make_sequence<T, N-1, T{0}>::type;

        template<std::size_t N>
        using make_index_sequence = typename st_make_sequence<std::size_t, N-1, std::size_t{0}>::type;

    } // end of namespace hidden

    template<typename SeqType1, typename SeqType2>
    using add_sequence_t = hidden::add_sequence_t<SeqType1, SeqType2>;

    template<typename T, T N>
    using make_integer_sequence = hidden::make_integer_sequence<T, N>;

    template<std::size_t N>
    using make_index_sequence = hidden::make_index_sequence<N>;

    template<typename... Types>
    using index_sequence_for = make_index_sequence<sizeof...(Types)>;

} // end of namespace tpf::types;

namespace types = tpf::types;

void test_add_sequence()
{
    using seq_1 = types::integer_sequence<int, 0, 1, 2>;
    using seq_2 = types::integer_sequence<int, 3, 4, 5>;

    using seq_3 = types::add_sequence_t<seq_1, seq_2>;

    cout <<"seq_3: " << Tpf_GetTypeName(seq_3) << endl;

    using std_1 = std::integer_sequence<int, 0, 1, 2, 3, 4, 5>;
    cout <<"std_1: " << Tpf_GetTypeName(std_1) << endl;
}

void test_make_sequence()
{
    using seq_1 = types::make_integer_sequence<std::size_t, 5>;

    cout << "seq_1: " << Tpf_GetTypeName(seq_1) << endl;

    using std_1 = std::make_integer_sequence<std::size_t, 5>;

    cout << "std_1: " << Tpf_GetTypeName(std_1) << endl;

    using typ_idx_1 = types::make_index_sequence<5>;
    using std_idx_1 = std::make_index_sequence<5>;

    cout << "typ_idx_1: " << Tpf_GetTypeName(typ_idx_1) << endl;
    cout << "std_idx_1: " << Tpf_GetTypeName(std_idx_1) << endl;

    using index_for_t = types::index_sequence_for<int, float, double>;
    using std_index_t = std::index_sequence_for<int, float, double>;

    cout << "index_for_t: " << Tpf_GetTypeName(index_for_t) << endl;
    cout << "std_index_t: " << Tpf_GetTypeName(std_index_t) << endl;
  
}

int main()
{
    // test_add_sequence();

    test_make_sequence();
}